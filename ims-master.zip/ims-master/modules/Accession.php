<?php
/**
 * Created by PhpStorm.
 * User: ahmad
 * Date: 12/12/14
 * Time: 4:04 PM
 */

class Accession extends Controller {

    private $tbl;

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("Accession", "acc_num");
        $this->tbl = "tbl_book_master";
    }

    public function index() {

         if(fnmatch(URL."Accession/edit/*",$_SERVER['HTTP_REFERER'])!=true){
            $this->Reset('Accession');
			}
        Controller::$view['indexPage']="Accession";
        //$this->Reset('Accession');
		
        Controller::$view['title'] = "Accession of Book";
        $t=array('Accession Number','Book Title','Category Title','Type','Volume','Author','status','Publication Year','Class No.','Book No.','cost','Bill No','Withdrawn Date','remarks');
        $f=array('acc_num','title','cat_title','book_type','volume','author','status','publication_year','class_num','book_num','cost','bill_no','withdrawn_date','remark');
        Controller::$view['grid'] = $this->db->GetRecords($t, $f,'view_acc_details', $this->link['expre'],$this->link['add'], false, $this->link['edit'], FALSE, True,$this->link['edit'],false);
       
        //Controller::$view['grid']=$this->db->GetRecords($t,$f,'view_acc_details', $this->link['expre'], $this->link['add'], $this->link['del'], $this->link['edit'], FALSE, true, $this->link['edit'],true);

        $this->view();
    }
//*********************

    public function edit($id) {
        
        $this->checkPermission("edit");
        Controller::$view['title']="Edit Accession details";
        Controller::$view['indexPage']="Accession";
        Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');
        if(isset($_POST['update']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $category_id=trim($_POST['category']);
            $book_type=trim($_POST['book_type']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($_POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            //$status="IN";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);
            $location=trim($_POST['location']);

            $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                "book_num","pages","cost","bill_no","withdrawn_date","bill_date","location","remark");
            $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$location,$remarks);
            $result = $this->db->Update($this->tbl, $f, $v, 'acc_num', $id);

            if ($result == true) {
                Controller::$view['message'] = 'Record updated.';
            }
            else
            {
                Controller::$view['message']=  'Error Occured';
            }

            Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
            Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');


        }


        $this->view('editbookacc');
    }

//*********************
    public function add() {
        $this->checkPermission("add");
        Controller::$view['title'] = "Add New Accession";
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');
        $next_acc="";
        Controller::$view['libName']='central';
        Controller::$view['indexPage']="Accession";

        if(isset($_POST['add']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $book_type=trim($_POST['book_type']);
            $category_id=trim($_POST['category']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($_POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            $status="Available";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);

            $copies=trim($_POST['copies']);
            
            $location=trim($_POST['location']);

            if($copies==1){
            $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                "book_num","pages","cost","bill_no","withdrawn_date","bill_date","status","location","remark");
            $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$status,$location,$remarks);

            $result= $this->db->Insert($this->tbl, $f, $v);
			$next_acc=$acc_num+1;
            if($result==True)
            {
                Controller::$view['message']="Record Inserted. Accession Number is :".$acc_num;
            
            }
            else{
                Controller::$view['message']="Error occured.";

            }
            }
            else{
                while($copies>0){

                    $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                    "book_num","pages","cost","bill_no","withdrawn_date","bill_date","status","location","remark");
                $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                    $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$status,$location,$remarks);

                $result= $this->db->Insert($this->tbl, $f, $v);

                if($result==True)
                {
                    Controller::$view['message']="Record Inserted. Accession Number is :".$acc_num;
                }
                else{
                    Controller::$view['message']="Error occured.";

                }
                $acc_num++;
                $copies--;
                }
			$next_acc=$acc_num;
            }

		
		
		Controller::$view['next-acc']=$next_acc;
		
		$next_acc="";

        }

        $this->view('addbookacc');
    }

//*********************

}

?>
