<?php

class attendanceleft extends Controller {

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("id", "paper_id");
   //     $this->tbl = "tbl_students";
    }

    public function index() {
        $this->Reset('students');
        Controller::$view['title']="Faculty List whose attendance is left";
        $paperlist=$this->db->FetchList('*','view_assign_paper_staff');
        $i=1;
        Controller::$view['papers_record']="<table border='5'>";
        Controller::$view['papers_record'].="<tr>";

        Controller::$view['papers_record'].="<th>S.No.</th>";
        Controller::$view['papers_record'].="<th>Batch Title</th>";
        Controller::$view['papers_record'].="<th>Paper Code</th>";
        Controller::$view['papers_record'].="<th>Paper Name</th>";
        Controller::$view['papers_record'].="<th>HR Number</th>";
        Controller::$view['papers_record'].="<th>Faculty Name</th>";
        Controller::$view['papers_record'].="<th>Email</th>";

        Controller::$view['papers_record'].="</tr>";
        foreach($paperlist as $paper)
        {
            Controller::$view['papers_record'].="<tr>";
            $paperid=$paper['paper_id'];

            $paperlist=$this->db->FetchList('*','tbl_attendance',"WHERE paper_id='$paperid'");

            if($paperlist==False)
            {
                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$i;
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['title'];
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['paper_code'];
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['paper_title'];
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['staff_id'];
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['staff_name'];
                Controller::$view['papers_record'].="</td>";

                Controller::$view['papers_record'].="<td>";
                Controller::$view['papers_record'].=$paper['o_email'];
                Controller::$view['papers_record'].="</td>";


                $i++;
            }

            Controller::$view['papers_record'].="</tr>";

        }
        Controller::$view['papers_record'].="</table>";

        $i--;
        $this->view('attendanceleft');
    }

}
