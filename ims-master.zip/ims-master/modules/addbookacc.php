<?php
/**
 * Created by PhpStorm.
 * User: ahmad
 * Date: 15/12/14
 * Time: 11:48 AM
 */
require('header.php'); ?>
<h1><?= Controller::$view['title'] ?></h1>
<div class="content_item">
    <center><b><?= Controller::printMessage() ?></b></center><br/>

    <form id="form1" name="form1" method="post">
        <table width="100%" border="0">

            <tr>
                <td width="30%">Book Accession No.:</td>
                <td width="70%"><input type="text" name="booknum" id="booknum" class="validate[required] text-input" /><span style=" font-weight: bold;" id="encheck"></td>

            </tr>
            <tr>
                <td>Book Title:</td>
                <td><input type="text" name="title" id="title" class="validate[required] text-input" /></td>
                </tr>
            <tr>
                <td>Number Of Copies</td>
                <td><input type="text" name="copies" id="copies" class="validate[required,custom[integer]] text-input" /></td>
            </tr>
            <tr>
                <td>Book Category</td>
                <td>
                    <select name="category" class="validate[required]">
                        <option value="">--Select--</option>
                        <?php echo Controller::$view['category']; ?>
                    </select>
                </td>

            </tr>
            <tr>
                <td>Book Type</td>
                <td>
                    <select name="book_type" class="validate[required]">
                        <option value="">--Select--</option>
                        <option value="Reference">Reference</option>
                        <option value="Text-Book">Text-Book</option>
                        <option value="Journal">Journal</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td>Author(s):</td>
                <td><input type="text" name="author" id="author" class="validate[required] text-input" /></td>
            </tr>
            <tr>
                <td>Place & Publisher:</td>
                <td><input type="text" name="placepub" id="placepub" class="validate[required] text-input" /></td>
            </tr>
            </tr>
            <tr>
                <td>Volume:</td>
                <td><input type="text" name="volume" id="volume" /></td>
            </tr>
            <tr>
                <td>Year of Publication:</td>
                <td><input type="text" name="yearpub" id="yearpub" class="validate[required] text-input" /></td>
            </tr>
            <tr>
                <td>Pages:</td>
                <td><input type="text" name="pages" id="pages" class="validate[required,custom[integer]] text-input" /></td>
            </tr>
            <!--
            <tr>
                <td>Status:</td>
                <td>
                    <select name="status" class="validate[required]">
                        <option value="">--Select</option>
                        <option value="IN">Available</option>
                        <option value="OUT">Issued</option>
                        <option value="HOLD">Reserved</option>
                        <option value="NA">Not Available</option>
                    </select>
                </td>
            </tr>
            -->
            <tr>
                <td>Source:</td>
                <td><input type="text" name="source" id="source" class="validate[required] text-input" /></td>
            </tr>
            <tr>
                <td>Class No:</td>
                <td><input type="text" name="class_num" id="class_num" /></td>
            </tr>
            <tr>
                <td>Book No:</td>
                <td><input type="text" name="book_num" id="book_num"  /></td>
            </tr>
            <tr>
                <td>Cost:</td>
                <td><input type="text" name="cost" id="cost" class="" /></td>
            </tr>
            <tr>
                <td>Bill No:</td>
                <td><input type="text" name="bill_num" id="bill_num"  /></td>
            </tr>
            <tr>
                <td>Bill Date:</td>
                <td><input type="text"  name="bill_date" id="datepick" /></td>
            </tr>

            <tr>
                <td>Withdrawn Date:</td>
                <td><input type="text"  name="withdrawn_date" id="datepick2" /></td>

            </tr>

            <tr>
                <td>Remarks:</td>
                <td><textarea name="remarks" id="remarks"></textarea> </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
            </tr>

            <tr>
                <td height="24">&nbsp;</td>
                <td><input type="submit" name="add" id="addacc" value="Add Book" />
                </td>
            </tr>

        </table>
        <input type="hidden" name="libName" id="libName" value="<?=Controller::$view['libName'];?>">
    </form>
</div>
<?php require('footer.php'); ?>
