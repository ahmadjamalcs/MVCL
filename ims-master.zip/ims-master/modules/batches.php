<?php

class Batches extends Controller {

    private $tbl;

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("batches", "id");
        $this->tbl = "tbl_batches";
    }

    public function index() {
        $this->Reset('batches');

        Controller::$view['title'] = "Batches";
        $titles = array('ID','Title', 'School', 'DeptID', 'Course', 'Status', 'Location','ID');
        $fields = array('id','title', 'faculty_id', 'dept_id', 'course_id','c_status','location', 'id');
        Controller::$view['grid'] = $this->db->GetRecords_batches($titles, $fields, 'tbl_batches', $expre, $this->link['add'],
            false, $this->link['edit'], false, TRUE, false, array('Enable', 'active'),FALSE);
        $this->view();
    }

    public function add() {
        $this->checkPermission("add");
        if (isset($_POST['btnsubmit'])) {
            $title = trim($_POST['title']);

            $faculty_id = $_POST['faculty_id'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];
            //$start_date = trim($_POST['start_date']);
            //$end_date = trim($_POST['end_date']);
            //$acc_session_id = trim($_POST['acc_session_id']);
            //$section = $_POST['section'];
            //$location = $_POST['location'];
            $sem=trim($_POST['sem']);
            $semWiseSystem=trim($_POST['semWiseSystem']);
            $gradingSystem=trim($_POST['gradingSystem']);

            $c_status = $_POST['c_status'];
            $des = trim($_POST['des']);

            $t = array('`title`','`des`', '`faculty_id`', '`dept_id`', '`course_id`', '`sem`', '`Sem-year`','`c_status`','`gradingSystem`');
            $v = array($title, $des, $faculty_id, $dept_id, $course_id, $sem, $semWiseSystem,$c_status,$gradingSystem);
            $result=$this->db->Insert($this->tbl, $t, $v);
            if ($result) {
                Controller::$view['message'] = "Batch created.".$result;
            } else {
                Controller::$view['message'] = "Error! please try later";
            }
        }

        Controller::$view['title'] = 'Create New Batch';
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");
        Controller::$view['acc_session']=$this->getOptions('id,session_name', 'tbl_academic_session', "WHERE active=1");
        $this->view('addbatch');
    }

    public function timetable($id){

        $this->checkPermission("edit");

        if(isset($_POST['add_pr']))
        {
            $fields="(`batchid`,`paperid`,`daytime`,`empcode`)";

            $M9=$_POST['M-9'];
            $HDN_M9=$_POST['HDN_M-9'];
            $array_M9="($id,'$M9','M9','$HDN_M9')";

            $T9=$_POST['T-9'];
            $HDN_T9=$_POST['HDN_T-9'];
            $array_T9="($id,'$T9','T9','$HDN_T9')";

            $W9=$_POST['W-9'];
            $HDN_W9=$_POST['HDN_W-9'];
            $array_W9="($id,'$W9','W9','$HDN_W9')";

            $TH9=$_POST['TH-9'];
            $HDN_TH9=$_POST['HDN_TH-9'];
            $array_TH9="($id,'$TH9','TH9','$HDN_TH9')";

            $F9=$_POST['F-9'];
            $HDN_F9=$_POST['HDN_F-9'];
            $array_F9="($id,'$F9','F9','$HDN_F9')";

            $S9=$_POST['S-9'];
            $HDN_S9=$_POST['HDN_S-9'];
            $array_S9="($id,'$S9','S9','$HDN_S9')";

            $M10=$_POST['M-10'];
            $HDN_M10=$_POST['HDN_M-10'];
            $array_M10="($id,'$M10','M10','$HDN_M10')";

            $T10=$_POST['T-10'];
            $HDN_T10=$_POST['HDN_T-10'];
            $array_T10="($id,'$T10','T10','$HDN_T10')";

            $W10=$_POST['W-10'];
            $HDN_W10=$_POST['HDN_W-10'];
            $array_W10="($id,'$W10','W10','$HDN_W10')";

            $TH10=$_POST['TH-10'];
            $HDN_TH10=$_POST['HDN_TH-10'];
            $array_TH10="($id,'$TH10','TH10','$HDN_TH10')";

            $F10=$_POST['F-10'];
            $HDN_F10=$_POST['HDN_F-10'];
            $array_F10="($id,'$F10','F10','$HDN_F10')";

            $S10=$_POST['S-10'];
            $HDN_S10=$_POST['HDN_S-10'];
            $array_S10="($id,'$S10','S10','$HDN_S10')";

            $M11=$_POST['M-11'];
            $HDN_M11=$_POST['HDN_M-11'];
            $array_M11="($id,'$M11','M11','$HDN_M11')";

            $T11=$_POST['T-11'];
            $HDN_T11=$_POST['HDN_T-11'];
            $array_T11="($id,'$T11','T11','$HDN_T11')";

            $W11=$_POST['W-11'];
            $HDN_W11=$_POST['HDN_W-11'];
            $array_W11="($id,'$W11','W11','$HDN_W11')";

            $TH11=$_POST['TH-11'];
            $HDN_TH11=$_POST['HDN_TH-11'];
            $array_TH11="($id,'$TH11','TH11','$HDN_TH11')";

            $F11=$_POST['F-11'];
            $HDN_F11=$_POST['HDN_F-11'];
            $array_F11="($id,'$F11','F11','$HDN_F11')";

            $S11=$_POST['S-11'];
            $HDN_S11=$_POST['HDN_S-11'];
            $array_S11="($id,'$S11','S11','$HDN_S11')";

            $M12=$_POST['M-12'];
            $HDN_M12=$_POST['HDN_M-12'];
            $array_M12="($id,'$M12','M12','$HDN_M12')";

            $T12=$_POST['T-12'];
            $HDN_T12=$_POST['HDN_T-12'];
            $array_T12="($id,'$T12','T12','$HDN_T12')";

            $W12=$_POST['W-12'];
            $HDN_W12=$_POST['HDN_W-12'];
            $array_W12="($id,'$W12','W12','$HDN_W12')";

            $TH12=$_POST['TH-12'];
            $HDN_TH12=$_POST['HDN_TH-12'];
            $array_TH12="($id,'$TH12','TH12','$HDN_TH12')";

            $F12=$_POST['F-12'];
            $HDN_F12=$_POST['HDN_F-12'];
            $array_F12="($id,'$F12','F12','$HDN_F12')";


            $S12=$_POST['S-12'];
            $HDN_S12=$_POST['HDN_S-12'];
            $array_S12="($id,'$S12','S12','$HDN_S12')";




            $M2=$_POST['M-2'];
            $HDN_M2=$_POST['HDN_M-2'];
            $array_M2="($id,'$M2','M2','$HDN_M2')";

            $T2=$_POST['T-2'];
            $HDN_T2=$_POST['HDN_T-2'];
            $array_T2="($id,'$T2','T2','$HDN_T2')";

            $W2=$_POST['W-2'];
            $HDN_W2=$_POST['HDN_W-2'];
            $array_W2="($id,'$W2','W2','$HDN_W2')";

            $TH2=$_POST['TH-2'];
            $HDN_TH2=$_POST['HDN_TH-2'];
            $array_TH2="($id,'$TH2','TH2','$HDN_TH2')";

            $F2=$_POST['F-2'];
            $HDN_F2=$_POST['HDN_F-2'];
            $array_F2="($id,'$F2','F2','$HDN_F2')";

            $S2=$_POST['S-2'];
            $HDN_S2=$_POST['HDN_S-2'];
            $array_S2="($id,'$S2','S2','$HDN_S2')";

            $M3=$_POST['M-3'];
            $HDN_M3=$_POST['HDN_M-3'];
            $array_M3="($id,'$M3','M3','$HDN_M3')";

            $T3=$_POST['T-3'];
            $HDN_T3=$_POST['HDN_T-3'];
            $array_T3="($id,'$T3','T3','$HDN_T3')";

            $W3=$_POST['W-3'];
            $HDN_W3=$_POST['HDN_W-3'];
            $array_W3="($id,'$W3','W3','$HDN_W3')";

            $TH3=$_POST['TH-3'];
            $HDN_TH3=$_POST['HDN_TH-3'];
            $array_TH3="($id,'$TH3','TH3','$HDN_TH3')";

            $F3=$_POST['F-3'];
            $HDN_F3=$_POST['HDN_F-3'];
            $array_F3="($id,'$F3','F3','$HDN_F3')";

            $S3=$_POST['S-3'];
            $HDN_S3=$_POST['HDN_S-3'];
            $array_S3="($id,'$S3','S3','$HDN_S3')";


            $M4=$_POST['M-4'];
            $HDN_M4=$_POST['HDN_M-4'];
            $array_M4="($id,'$M4','M4','$HDN_M4')";

            $T4=$_POST['T-4'];
            $HDN_T4=$_POST['HDN_T-4'];
            $array_T4="($id,'$T4','T4','$HDN_T4')";

            $W4=$_POST['W-4'];
            $HDN_W4=$_POST['HDN_W-4'];
            $array_W4="($id,'$W4','W4','$HDN_W4')";

            $TH4=$_POST['TH-4'];
            $HDN_TH4=$_POST['HDN_TH-4'];
            $array_TH4="($id,'$TH4','TH4','$HDN_TH4')";

            $F4=$_POST['F-4'];
            $HDN_F4=$_POST['HDN_F-4'];
            $array_F4="($id,'$F4','F4','$HDN_F4')";

            $S4=$_POST['S-4'];
            $HDN_S4=$_POST['HDN_S-4'];
            $array_S4="($id,'$S4','S4','$HDN_S4')";

            $values="$array_M9,$array_T9,$array_W9,$array_TH9,$array_F9,$array_S9,$array_M10,$array_T10,$array_W10,
            $array_TH10,$array_F10,$array_S10,$array_M11,$array_T11,$array_W11,$array_TH11,$array_F11,$array_S11,
            $array_M12,$array_T12,$array_W12,$array_TH12,$array_F12,$array_S12,
            $array_M2,
            $array_T2,$array_W2,$array_TH2,$array_F2,$array_S2,$array_M3,$array_T3,$array_W3,$array_TH3,$array_F3,$array_S3
            ,$array_M4,$array_T4,$array_W4,$array_TH4,$array_F4,$array_S4";

            $test_q="INSERT INTO tbl_batch_timetable ".$fields." VALUES ".$values;
            $this->db->runSQL("DELETE FROM tbl_batch_timetable WHERE batchid=".$id);
            if($this->db->runSQL("INSERT INTO tbl_batch_timetable ".$fields." VALUES ".$values))
            {
                Controller::$view['message'] = "Time Table created.";
            } else {
                // Controller::$view['message'] = "Error! please try later";
                Controller::$view['message'] = $test_q;
            }







            //Controller::$view['message']="Paper Assign";
        }
        Controller::$view['title']="Edit Time Table";

        Controller::$view['batch'] = $this->db->Fetch("*", "tbl_batches", "WHERE id='$id'");
        $acc_session_id=Controller::$view['batch']['acc_session_id'];
        Controller::$view['academic_session']=$this->db->Fetch("*", "tbl_academic_session", "WHERE id='$acc_session_id'");

        Controller::$view['timetable']=$this->db->FetchList("*","tbl_batch_timetable","WHERE batchid='$id' ");

        Controller::$view['papers_list']=$this->db->FetchList("*","tbl_papers","WHERE active='1' ");
        Controller::$view['faculty_list']=$this->db->FetchList("*","tbl_staff","WHERE active='1' ");

            if(Controller::$view['timetable']=="")
            {
               Controller::$view['assign_papers']="<option value= >--Select--</option>";

            }
        //Controller::$view['assign_papers']="<option value= >--Select--</option>";
        Controller::$view['assign_papers'].=$this->getOptions('paper_id,paper_title', 'view_assign_paper_batch', "WHERE active=1 AND batch_id=".$id);

        Controller::$view['assign_papers'].="<option value=N/A>N/A</option>
        <option value=Library>Library</option>
        <option value=PD>PD</option>";


        $this->view('edittimetable');
    }

    public function edit($id) {
        $this->checkPermission("edit");
        Controller::$view['title'] = "Edit Batch";
        if (isset($_POST['sub'])) {
            $title = trim($_POST['title']);
            $des = trim($_POST['des']);
            $start_date = trim($_POST['start_date']);
            $end_date = trim($_POST['end_date']);
            $c_status = $_POST['c_status'];

            $mons = array(1 => "Jan", 2 => "Feb", 3 => "Mar", 4 => "Apr", 5 => "May", 6 => "Jun", 7 => "Jul", 8 => "Aug", 9 => "Sep", 10 => "Oct", 11 => "Nov", 12 => "Dec");

            $f_month=explode("-",$start_date);
            $t_month=explode("-",$end_date);

            $f_month=intval($f_month[1]);
            $t_month=intval($t_month[1]);

            $total_mo="";
            if($f_month > $t_month) {
                for($i=$f_month;$i<=12;$i++){
                    $total_mo.=$mons[$i].",";
                }
                for($i=1;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            } else {
                for($i=$f_month;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            }



            $f = array('title', 'des', 'start_date', 'end_date', 'c_status');
            $v = array($title, $des, $start_date, $end_date, $c_status);
            $f = $this->db->Update($this->tbl, $f, $v, 'id', $id);
            if ($f == true) {
                Controller::$view['message'] = 'Record updated.';
            }
        }
        if(isset($_POST['paper_assign']))
        {
            $a="";

            //Controller::$view['message'] ="Paper Assign";
            $papers=$_POST['papers'];

            foreach ($papers as $key) {
                //$i++;
                $a.= $key.",";
            }
        Controller::$view['message'].=$a;
        }
        Controller::$view['batch'] = $this->db->Fetch("*", "tbl_batches", "WHERE id='$id'");
        $course_id=Controller::$view['batch']['course_id'];
        //Controller::$view['message']=$course_id;
        Controller::$view['id'] = $id;
        Controller::$view['assign_papers']=$this->getOptions('paper_id,paper_title', 'view_assign_paper_batch', "WHERE active=1 AND batch_id=".$id);
        Controller::$view['assign_papers_list']=$this->db->FetchList("paper_id","view_assign_paper_batch","WHERE active=1 AND batch_id=".$id);
        Controller::$view['photo'] = URL . 'public/images/loader.gif';
        //Controller::$view['message']=Controller::$view['assign_papers_list'];
        $pa="";
        foreach(Controller::$view['assign_papers_list'] as $p)
        {
            $pa.=$p['paper_id'].",";
        }
        $pa=rtrim($pa,',');
        if($pa=="")
        {
            $pa=0;
        }
        Controller::$view['papers']=$this->getOptions('id,title', 'tbl_papers', "WHERE active=1 AND course_id='$course_id' AND id NOT IN ( $pa) ");

        //Controller::$view['message']=$pa;
        $this->view('editbatch');
    }


}
