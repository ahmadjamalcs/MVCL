<?php
class attendancemarksync extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("attendancemarksync", "id");
    }

    public function index()
    {
        Controller::$view['title'] = "Attendance Marks Sync";
        $batches_list=$this->db->FetchList('*','tbl_batches',"WHERE active=1");
        $from='2016-08-16';
        $to='2017-01-17';
        foreach ($batches_list as $batches)
        {
            $batch_id=$batches['id'];
            $batch_sem=$batches['sem'];

            $paper_list=$this->db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' ");
            $student_list=$this->db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");

            foreach($paper_list as $papers)
            {
                $paper_id=$papers['paper_id'];
                $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
                $number_of_classes=$number_of_classes_count['date'];


                Controller::$view['paper_list'].=$papers['paper_title']." (".$number_of_classes.")";

            }

            foreach($student_list as $students)
            {
                $reg_date=$students['registration_date'];

                $total_num_of_classess=0;
                $attend_class=0;
                foreach($paper_list as $papers)
                {
                    $paper_id=$papers['paper_id'];
                    $std_regn=$students['std_regn'];

                    if($batch_sem=='1')
                    {
                        $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");
                        $number_of_classes=$number_of_classes_count['date'];
                    }
                    else{
                        $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND att_datetime >= '$from' AND att_datetime <= '$to' ");
                        $number_of_classes=$number_of_classes_count['date'];

                    }


                    $total_num_of_classess=$total_num_of_classess+$number_of_classes;
                    $attendance_array=$this->db->FetchList("*",'tbl_attendance',"WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND std_regn='$std_regn' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");

                    $absent=0;
                    $persent=0;
                    $j=0;
                    foreach($attendance_array as $attendance)
                    {
                        if($attendance['absent']==0)
                            $persent++;
                        elseif($attendance['absent']==1)
                            $absent++;
                        $j++;


                    }
                    $attend_class=$attend_class+$persent;

                    $persentage = round((($persent / $number_of_classes) * 100), 0);

                    $attendance = 0;
                    switch ($persentage) {
                        case $persentage >= 96:
                            $attendance = 5;
                            break;
                        case ($persentage <= 95 && $persentage >= 91):
                            $attendance = 4;
                            break;
                        case ($persentage <= 90 && $persentage >= 86):
                            $attendance = 3;
                            break;
                        case ($persentage <= 85 && $persentage >= 81):
                            $attendance = 2;
                            break;
                        case ($persentage <= 80 && $persentage >= 76):
                            $attendance = 1;
                            break;
                        default:
                            $attendance = 0;
                    }
                    Controller::$view['batches_list'].=$persentage." - ";
                    $this->db->runSQL("UPDATE tbl_marks SET `attendance`='$attendance' WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND std_regn='$std_regn' ");
                }
            }

            
            
           // Controller::$view['batches_list'].=$batches['id']." - ";
            
        }
        
        $this->view('attendancemarksync');

    }
}
