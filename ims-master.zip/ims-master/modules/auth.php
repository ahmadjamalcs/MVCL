<?php
class Auth extends Controller {

    function __construct() {
        parent::__construct();
    }
    public function index(){
        header('location: ' . URL.'auth/login' );
    }
    public function login(){
        Session::init();
        //Session::set('login',false);
        $logged = Session::get('login');
        if ($logged == TRUE) {
            header('location: ' . URL );
            exit;
        }
        Controller::$view['title']="Staff Login | ".COMPANY;
       if(isset($_POST['sub'])){
            $user=$this->db->realScape(trim($_POST['username']));
            $user=strip_tags($user);
            $pass=trim($_POST['password']);
            $pass=strip_tags($pass);
	        $pass=sha1($pass);
            
            Controller::$view['pass=']=$pass;
            $fields="id, role_id, username, name";
            $table="view_users";
            $qry="WHERE username=? AND password=? AND active=?";
            $values=array($user,$pass,1);
            $u=$this->db->pdoFetch($fields,$table,$qry,$values);
            if(isset($u['username'])){
            Session::init();
            Session::ResetId();
            $f=array('username','user_id','ip','session_id','date','in_time');
            $v=array($u['username'],$u['id'],$_SERVER['REMOTE_ADDR'], Session::id(),  $this->getdate(),  $this->gettime());
            $this->db->Insert('tbl_session', $f, $v);
            Session::set('login', true);
            Session::set('user', $u['username']);
            Session::set('name', $u['name']);

            Session::set('role_id', $u['role_id']);
            Session::set('user_id', $u['id']);
            Session::set('page', 0);
            Session::set('order', "");
            Session::set('condition', "");
            Session::set('find', "");

           if($u['role_id']==170) {
                Session::set('profileLink',"editstudent");
                Session::set('photo',"public/student_photos/");
                header('Location: '.URL."studentindex");
            } else {
                
                Session::set('profileLink','editstaff');
                Session::set('photo',"public/staff_photos/");
                  if(empty($_POST['g-recaptcha-response']))
                    {
                        $error = 'Captcha is required';
                    }
                    else
                    {

                        $secret_key = SECRET_KEY;

                        $response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret_key.'&response='.$_POST['g-recaptcha-response']);

                        $response_data = json_decode($response);
                        header('Location: '.URL);
                        if(!$response_data->success)
                        {
                            $error= 'Captcha verification failed';
                        }
                    }
            }
            //header('Location: '.URL);
        } else
            {
					// database entry for wrong credential.
				    Controller::$view['message'].="Login Failed!";
			}	
        }
       Controller::$view['SITE_KEY']=SITE_KEY;
       $this->view('stafflogin');
    }

    public function studentlogin(){
        Session::init();
        $logged = Session::get('login');
        if ($logged == TRUE) {
            header('location: ' . URL );
            exit;
        }
        Controller::$view['title']=" Student Login | ".COMPANY;
        if(isset($_POST['sub'])){
            
              $user=$this->db->realScape(trim($_POST['username']));
            $user=strip_tags($user);
            //$user=stripslashes($user);
            $pass=trim($_POST['password']);
            $pass=strip_tags($pass);
            //$pass=stripslashes($pass);
            
            $pass=sha1($pass);
            $f="id, role_id, username";
            $c="WHERE username='$user' AND password='$pass' AND active=1 AND role_active=1 AND role_id=158 LIMIT 0,1";
            $u=$this->db->Fetch($f, 'view_users',$c);
            if(isset($u['username'])){
                Session::init();
                Session::ResetId();
                $f=array('username','user_id','ip','session_id','date','in_time');
                $v=array($u['username'],$u['id'],$_SERVER['REMOTE_ADDR'], Session::id(),  $this->getdate(),  $this->gettime());
                $this->db->Insert('tbl_session', $f, $v);
                Session::set('login', true);
                Session::set('user', $u['username']);
                Session::set('name', $u['username']);
                Session::set('role_id', $u['role_id']);
                Session::set('user_id', $u['id']);
                Session::set('page', 0);
                Session::set('order', "");
                Session::set('condition', "");
                Session::set('find', "");
                header('Location: '.URL);
            } else
            {
                Controller::$view['message']="Login Failed!";
            }
        }
        $this->view('login');
    }

    public function forgotpassword(){
        Session::init();
        $logged = Session::get('login');
        if ($logged == TRUE) {
            header('location: ' . URL);
            exit;
        }
        Controller::$view['title'] = "Recover password | " . COMPANY;
        if(isset($_POST['pass']) && ($_SERVER['HTTP_REFERER'] == URL.'auth/forgotpassword')) {
            $email = $this->filterText($_POST['email']);
            $f = "id,email,name,username";
            $c = "WHERE email='$email' AND active=1 AND role_active=1 LIMIT 0,1";
            $u = $this->db->Fetch($f, 'view_users', $c);
            if(isset($u['email']) && $u['email']==$email) {
                $id=$u['id'];
                $pass = $this->get_Password();
                $f = array('password');
                $v = array(sha1($pass));
                $this->db->Update("tbl_users",$f,$v,'id',$id);

                $body = "Dear " . $u['name'] . ",<br><br>";
                $body .= "Here is your new login information:<br><br>";
                $body .= "Username : " . $u['username'] . "<br><br>";
                $body .= "Password : " . $pass . "<br><br>";
                $body .= "Please visit ".URL."auth/login to login.<br>";
                $body .= "You can change your password after logging in to your account.";
                $body .= "<br>-----------<br>Thanks and Regards,<br>The Glocal University";
                if ($this->sendEmail($email, "Password Recovery", $body)) {
                    Controller::$view['message']="Your new password has been sent to your email address.<br/>
                    <small>Note: Please check your junk/spam folder too.</small>";
                }

            } else {
                Controller::$view['message']="Invalid email address";
            }
        }
        $this->view("forgotpassword");
    }

    public function register()
    {
        Session::init();
        $logged = Session::get('login');
        if ($logged == TRUE) {
            header('location: ' . URL);
            exit;
        }

        Controller::$view['title'] = "User Registration | " . COMPANY;
        /*require_once(ROOT.'libs/captcha/securimage.php');
        Controller::$view['captcha']=Securimage::getCaptchaHtml();
        $image=new Securimage();*/




        if (isset($_POST['register']) && ($_SERVER['HTTP_REFERER'] == URL.'auth/register')) {

            /*if($image->check($_POST['captcha_code']) == false) {
                Controller::$view['message']="Incorrect security key.";
                $this->view("register");
                exit;
            }*/

            $card_id = $this->filterText($_POST['card_id']);
            $std_regn = $this->filterText($_POST['std_regn']);

            $ch = $this->db->Fetch("card_id", "test1", "WHERE card_id='$card_id' AND en='$std_regn'");
            if (!isset($ch['card_id']) || $ch['card_id'] == "") {
                Controller::$view['message'] = "Invalid Card ID/Enrollment no., please type another.";
            } else {

                $name = $this->filterText($_POST['name']);
                $email = $this->filterText($_POST['email']);
                $mobile = $this->filterText($_POST['mobile']);

                $pass = $this->get_Password();

                $f = array('name', 'email', 'username', 'password','phone', 'active','usertype', 'role_id', 'date');
                $v = array($name, $email, $std_regn, sha1($pass),$mobile, 1,'Student', 158, $this->getdate());
                $this->db->Insert("tbl_users", $f, $v);

                $body = "Dear " . $name . ",<br><br>";
                $body .= "Thank you for registering with AMU InfoSys, you can now login with the details given below : <br><br>";
                $body .= "Username : " . $std_regn . "<br><br>";
                $body .= "Password : " . $pass . "<br><br>";
                $body .= "Please visit ".URL."auth/login to login.<br>";
                $body .= "You can change your password after logging in to your account.";
                $body .= "<br>-----------<br>Thanks and Regards,<br>AMU InfoSys";
                if ($this->sendEmail($email, "Your Password", $body)) {
                    Controller::$view['title']="Registration Successful.";
                    Controller::$view['message'] = "Thank you $name, your registration is successful, your login details have been sent to your email address.<br />
                    <small>Note: Please check your junk/spam folder too.</small>";
                    $this->view('registered');
                    return;
                } else {
                    Controller::$view['message'] = "There is an error, please try again.";
                    $this->view('register');
                    return;
                }
            }
        }

        $this->view('register');
    }

    private function filterText($str)
    {
        return stripslashes(strip_tags(trim($str)));
    }

    public function logout(){
        Session::init();
        $this->db->Update('tbl_session',array('out_time'), array($this->gettime()), 'session_id', Session::id());
        Session::destroy();
	header('location: '.URL.'auth/login');
    }    
}
