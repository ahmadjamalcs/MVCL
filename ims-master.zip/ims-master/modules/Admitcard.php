<?php
class Admitcard extends Controller {
    private $tbl;

    function __construct() {
      
        parent::__construct();
        $this->CheckAuth();
        //$this->getPermissions("Accession", "acc_num");
       // $this->tbl = "tbl_book_master";
    }

    private function checkFileExtension($ext)
    {
        if ($ext == 'csv') {
            return 1;
        } else {
            return 0;
        }
    }
    private function uploadDoc($new_name="temp"){

        $filename = $_FILES['a_doc']['name'];
        $ext = explode(".",$filename);
        $cnt=(count($ext)-1);
        $ext=$ext[$cnt];

        if($this->checkFileExtension($ext)==0) {
            Controller::$view['message']="Invalid file type.".$ext;
            return 0;
        }
        //return ROOT . 'public/student_photos/' . $name . '.jpg';
        //$this->file_name = 'public/marksheet/' . $new_name .".". $ext;

        return move_uploaded_file($_FILES['a_doc']['tmp_name'], $this->file_name);
    }
    public function index()
    {
        $this->Reset('Admitcard');
        Controller::$view['title'] = "Admit Card";
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");
        Controller::$view['Admitcard_genrator'] = "0";
        if (isset($_POST['btnsubmit'])) {
            Controller::$view['Admitcard_genrator'] = "1";
            $faculty_id = $_POST['faculty_id'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];
            $batch_id = $_POST['batch_id'];
            $limit=$_POST['limit'];
            $row = 1;
            Controller::$view['Student_list']=$this->db->FetchList("*", "view_active_students","WHERE batch_id='$batch_id' ORDER BY std_regn ASC $limit");
          }
        $this->view('Admitcard');
    }
//*********************
    public function GenratePDF($id) {
        $this->Reset('Accession');
        $this->checkPermission("edit");
        Controller::$view['title']="Edit Accession details";

        Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');
        if(isset($_POST['update']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $category_id=trim($_POST['category']);
            $book_type=trim($_POST['book_type']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($_POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            //$status="IN";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);

            $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                "book_num","pages","cost","bill_no","withdrawn_date","bill_date","remark");
            $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$remarks);
            $result = $this->db->Update($this->tbl, $f, $v, 'acc_num', $id);

            if ($result == true) {
                Controller::$view['message'] = 'Record updated.';
            }
            else
            {
                Controller::$view['message']=  'Error Occured';
            }

            Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
            Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');


        }


        $this->view('editbookacc');
    }
    public function edit($id) {
        $this->Reset('Accession');
        $this->checkPermission("edit");
        Controller::$view['title']="Edit Accession details";

        Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');
        if(isset($_POST['update']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $category_id=trim($_POST['category']);
            $book_type=trim($_POST['book_type']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($_POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            //$status="IN";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);

            $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                "book_num","pages","cost","bill_no","withdrawn_date","bill_date","remark");
            $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$remarks);
            $result = $this->db->Update($this->tbl, $f, $v, 'acc_num', $id);

            if ($result == true) {
                Controller::$view['message'] = 'Record updated.';
            }
            else
            {
                Controller::$view['message']=  'Error Occured';
            }

            Controller::$view['book_acc_details']=$this->db->Fetch("*", $this->tbl,"WHERE acc_num='$id'");
            Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');


        }


        $this->view('editbookacc');
    }

//*********************
    public function add() {
        $this->checkPermission("add");
        Controller::$view['title'] = "Add New Accession";
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');


        if(isset($_POST['add']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $book_type=trim($_POST['book_type']);
            $category_id=trim($_POST['category']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($_POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            $status="Available";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);

            $copies=trim($_POST['copies']);

            if($copies==1){
                $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                    "book_num","pages","cost","bill_no","withdrawn_date","bill_date","status","remark");
                $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                    $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$status,$remarks);

                $result= $this->db->Insert($this->tbl, $f, $v);

                if($result==True)
                {
                    Controller::$view['message']="Record Inserted. Accession Number is :".$acc_num;
                }
                else{
                    Controller::$view['message']="Error occured.";

                }
            }
            else{
                while($copies>0){

                    $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                        "book_num","pages","cost","bill_no","withdrawn_date","bill_date","status","remark");
                    $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                        $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$status,$remarks);

                    $result= $this->db->Insert($this->tbl, $f, $v);

                    if($result==True)
                    {
                        Controller::$view['message']="Record Inserted. Accession Number is :".$acc_num;
                    }
                    else{
                        Controller::$view['message']="Error occured.";

                    }
                    $acc_num++;
                    $copies--;
                }
            }


        }

        $this->view('addbookacc');
    }

//*********************

}

?>
