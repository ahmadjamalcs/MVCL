<?php
/*
// *************************************************************************
// *                                                                       *
// * Developed by HATAM Consultancy Services (P) LTD 
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: in@hatam.in                                                 *
// * Website: http://www.hatam.in                                         *
// *                                                                       *
// *************************************************************************
// * Date: 30/1/13
// * Time: 4:07 PM                                                                      *
// *************************************************************************/
?>
<?php require('header.php'); ?>
<h1><?=Controller::$view['title']?></h1>

<div class="content_item">
    <a href="<?=URL ?>mypaperlist" class="btn btn-round btn-success" style="float: right;" >Back </a>
          <center><b><?=Controller::printMessage()?></b></center><br/>

    <form id="form1" name="form1" method="post">
              <table width="100%" border="0">
                  <tr>
                      <td>Paper Code:</td>
                      <td>Paper Name</td>
                      <td>Batch Name</td>
                      <td>Date Time </td>
                  </tr>
                  <tr>
                  <th><?=Controller::$view['paper_details']['paper_code']?></th>
                  <th><?=Controller::$view['paper_details']['paper_title']?></th>
                  <th><?=Controller::$view['paper_details']['title']?></th>
                  <th><?= Controller::$view['current_date']?></th>
                  </tr>
              <input type="hidden" name="paper_id" value="<?=Controller::$view['paper_details']['paper_id']?>" />
                  <input type="hidden" name="batch_id" value="<?=Controller::$view['paper_details']['batch_id']?>" />
                  <input type="hidden" name="date" value="<?=Controller::$view['current_date']?>" />


              </table>
              </br>
<?php if(Controller::$view['flag']!=1)
{?>
              <table class="table table-bordered table-striped table-condensed">

                  <thead>
                  <tr>

                      <th>S.No.</th>
                      <th>Name</th>
                      <th>Roll Number</th>
                      <th>Absent</th>
                      <th>Remarks</th>
                      </tr>
                  </thead>

                  <?php
              $i=1;
              foreach (Controller::$view['students_list'] as $students)
              {
                  echo "<tr>";
                  echo "<td>".$i."</td>";
                  echo "<td>".$students['std_name']."</td>";
                  echo "<td>".$students['std_regn']."</td>";
                  echo "<input type='hidden' name=std_regn".$i." value=".$students['std_regn']." />";

                  echo "<td>
                  <input type=checkbox class=list-child name=attend".$i." value='1' />
                    </td>";
                  echo "<td>
                  <textarea name=remarks".$i." style='width:200px; height:30px' padding:0px; margin:0px;></textarea>
                  </td>";

                  $i++;
              }
                  $i--;
                echo "Number Of students : ".$i;
              ?>
              </table>
              <input type="hidden" name="number_of_students" value="<?=$i; ?>" />

              <input <?php
    if($i==0)
    {
        echo "disabled=disabled";
    }

    ?> type="submit" name="sub" id="sub" value="Submit" onclick="return del();" class="btn btn-primary btn-lg btn-block">
      <?php }else{
    $absent=Controller::$view['$total_students']['students']-Controller::$view['present_students']['studentsper'];
    ?>

    <h3>Todays Report</h3>
    <table class="table table-bordered table-striped table-condensed">
              <tr>
                  <th>Total Number of Students</th>
                  <th>Total Persent Students</th>
                  <th>Total Absent Students</th>
                  </tr>
                  <tr>
                      <td>
                          <?=Controller::$view['$total_students']['students'];?>
                      </td>
                      <td>
                          <?=Controller::$view['present_students']['studentsper']." (".round((Controller::$view['present_students']['studentsper']*100)/Controller::$view['$total_students']['students'],2)."%)"; ?>
                      </td>
                      <td>
                          <?=$absent."(".round(($absent*100)/Controller::$view['$total_students']['students'],2)."%)";
                          ?>
                      </td>
                  </tr>
              </table>
    <?php
}

?>
          </form>

      </div>
<?php require('footer.php'); ?>

