<?php
class Attendancereport extends Controller
{
    function __construct(){
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("attendancereport", "id");
    }
    public function index() {
        Controller::$view['title'] = "Attendance Report";
        Controller::$view['generate_button_click']=0;
        Controller::$view['report']="";
        Controller::$view['date'] = $this->getdate();

        $username=Session::get('user');
        $role_id=Session::get('role_id');
        $faculty_details=$this->db->Fetch("faculty_id",'tbl_staff',"where desg_code='HOS' AND staff_regn='$username' ");

        if($faculty_details==true AND $role_id!=1)
        {
            Controller::$view['flag']=$faculty_details['faculty_id'];
            $faculty_id=$faculty_details['faculty_id'];
            Controller::$view['flag']=1;
            Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1 AND faculty_id='$faculty_id' ");

        }
        else{
            if($role_id==1 OR $role_id==173 OR $role_id==195 OR $role_id==214 OR $role_id==216)
            {
                Controller::$view['flag']=1;
                Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");

            }
            else {
                Controller::$view['flag'] = 0;
            }
        }
        //Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1 AND faculty_id='$faculty_id' ");
        $this->view('att_report');
    
    }
    /*public function edit($id){
        Controller::$view['title']="Edit Lectures";
        if(isset($_POST['sub'])){
            $lectures = trim($_POST['lectures']);

            $f = array('l_month','lectures');
            $v = array($_POST['l_month'],$lectures);
            if($this->db->Update($this->tbl,$f,$v,'id',$id)){
                Controller::$view['message']="Record updated.";
            } else{Controller::$view['message']="There is an error, please try later.";}
        }
        Controller::$view['paper']=$this->db->Fetch("*", "view_lectures","WHERE id='$id'");
        Controller::$view['faculty']=$this->getOptions("faculty_id,faculty_name","tbl_faculty","WHERE active=1");
        $this->view('editlecture');
    }

    public function add() {
        $this->checkPermission("add");
        Controller::$view['title'] = "Add total lectures for a month";
        if (isset($_POST['add'])) {
            $paper_code = $_POST['paper_code'];
            $batch_id=$_POST['batch_id'];
            $cc=$this->db->Fetch("id", $this->tbl,"WHERE batch_id='$batch_id' AND paper_code='$paper_code' AND active='1'");
            if($cc['id']!=""){
                Controller::$view['message']="Lectures for this paper have already been created";
                Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', 'WHERE active=1');
                $this->view('addlecture');
                return;
            }


            $lectures = trim($_POST['lectures']);

            $f = array('paper_code','batch_id','lectures','l_month');
            $v = array($paper_code,$batch_id,$lectures,$_POST['l_month']);
            if($this->db->Insert($this->tbl, $f, $v)){
                Controller::$view['message'] = 'Lectures created.';
            } else {
                Controller::$view['message'] = 'There is an error.';
            }

        }
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', 'WHERE active=1');
        $this->view('addlecture');
    }*/
}

