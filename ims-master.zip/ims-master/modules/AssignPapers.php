<?php

class AssignPapers extends Controller {

    private $tbl;

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("AssignPapers", "staff_regn");
        $this->tbl = "tbl_staff";
    }

    public function index() {

      //  $this->Reset('AssignPapers');

        if(fnmatch(URL."AssignPapers/edit/*",$_SERVER['HTTP_REFERER'])!=true){
            $this->Reset('AssignPapers');
        }

        Controller::$view['title'] = "List of Staff";


//********************************
        if(isset($_POST['del_sub'])){
            $this->checkPermission("del");
            Controller::$view['message']="Delete function is disabled for now";
        }
        if(isset($_POST['publish'])){
            $this->checkPermission("edit");
            Controller::$view['message']=$this->Activate($this->tbl, 'staff_regn');
        }
        if(isset($_POST['unpublish'])){
            $this->checkPermission("edit");
            Controller::$view['message']=$this->deActivate($this->tbl, 'staff_regn');
        }
        $t = array('HR No.','Title','Name','Gender','Cat.','Designation','Office/Dept');
        $f = array('staff_regn','staff_title','staff_name','staff_sex','category','desg_code','dept_id');
        Controller::$view['grid'] = $this->db->GetRecords($t, $f, 'tbl_staff', $this->link['expre'],$this->link['add'], false, $this->link['edit'], FALSE, TRUE, $this->link['publish'], array('Enabled', 'active'),false);

        $this->view();
    }

    public function add() {
        $this->checkPermission("add");
        if (isset($_POST['btnsubmit'])) {
            $title = trim($_POST['title']);

            $faculty_id = $_POST['faculty_id'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];
            $start_date = trim($_POST['start_date']);
            $end_date = trim($_POST['end_date']);
            $acc_session_id = trim($_POST['acc_session_id']);
            $section = $_POST['section'];
            $location = $_POST['location'];
            $c_status = $_POST['c_status'];
            $des = trim($_POST['des']);


            $mons = array(1 => "Jan", 2 => "Feb", 3 => "Mar", 4 => "Apr", 5 => "May", 6 => "Jun", 7 => "Jul", 8 => "Aug", 9 => "Sep", 10 => "Oct", 11 => "Nov", 12 => "Dec");

            $f_month=explode("-",$start_date);
            $t_month=explode("-",$end_date);

            $f_month=intval($f_month[1]);
            $t_month=intval($t_month[1]);

            $total_mo="";
            if($f_month > $t_month) {
                for($i=$f_month;$i<=12;$i++){
                    $total_mo.=$mons[$i].",";
                }
                for($i=1;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            } else {
                for($i=$f_month;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            }

            $t = array('title', 'des', 'faculty_id', 'dept_id', 'course_id', 'start_date', 'end_date','acc_session_id','section','location','c_status');
            $v = array($title, $des, $faculty_id, $dept_id, $course_id, $start_date, $end_date,$acc_session_id,$section,$location, $c_status);
            if ($this->db->Insert($this->tbl, $t, $v)) {
                Controller::$view['message'] = "Batch created.";
            } else {
                Controller::$view['message'] = "Error! please try later";
            }
        }

        Controller::$view['title'] = 'Create New Batch';
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");
        Controller::$view['acc_session']=$this->getOptions('id,session_name', 'tbl_academic_session', "WHERE active=1");
        $this->view('addbatch');
    }

    public function edit($id) {
        $this->checkPermission("edit");
        Controller::$view['title'] = "Assign Papers";


        if(isset($_POST['sub'])){
            $staff_regn = trim($_POST['staff_regn']);
            $staff_title=trim($_POST['staff_title']);
            $staff_name = trim($_POST['staff_name']);
            $staff_sex = trim($_POST['staff_sex']);
            $staff_father = trim($_POST['staff_father']);
            $staff_mother = trim($_POST['staff_mother']);
            $dob = trim($_POST['dob']);
            $staff_edqf = trim($_POST['staff_edqf']);
            $l_address = trim($_POST['l_address']);
            $h_address = trim($_POST['h_address']);
            $city = trim($_POST['city']);
            $state = trim($_POST['state']);
            $ph_mobile = trim($_POST['ph_mobile']);
            $ph_home = trim($_POST['ph_home']);
            $email = trim($_POST['email']);
            $religion=trim($_POST['religion']);
            $sunni_shia=trim($_POST['sunni_shia']);
            $cast=trim($_POST['cast']);
            $staff_cat=trim($_POST['staff_cat']);
            $disable=trim($_POST['disable']);
            $url = trim($_POST['url']);
            //$cat = trim($_POST['cat']);

            $f = array('staff_title', 'staff_name', 'staff_sex','dob','staff_edqf', 'staff_father', 'staff_mother', 'l_address', 'h_address', 'city', 'state', 'ph_mobile', 'ph_home', 'email','religion','sunni_shia','cast','staff_cat','disable','url','registration_date');
//echo $staff_title, $staff_name, $staff_sex, $dob, $staff_edqf, $staff_father,$l_address,$h_address, $city, $state, $ph_mobile, $ph_home, $email;
            $v = array($staff_title, $staff_name, $staff_sex, $dob, $staff_edqf, $staff_father, $staff_mother, $l_address,$h_address, $city, $state, $ph_mobile, $ph_home, $email, $religion, $sunni_shia, $cast, $staff_cat, $disable, $url, $registration_date);
            $r1 = $this->db->Update($this->tbl, $f, $v, "staff_regn", $id);
            if ($r1 == TRUE) {
                Controller::$view['message'] = "Record Updated Successfully.";
            } else{Controller::$view['message']="There's an error, please try later.";
            }
        }
        Controller::$view['stu']=$this->db->Fetch("*", 'view_tstaff',"WHERE staff_regn='$id'");

        Controller::$view['staffcategory'] = $this->getOptions('cat_code,category', 'tbl_staffdsgncategory');
        Controller::$view['stu'] = $this->db->Fetch("*", 'tbl_staff', "WHERE staff_regn='$id'");
        Controller::$view['design'] = $this->db->FetchList("*", "tbl_staffdesignheld", "WHERE staff_regn='$id' AND
         ds_active ORDER BY id DESC");

        if (isset($_POST['sub'])) {
            $title = trim($_POST['title']);
            $des = trim($_POST['des']);
            $start_date = trim($_POST['start_date']);
            $end_date = trim($_POST['end_date']);
            $c_status = $_POST['c_status'];

            $mons = array(1 => "Jan", 2 => "Feb", 3 => "Mar", 4 => "Apr", 5 => "May", 6 => "Jun", 7 => "Jul", 8 => "Aug", 9 => "Sep", 10 => "Oct", 11 => "Nov", 12 => "Dec");

            $f_month=explode("-",$start_date);
            $t_month=explode("-",$end_date);

            $f_month=intval($f_month[1]);
            $t_month=intval($t_month[1]);

            $total_mo="";
            if($f_month > $t_month) {
                for($i=$f_month;$i<=12;$i++){
                    $total_mo.=$mons[$i].",";
                }
                for($i=1;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            } else {
                for($i=$f_month;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            }



            $f = array('title', 'des', 'start_date', 'end_date', 'c_status');
            $v = array($title, $des, $start_date, $end_date, $c_status);
            $f = $this->db->Update($this->tbl, $f, $v, 'id', $id);
            if ($f == true) {
                Controller::$view['message'] = 'Record updated.';
            }
        }
        if(isset($_POST['paper_assign']))
        {
            $a="";
            //Controller::$view['message'] ="Paper Assign";
            $papers=$_POST['papers'];

            foreach ($papers as $key) {
                //$i++;
                $a.= $key.",";
            }
        Controller::$view['message'].=$a;
        }
        Controller::$view['papers']=$this->getOptions('id,title', 'tbl_papers', "WHERE active=1");
       Controller::$view['assign_papers']=$this->getOptions_papers('paper_id,paper_title,batch_id,title', 'view_assign_paper_staff', "WHERE staff_id='$id'");
        //Controller::$view['assign_papers']=$this->getOptions('paper_id,paper_title', 'view_assign_paper_staff', "WHERE staff_id='$id'");
        //Controller::$view['assign_papers']="aHMAD";
        $staff_school_id=Controller::$view['stu']['faculty_id'];
        if($staff_school_id=='NONE' || $staff_school_id=='NT')
        {
		Controller::$view['batches']=$this->getOptions('id,title', 'tbl_batches', "WHERE active=1");
		}
		else{
        Controller::$view['batches']=$this->getOptions('id,title', 'tbl_batches', "WHERE active=1 AND faculty_id='$staff_school_id'");
		}
        $this->view('editassignpapers');
    }

    public function batchgroups($batchid) {
        $this->checkPermission("edit");
        if (isset($_POST['del_group'])) {
            if (!isset($_POST['id'])) {
                Controller::$view['message'] = "Please select atleast one record.";
            } else {
                $checkbox = $_POST['id'];
                $countCheck = count($_POST['id']);
                for ($i = 0; $i < $countCheck; $i++) {
                    $id = $checkbox[$i];
                    $flag = $this->db->Delete("tbl_batchgroup", 'id', $id);
                }
                if ($flag == FALSE) {
                    Controller::$view['message'] = "There is an error";
                } else {
                    Controller::$view['message'] = $countCheck . ' group(s) unassigned from this batch.';
                }
            }
        }
        if (isset($_POST['as_group'])) {
            if (!isset($_POST['id'])) {
                Controller::$view['message'] = "Please select atleast one record.";
            } else {
                $checkbox = $_POST['id'];
                $countCheck = count($_POST['id']);
                for ($i = 0; $i < $countCheck; $i++) {
                    $id = $checkbox[$i];
                    $flag = $this->db->Insert("tbl_batchgroup", array('batch_id', 'group_id'), array($batchid, $id));
                }
                if ($flag == FALSE) {
                    Controller::$view['message'] = "There is an error";
                } else {
                    Controller::$view['message'] = $countCheck . ' group(s) assigned to this batch.';
                }
            }
        }
        Controller::$view['title'] = "Batch Groups";
        Controller::$view['batch'] = $this->db->Fetch("*", "view_batches", "WHERE id='$batchid'");
        $dept_id = Controller::$view['batch']['dept_id'];
        $gg = $this->db->FetchList("*", "tbl_papergroups", "WHERE active=1 AND dept_id='$dept_id'");
        Controller::$view['gr'] = '';        Controller::$view['i']=0;
        foreach ($gg as $g) {
            if ($this->db->countRecords("id","tbl_batchgroup","WHERE batch_id='$batchid' AND group_id='".$g['id']."'") < 1) {
                Controller::$view['i']++;
                Controller::$view['gr'].='<tr>
                        <td><input type="checkbox" name="id[]" value="' . $g['id'] . '" /></td>
                        <td>' . $g['title'] . '</td>
                        <td>' . $g['remarks'] . '</td>
                    </tr>';
            }
        }


        Controller::$view['gr2'] = $this->db->FetchList("*", "view_batchgroup", "WHERE batch_id='$batchid'");

        $this->view('batchgroups');
    }

    public function batchstudents($batchid) {
        $this->checkPermission("edit");
        if (isset($_POST['del_stu'])) {
            if (!isset($_POST['id'])) {
                Controller::$view['message'] = "Please select atleast one record.";
            } else {
                $checkbox = $_POST['id'];
                $countCheck = count($_POST['id']);
                for ($i = 0; $i < $countCheck; $i++) {
                    $id = $checkbox[$i];
                    $flag = $this->db->Delete("tbl_batchstudent", 'id', $id);
                }
                if ($flag == FALSE) {
                    Controller::$view['message'] = "There is an error";
                } else {
                    Controller::$view['message'] = $countCheck . ' student(s) unassigned from this batch.';
                }
            }
        }
        if (isset($_POST['as_stu'])) {
            if (!isset($_POST['id'])) {
                Controller::$view['message'] = "Please select atleast one record.";
            } else {
                $checkbox = $_POST['id'];
                $countCheck = count($_POST['id']);
                for ($i = 0; $i < $countCheck; $i++) {
                    $id = $checkbox[$i];
                    $flag = $this->db->Insert("tbl_batchstudent", array('batch_id', 'st_id'), array($batchid, $id));
                }
                if ($flag == FALSE) {
                    Controller::$view['message'] = "There is an error";
                } else {
                    Controller::$view['message'] = $countCheck . ' student(s) assigned to this batch.';
                }
            }
        }
        Controller::$view['batch'] = $this->db->Fetch("*", "view_batches", "WHERE id='$batchid'");
        $course_id = Controller::$view['batch']['course_id'];
        $gg = $this->db->FetchList("*", "view_studentcourses", "WHERE active=1 AND course_id='$course_id' AND c_status <> 'Archive' ORDER BY courseyear");
        Controller::$view['gr'] = ''; Controller::$view['i']=0;
        foreach ($gg as $g) {
            if ($this->db->countRecords("id","tbl_batchstudent","WHERE st_id='".$g['id']."'") < 1) {
                Controller::$view['i']++;
                Controller::$view['gr'].='<tr>
                        <td><input type="checkbox" name="id[]" value="' . $g['id'] . '" /></td>
                        <td>' . $g['std_regn'] . '</td>
                        <td>' . $g['name'] . '</td>
                        <td>' . $g['gender'] . '</td>
                        <td>' . $g['faculty_id'] . '</td>
                        <td>' . $g['faculty_no'] . '</td>
                        <td>' . $g['dept_id'] . '</td>
                        <td>' . $g['course_id'] . '</td>
                        <td>' . $g['courseyear'] . '</td>
                    </tr>';
            }
        }


        Controller::$view['st2'] = $this->db->FetchList("*", "view_batchstudent", "WHERE batch_id='$batchid' ORDER BY year");
        Controller::$view['title'] = "Batch students";
        $this->view('batchstudents');
    }

}
