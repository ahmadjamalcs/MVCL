<?php

class ayur_idcard extends Controller {

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("Idcard", "id");
    }
    public function index()
    {
        $recordSet=$this->db->FetchList("*","tbl_ayurveda_staff","WHERE printed=0 ORDER BY id");

        //echo $recordSet;


        require_once(ROOT . 'libs/fpdf/fpdf.php');
        //$p = array(5.5, 8.5);
        //$pdf = new FPDF(P, cm, $p);
        $p = array(5.5, 8.5);
        $pdf = new FPDF('P', 'cm', $p);
        $pdf->SetMargins(0, 0, 0, 0);

        //Front Page



        foreach ($recordSet as $r){
            $pdf->AddPage();
            $pdf->SetAutoPageBreak(0);


            //Rectangle
            $pdf->Rect(.2,.2,5.1,8.1);

            $pdf->Image(ROOT.'skins/'.SKIN.'/assets/img/bams.jpg', .60,.3,4.3);
            $pdf->Image($this->getPhoto($r['HR-NO']), 1.5, 1.9,2.5,3);


            $pdf->Rect(1.5, 1.9,2.5,3);
            $pdf->SetFont('Times', 'B', 11);
            $pdf->SetXY(.2, 5.3);
            $pdf->Cell(5.1,0,$r['NAME'],0,0,'C');
            $pdf->SetFont('Times', '', 10);
            $pdf->SetXY(.2, 5.7);
            $pdf->MultiCell(0,.3,'Emp. Code : '.$r['HR-NO'],0,'C');
            $pdf->SetFont('Times', 'B', 10);
            $pdf->SetXY(.2, 6.2);
            $pdf->MultiCell(0,.3,$r['Designation'],0,'C');
            $pdf->SetFont('Times', '', 10);

            $pdf->SetXY(.2, 6.6);
            $pdf->MultiCell(0,.3,$r['Department'],0,'C');

            $pdf->SetFont('Times', 'B', 7);
           $pdf->Image(ROOT.'public/Ayur_sign.jpg', 2.1, 7.1  ,1.3,.84);
           // $pdf->Image(ROOT.'public/khan.jpg', .5, 7.0  ,1.3,.84);
           // $pdf->Image(ROOT.'public/staff_sign/'.$r['staff_regn'].'.jpg', 3.4, 7.0 ,1.6,.84);

            $pdf->SetXY(.2, 7.5);
            //$pdf->Cell(5.1,0,':',0,0);

            $pdf->SetXY(2.2, 8.0);

            $pdf->Cell(5.1,0,'Principal',0,0);
            $pdf->SetXY(3.7, 8.0);

            //$pdf->Cell(5.1,0,'Employee',0,0);


            //Back Page

            $pdf->AddPage();
            $pdf->SetAutoPageBreak(0);
            //Rectangle
            $pdf->Rect(.2,.2,5.1,8.1);

            $pdf->Line(.2,3.4,5.3,3.4);


            $pdf->SetFont('Times', '', 7.5);
            $pdf->SetXY(.2, .5);
            $date_of_joining=date_format($r['joining-date'],'d/m/Y');
            $pdf->Cell(5.1,0,'Date of Joining   : '.$r['Date of Joining'],0,0);

            $pdf->SetXY(.2,.8);
            $pdf->Cell(5.1,0,'Blood Group       : '.$r['Blood Group'],0,0);

            $pdf->SetXY(.2, 1.1);
            $pdf->Cell(5.1,0,'Father\'s Name    : '.$r['Father Name'],0,0);

            $pdf->SetXY(.2, 1.4);
            $pdf->Cell(5.1,0,'Date of Birth       : '.$r['Date Of Birth'],0,0);

            $pdf->SetXY(.2, 1.7);
            //$pdf->Cell(5.1,0,'Address: ',0,0);

            $str_c=str_word_count($r['Address']);
            $stu_address=explode(' ',$r['Address']);
            $count=count($stu_address);
            $str_c1=ceil($count/2);
            $str_c2=$count-$str_c1;
            $i=0;
            $add="";
            while($i<$str_c1)
            {
                $add.=$stu_address[$i];
                $add.=" ";
                $i++;
            }
            $pdf->Cell(5.1,0,'Address: ',0,1);
            $pdf->SetXY(.5, 2.0);
            $pdf->Cell(5.1,0,$add,0,0);


            $add="";
            while($i<=$count)
            {
                $add.=$stu_address[$i];
                $add.=" ";
                $i++;
            }
            $pdf->SetXY(.5, 2.3);
            $pdf->Cell(5.1,0,''.$add,0,0);

            $pdf->SetXY(.2, 2.6);
            $pdf->Cell(5.1,0,'Email : '.$r['E-mail ID'],0,0);

            $pdf->SetXY(.2, 2.9);
            $pdf->Cell(5.1,0,'Contact                : '.$r['Mobile No.'],0,0);


            $pdf->SetXY(.2, 3.2);
       //     $pdf->Cell(5.1,0,'Emergency No.   : '.$r['Emergency Contact'],0,0);


         //   $pdf->Image(ROOT.'skins/'.SKIN.'/assets/img/unani_logo.jpg', .95,3.5,3.1);

            $pdf->SetFont('Times', '', 7.7);
            $pdf->SetXY(.2, 3.8);
            $pdf->Cell(5.1,0,'-This card is property of Glocal University',0,0);

            $pdf->SetXY(.2, 4.3);
            $pdf->Cell(5.1,0,'-If this card is found, kindly return to: ',0,0);
            $pdf->SetFont('Times', 'B', 7.7);
            $pdf->SetXY(.2, 4.8);
            $pdf->Cell(5.1,0,' "Registrar Office" ',0,0,'C');

            $pdf->SetXY(.2, 5.3);
            $pdf->Cell(5.1,0,'Glocal University',0,0,'C');


            $pdf->SetXY(.2, 5.8);
            $pdf->Cell(5.1,0,'Delhi-Yamunotri Marg (State Highway 57),',0,0,'C');


            $pdf->SetXY(.2, 6.3);
            $pdf->Cell(5.1,0,'Mirzapur Pole, Distt. Saharanpur',0,0,'C');

            $pdf->SetXY(.2, 6.8);
            $pdf->Cell(5.1,0,'U.P.247121, INDIA',0,0,'C');

            $pdf->SetFont('Times', '', 8);

            $pdf->SetXY(.2, 7.2);
            $pdf->Cell(5.1,0,'Enquiries :',0,0,'C');

            $pdf->SetXY(.2, 7.5);
            $pdf->Cell(5.1,0,'(91) 8392939379, 8392939343',0,0,'C');

            $pdf->SetXY(.2, 7.8);
            $pdf->Cell(5.1,0,'Enquiries: 0132-2614500',0,0,'C');

        }

        $pdf->Output();
    }
    private function getPhoto($id) {
        if (file_exists(ROOT . 'public/unani_staff_photo/' . trim($id) . '.jpg')) {
            return URL . 'public/unani_staff_photo/' . trim($id) . '.jpg';
        }elseif (file_exists(ROOT . 'public/unani_staff_photo/' . trim($id) . '.png')) {
            return URL . 'public/unani_staff_photo/' . trim($id) . '.png';
        }elseif (file_exists(ROOT . 'public/unani_staff_photo/' . trim($id) . '.JPG')) {
            return URL . 'public/unani_staff_photo/' . trim($id) . '.JPG';
        }
         else {
            return URL . 'public/ayur_staff_photo/m.jpg';
        }
    }

    public function generate(){
        if(isset($_POST['btnsubmit'])) {


        }
    }
}
