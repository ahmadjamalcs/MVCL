<?php
class api extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("api", "id");
    }

    public function finalMarks($stdRegn, $paperId, $batchId, $groupId, $dash = true)
    {
        // function to calculate the final marks of student.
        $db = new Database();
        $extractValue = "Total";
        $marks = $db->Fetch("*", "tbl_marks", "WHERE batch_id='$batchId' AND std_regn='$stdRegn' AND paper_id='$paperId' AND group_id='$groupId' ");
        if ($marks == false && $dash == false) {
            $paperData = $db->Fetch("*", "tbl_papers", "WHERE id='$paperId' LIMIT 0,1");
            $patternId = $paperData['marks_distribution_id'];
            $marksDistribution = $db->Fetch("*", "tbl_marksdistibutionpattern", "WHERE id='$patternId'");
            $marks['marks'] = $marksDistribution['pattern'];
        }
        $semMarksTotal = $this->jsonMarksTotal($marks['marks'], $extractValue);
        if ($marks['reCheckMarks'] != NULL)
            $reCheckMarksTotal = $this->jsonMarksTotal($marks['reCheckMarks'], $extractValue);
        if ($marks['repeatMarks1'] != NULL)
            $repeatMarks1Total = $this->jsonMarksTotal($marks['repeatMarks1'], $extractValue);
        if ($marks['reCheckMarks2'] != NULL)
            $repeatMarks2Total = $this->jsonMarksTotal($marks['repeatMarks2'], $extractValue);
        if ($marks['reCheckMarks3'] != NULL)
            $repeatMarks3Total = $this->jsonMarksTotal($marks['repeatMarks3'], $extractValue);
        $x = array(
            'marks' => $semMarksTotal,
            'reCheckMarks' => $reCheckMarksTotal,
            'repeatMarks1' => $repeatMarks1Total,
            'repeatMarks2' => $repeatMarks2Total,
            'repeatMarks3' => $repeatMarks3Total);

        reset($x);   // optional.
        arsort($x);

        $key = key($x);

        if ($key == 'marks' || $key == 'reCheckMarks' || $marks == false) {
            $extraValue = null;
        } else {
            $extraValue = "R";
        }
        return $marks[$key] . "-" . $extraValue;

        //    return $marks;

    }

    public function jsonMarksTotal($marks, $extractValue)
    {
        $pattern = json_decode($marks, true);
        if (!$pattern) {
            return 0;
        } else {
            return $pattern[$extractValue];
        }

    }

    public function index($std_regn)
    {



    }

    public function gradeCalculate($stdRegn)
    {
        $students = $this->db->Fetch("*", 'view_active_students', "WHERE std_regn='$stdRegn'");
        $student_school=$this->db->Fetch("*",'tbl_faculty',"WHERE faculty_id='$students[faculty_id]' ");
        $student_course=$this->db->Fetch("*",'tbl_courses',"WHERE course_id='$students[course_id]' ");
        $student_dept=$this->db->Fetch("*",'tbl_department',"WHERE dept_id='$student_course[dept_id]' ");
        $totalCredits=0;
        $totalOptainMarks=0;
        $paperIds=array();
        $totalMaxMarks=0;
        $subjectFields=array();
        $patternTotal=array();
        $credits=array();
        $batch_id=$students['batch_id'];
        $paper_list=$this->db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' order by category DESC, id DESC");

        $batch_details=$this->db->Fetch("*",'view_batches',"WHERE id='$batch_id' ");
        foreach($paper_list as $papers)
        {




            $paper_id=$papers['paper_id'];
            $marksDistributionId=$papers['marks_distribution_id'];
            $marksPattern=$this->db->Fetch("*","tbl_marksdistibutionpattern","WHERE id='$marksDistributionId'");
            $pattern = json_decode($marksPattern['pattern'],true);

            $numberofKeys=1;
            foreach($pattern as $key => $value)
            {
                $patternRow.="<th>".$key."</th>";
                array_push($patternRowCSV,$key);
                $numberofKeys++;
                if($key=='Total')
                {
                    $totalMaxMarks=$totalMaxMarks+$value;
                }
            }
            $nk=$numberofKeys;
            if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
            {
                $subjectHeadings=$paper_id."(".$papers['paper_code'].") ".$papers['paper_title']." :: ".$papers['credits']." Credits";

            }
            if($batch_details['gradingSystem']==3)
            {
                $subjectHeadings=$paper_id."(".$papers['paper_code'].") ".$papers['paper_title'];
                $content.=$papers['paper_title'];
                $nk--;
            }
            $subjectRow.="<td colspan=".$nk.">".$subjectHeadings."</td>";
            array_push($subjectRowCSV,$subjectHeadings);


            if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
            {

                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"");
                }

                $patternRow.="<th>"."Grade"."</th>";
                array_push($patternRowCSV,"Grade");
            }
            elseif($batch_details['gradingSystem']==3)
            {
                // blank row for 3rd coding system
                $numberofKeys--;
                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"");
                }
            }
            else{
                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"...");
                }
                $patternRow.="<th>"."Grading System Not Defined"."</th>";
                array_push($patternRowCSV,"Grading System Not Defined");
            }

            array_push($paperIds,$paper_id);
            array_push($subjectFields,$numberofKeys);
            array_push($patternTotal,$pattern['Total']);


            array_push($credits,$papers['credits']);


        }

        foreach ($paperIds as $paperId)
        {
            $flagCheck=0;
            $marksTotal=0;
            Controller::$view['message'].="paper".$paperId;
            $paperdetails=$this->db->Fetch("*","tbl_papers","WHERE id='$paperId'");
            $paperType=$paperdetails['type'];
            $content.="<tr>";
            $content.='<td align="center" >';
            $content.=$paperdetails['code'];

            $content.="</td>";
            $content.="<td>";
            $content.=$paperdetails['title'];

            $content.="</td>";
            $content.='<td align="center">';
            $content.=$paperdetails['credits'];

            $content.="</td>";

            $group_id=0;

            if($paperType=='E')
            {
                $flagCheck=1;
                $checkElective=$this->db->Fetch("*","tbl_electivePaperList","WHERE batch_id='$batch_id' AND std_regn='$stdRegn' AND paper_id='$paperId' AND group_id='$group_id'");

            }

            $selectMarksData=$this->db->Fetch("*","tbl_marks","WHERE batch_id='$batch_id' AND std_regn='$stdRegn' AND paper_id='$paperId' ");
            if($checkElective==true || $flagCheck==0) {
                if ($selectMarksData == false) {
                    for ($j = 1; $j <= $subjectFields[$index]; $j++) {
                        $studentMarksRow .= "<td>" . "M.N.U." . "</td>";

                        $content.="<td>";
                        $content.="M.N.U";
                        $content.="</td>";

                    }
                } else {

                    $marks=$this->finalMarks($stdRegn,$paperId,$batch_id,$group_id,false);
                    //$marks = $selectMarksData['marks'];
                    $marks=explode('-',$marks);

                    $pattern = json_decode($marks[0], true);

                    foreach ($pattern as $key => $value) {
                        if ($value == 'None') {
                            $studentMarksRow .= "<td>" . "&nbsp;" . "</td>";

                        } else {
                            if($key=='Total') {
                                $studentMarksRow .= "<td>" . $value.$marks[1]. "</td>";
                                array_push($studentMarksRowCSV, $value.$marks[1]);
                            }else{
                                $studentMarksRow .= "<td>" . $value. "</td>";
                                array_push($studentMarksRowCSV, $value);


                            }
                        }
                    }

                    $totalCredits=$totalCredits+$paperdetails['credits'];
                    $marksTotal = $pattern['Total'];
                    $totalOptainMarks = $totalOptainMarks + $marksTotal;
                    $percentage = round(($marksTotal * 100) / $patternTotal[$index], 0);

                    if ($batch_details['gradingSystem'] == 1) {
                        if ($percentage >= 91) {
                            $grade = "O";
                            $grade_point = 10;
                        } elseif ($percentage >= 81) {
                            $grade = "A+";
                            $grade_point = 9;
                        } elseif ($percentage >= 71) {
                            $grade = "A";
                            $grade_point = 8;
                        } elseif ($percentage >= 61) {
                            $grade = "B+";
                            $grade_point = 7;
                        } elseif ($percentage >= 56) {
                            $grade = "B";
                            $grade_point = 6;
                        } elseif ($percentage >= 51) {
                            $grade = "C";
                            $grade_point = 5;
                        } elseif ($percentage >= 40) {
                            $grade = "P";
                            $grade_point = 4;
                        } elseif ($percentage < 40) {
                            $grade = "F";
                            $grade_point = 0;
                        }
                        $gradeCredit = $gradeCredit + ($credits[$index] * $grade_point);
                        $studentMarksRow .= "<td>" . $grade . "</td>";
                        $content.='<td align="center">';
                        $content.=$grade;
                        $content.="</td>";

                    } elseif ($batch_details['gradingSystem'] == 2) {
                        if ($percentage <= 100 && $percentage >= 90) {
                            $grade = "O";
                            $grade_point = 10;
                        } elseif ($percentage < 90 && $percentage >= 80) {
                            $grade = "A";
                            $grade_point = 9;
                        } elseif ($percentage < 80 && $percentage >= 70) {
                            $grade = "B";
                            $grade_point = 8;
                        } elseif ($percentage < 70 && $percentage >= 60) {
                            $grade = "C";
                            $grade_point = 7;
                        } elseif ($percentage < 60 && $percentage >= 50) {
                            $grade = "D";
                            $grade_point = 6;
                        } elseif ($percentage < 50) {
                            $grade = "F";
                            $grade_point = 0;
                        }
                        $gradeCredit = $gradeCredit + ($credits[$index] * $grade_point);
                        $studentMarksRow .= "<td>" . $grade . "</td>";
                        $content.="<td>";
                        $content.=$grade;
                        $content.="</td>";

                    } elseif ($batch_details['gradingSystem'] == 3) {
                        // for 3rd grading system
                    }


                }
            }
            else{
                for ($j = 1; $j <= $subjectFields[$index]; $j++) {
                    $studentMarksRow .= "<td>" . "<i class=\"fa fa-tasks\" aria-hidden=\"true\"></i></td>";

                }
            }
            $index++;



            $content.="</tr>";

        }

        if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
        {
            $sgpa=round($gradeCredit/$totalCredits,2);
            $studentMarksRow.="<th style='text-align: center;'>".$sgpa."</th>";
            array_push($studentMarksRowCSV,$sgpa);

            $content.="<tr>";
            $content.="<td>";
            $content.="</td>";
            $content.="<td>";
            $content.="</td>";
            $content.='<td align="center">';
            $content.="<b>SGPA</b>";
            $content.="</td>";

            $content.='<td align="center">';
            $content.=$sgpa;
            $content.="</td>";
            $content.="</tr>";


        }

        elseif($batch_details['gradingSystem']==3)
        {
            $per=round(($totalOptainMarks*100)/$totalMaxMarks,2);
            $studentMarksRow.="<th style='text-align: center;'>".$per."%</th>";
            array_push($studentMarksRowCSV,$per."%");
        }
        $values=array($gradeCredit,$totalCredits);
     return $values;
    //    Controller::$view['message'] =($values[1]);

        $content.="</table>";

        $this->view();


    }
}