<?php
/**
 * Created by PhpStorm.
 * User: ahmad
 * Date: 3/1/15
 * Time: 12:57 PM
 */


class HelpDeskAdministration extends Controller {

    private $tbl;

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("HelpDeskAdministration", "id");
        $this->tbl = "tbl_helpdesk_ticket";
    }

    public function index() {

        $this->Reset('HelpDeskAdministration');
        $current_user=Session::get('user');
        $role_id=Session::get('role_id');

        Controller::$view['title'] = "Administration of Help Desk";
        $t=array('Ticket id','Category','Subject','Date and Time','Status','Assigned To','Description','Last Status');
        $f=array('id','cat_id','subject','datetime','status','assignTo','des','laststatus');
        if($current_user=='HR-123')
        {
            Controller::$view['grid']=$this->db->GetRecords($t,$f,"tbl_helpdesk_ticket WHERE main_cat='taxi'  ORDER BY id DESC", $this->link['expre'], false, false, $this->link['edit'], FALSE, true, false);
        }
        else{
            Controller::$view['grid']=$this->db->GetRecords($t,$f,"tbl_helpdesk_ticket WHERE main_cat='it'  ORDER BY id DESC", $this->link['expre'], false, false, $this->link['edit'], FALSE, true, false);

        }
        if($current_user=='HR-350' or $current_user=='HR-255')
        {
           Controller::$view['grid']=$this->db->GetRecords($t,$f,"tbl_helpdesk_ticket WHERE cat_id='ims' ORDER BY id DESC", $this->link['expre'], false, false, $this->link['edit'], FALSE, true, false);
        }
        if($current_user=='HR-353' OR $current_user=='HR-113' OR $current_user=='HR-349')
        {
            Controller::$view['grid']=$this->db->GetRecords($t,$f,"tbl_helpdesk_ticket WHERE cat_id='hardware' or cat_id='printer'  ORDER BY id DESC", $this->link['expre'], false, false, $this->link['edit'], FALSE, true, false);
        }
        if($current_user=='HR-112' OR $current_user=='HR-478')
        {
            Controller::$view['grid']=$this->db->GetRecords($t,$f,"tbl_helpdesk_ticket WHERE cat_id='hardware' or cat_id='printer' or cat_id='ims'  ORDER BY id DESC", $this->link['expre'], false, false, $this->link['edit'], FALSE, true, false);
        }



        $this->view();
    }
//*********************

    public function edit($id) {
        $this->Reset('HelpDeskAdministration');
        $this->checkPermission("edit");
        Controller::$view['title']="Help Desk Administration";


        if(isset($_POST['assignTo']))
        {
            $assignedTo=trim($_POST['assigned_to']);
            if($assignedTo=='')
            {
                Controller::$view['message']="Please assign some one";

            }
            else{
                $status=trim($_POST['status_to']);
                $ticketId=trim($_POST['id_tic']);

                $select=$this->db->Fetch("*","tbl_helpdesk_ticket","WHERE id='$ticketId'");
                if($select['assignTo']==$assignedTo)
                {
                    Controller::$view['message']="Already Assigned to this person";
                }
                else{
                    $fields=array("assignTo");
                    $values=array($assignedTo);



                    $update1=$this->db->Update($this->tbl,$fields,$values,'id',$ticketId);
                    if($update1==true)
                    {
                        $reply_message="Task Assigned to ".$assignedTo;
                        $current_user=Session::get('user');

                        $requester_details = $this->db->Fetch("*", 'tbl_staff', "WHERE staff_regn='$current_user' ");
                        $requesterName=$requester_details['staff_name'];
                        $ticketDetails=$this->db->Fetch("*","tbl_helpdesk_ticket","WHERE id='$ticketId'");


                        date_default_timezone_set('Asia/Kolkata');
                        $date = date('Y-m-d H:i:s');

                        $f=array("ticket_id","message","status","datetime","message_writtenby_id","messageWrittenBy");
                        $v=array($ticketId,$reply_message,$status,$date,$current_user,$requesterName);

                        $result=$this->db->Insert("tbl_helpdesk_message",$f,$v);
                        if($result==true)
                        {
                            $mailBodyTo='Dear '.$requesterName.'<br>
                
                Your support ticket has now been updated.The details of your ticket are shown below.<br>
                Ticket ID : '.$ticketId.'<br>
                Message   : '.$reply_message.'<br>
                Status    : '.$status.'<br>
                <br>
                You can view the ticket at any time by login into IMS Portal : <a href="http://170.170.117.113/ims">IMS</a>';

                            $mailBodyCc='Dear Concern,<br>
                A support ticket has been Updated.The details of ticket are shown below.<br>
                Ticket ID : '.$ticketId.'<br>
                Message   : '.$reply_message.'<br>
                Status    : '.$status.'<br>';

                            $mailBodyAssigned='Dear <br>
                            A new Task(ticket) is assigned to you.<br>
                            The details of your ticket are shown below<br>
                            Ticket ID : '.$ticketId.'<br>
                            Message   : '.$reply_message.'<br>
                            Status    : '.$status.'<br>
                            ';

                            if($assignedTo=='Perwez')
                            {
                                $assignedMailID=array('perwez@theglocaluniversity.in');
                            }
                            elseif($assignedTo=='Ahmad')
                            {
                                $assignedMailID=array('ahmad@theglocaluniversity.in');
                            }elseif($assignedTo=='Noor')
                            {
                                $assignedMailID=array('noor@theglocaluniversity.in');
                            }elseif($assignedTo=='Aizaz')
                            {
                                $assignedMailID=array('aizaz@theglocaluniversity.in');
                            }elseif($assignedTo=='Shoukat')
                            {
                                $assignedMailID=array('shoukat@theglocaluniversity.in');
                            }elseif($assignedTo=='Tanveer')
                            {
                                $assignedMailID=array('tanveer@theglocaluniversity.in');
                            }elseif($assignedTo=='Kashif')
                            {
                                $assignedMailID=array('kashif@theglocaluniversity.in');
                            }elseif($assignedTo=='Shahnawaz')
                            {
                                $assignedMailID=array('shahnawaz@theglocaluniversity.in');
                            }

                            $f=sendmail($assignedMailID,'New Task',$mailBodyAssigned);

                            if($ticketDetails['main_cat']=='it')
                            {
                                $f=sendmail(array('it@theglocaluniversity.in'),"[".$ticketId."] Support Ticket Update",$mailBodyCc);

                            }
                            elseif($ticketDetails['main_cat']=='taxi')
                            {
                                $f=sendmail(array('ahmad@theglocaluniversity.in'),"[".$ticketId."] Support Ticket Update",$mailBodyCc);

                            }
                            //$f=sendmail(array($requester_details['o_email']),"Support Ticket Update",$mailBodyTo);

                            Controller::$view['message']="Task Assigned";
                        }
                        else{
                            Controller::$view['message']="Error...";
                        }

                    }
                }


            }


        }
        if(isset($_POST['send']))
        {
            $ticket_id=trim($_POST['id_ticket']);
            $status=trim($_POST['status']);
            Controller::$view['ticket_details']=$this->db->Fetch("*", $this->tbl,"WHERE id='$ticket_id'");

            //$status=Controller::$view['ticket_details']['status'];

            $reply_message=trim($_POST['reply']);
            $current_user=Session::get('user');

            $requester_details = $this->db->Fetch("*", 'tbl_staff', "WHERE staff_regn='$current_user' ");
            $requesterName=$requester_details['staff_name'];


            date_default_timezone_set('Asia/Kolkata');
            $date = date('Y-m-d H:i:s');

            $f=array("ticket_id","message","status","datetime","message_writtenby_id","messageWrittenBy");
            $v=array($ticket_id,$reply_message,$status,$date,$current_user,$requesterName);
            $ticketDetails=$this->db->Fetch("*","tbl_helpdesk_ticket","WHERE id='$ticket_id'");

            $result=$this->db->Insert("tbl_helpdesk_message",$f,$v);
            $fields=array('status','laststatus');
            $values=array($status,$reply_message);

            if ($result == true) {

                $mailBodyTo='Dear '.$requesterName.'<br>
                Your support ticket has now been updated.The details of your ticket are shown below.<br>
                Ticket ID : '.$ticket_id.'<br>
                Message   : '.$reply_message.'<br>
                Status    : '.$status.'<br>
                
                You can view the ticket at any time by login into IMS Portal : <a href="http://170.170.117.113/ims">IMS</a> <br>';

                $mailBodyCc='Dear Concern,
                A support ticket has been Updated.The details of ticket are shown below.<br>
                Ticket ID : '.$ticket_id.'  <br>
                Message   : '.$reply_message.'<br>
                Status    : '.$status.'<br>';


                if($ticketDetails['main_cat']=='it')
                {
                    $f=sendmail(array('it@theglocaluniversity.in'),"[".$ticket_id."] Support Ticket Update",$mailBodyCc);

                }
                elseif($ticketDetails['main_cat']=='taxi')
                {
                    $f=sendmail(array('ahmad@theglocaluniversity.in'),"[".$ticket_id."] Support Ticket Update",$mailBodyCc);

                }
                $f=sendmail(array($requester_details['o_email']),"[".$ticket_id."] Support Ticket Update",$mailBodyTo);

                $r=$this->db->Update("tbl_helpdesk_ticket",$fields,$values,'id',$id);
                Controller::$view['message'] = 'Message sent.';
                header("location:".URL."HelpDeskAdministration/edit/".$ticket_id);
            }
            else
            {
                Controller::$view['message'].=  'Error Occurred';
            }
        }



        Controller::$view['ticket_details']=$this->db->Fetch("*", $this->tbl,"WHERE id='$id'");
        Controller::$view['messages']=$this->db->FetchList("*","tbl_helpdesk_message","WHERE ticket_id='$id' ");
        $staffId=Controller::$view['ticket_details']['requester_id'];
        Controller::$view['staff_details']=$this->db->Fetch("*",'view_staff',"WHERE staff_regn='$staffId'");
        Controller::$view['title']="Ticket Number: ".Controller::$view['ticket_details']['id'];
        Controller::$view['url']=URL;

        $this->view('editHelpDeskAdministration');
    }

//*********************
 /*
    public function add() {
        $this->checkPermission("add");
        Controller::$view['title'] = "Add New Accession";
        Controller::$view['category'] = $this->getOptions('id,title', 'tbl_book_cat', 'ORDER BY title');


        if(isset($_POST['add']))
        {
            $acc_num=trim($_POST['booknum']);
            $title=trim($_POST['title']);
            $book_type=trim($_POST['book_type']);
            $category_id=trim($_POST['category']);
            $author=trim($_POST['author']);
            $place=trim($_POST['placepub']);
            $volume=trim($
 _POST['volume']);
            $yearpub=trim($_POST['yearpub']);
            $pages=trim($_POST['pages']);
            $status="Available";
            $source=trim($_POST['source']);
            $class_num=trim($_POST['class_num']);
            $book_num=trim($_POST['book_num']);
            $cost=trim($_POST['cost']);
            $bill_num=trim($_POST['bill_num']);
            $bill_date=trim($_POST['bill_date']);
            $withdrawn_date=trim($_POST['withdrawn_date']);
            $remarks=trim($_POST['reamrks']);

            $f=array("acc_num","title","category_id","book_type","volume","author","place_pub","publication_year","source","class_num",
                "book_num","pages","cost","bill_no","withdrawn_date","bill_date","status","remark");
            $v=array($acc_num,$title,$category_id,$book_type,$volume,$author,$place,$yearpub,$source,$class_num,
                $book_num,$pages,$cost,$bill_num,$withdrawn_date,$bill_date,$status,$remarks);

            $result= $this->db->Insert($this->tbl, $f, $v);

            if($result==True)
            {
                Controller::$view['message']="Record Inserted.";
            }
            else{
                Controller::$view['message']="Error occured.";

            }



        }

        $this->view('addbookacc');
    }
*/
//*********************

}

?>