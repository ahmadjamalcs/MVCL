<?php

class Admcanslip extends Controller {
    private $tbl;
    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("admcanslip", "std_regn");
        $this->tbl="view_studentgeneral";
    }

    public function index() {
        Controller::$view['title'] = "Print Admission Cancellation Slip";
        $this->view("pradmcanslip");
    }

    public function singleprint() {
        if (isset($_POST['pradmcanslip'])) {
            $std_regn=trim($_POST['std_regn']);
            $q=$this->db->runSQL("SELECT * FROM $this->tbl WHERE std_regn='$std_regn'");
            if(mysqli_num_rows($q)<1){
                echo '<b>Enrollment no. does not extst.</b>';
                return;
            }
            $r=  mysqli_fetch_assoc($q);
            $hall_code=$r['hall_code'];
            $h=  $this->db->Fetch("hall_name","tbl_halls","WHERE hall_code='$hall_code'");
            
            
            require_once(ROOT . 'libs/fpdf/fpdf.php');
            $p = array(21, 7.3);
            //$pdf = new FPDF(P, cm, $p)
            $pdf = new FPDF('P', 'cm', $p);
            $pdf->SetMargins(0, 0, 0, 0);
            $copyto=array("Dealing Clerk","Student","Controller","Provost");

         for ($i=0; $i<4; $i++) 
           {

            //front page
            $pdf->AddPage();
            $pdf->SetAutoPageBreak(0);

            //header part starts here
            $pdf->SetFont('Arial', 'B', 11);
            $pdf->SetXY(14.5, 1.0);
            $pdf->Cell(0, 0, 'DEAN\'S OFFICE',0,0,'L');
            $pdf->SetXY(14.5, 1.4);
            $pdf->Cell(0, 0, 'FACULTY OF'. strtoupper($r['faculty_id']),0,0,'L');
            $pdf->SetFont('Arial', 'B', 11);
            $pdf->SetXY(14.5, 1.8);
            $pdf->Cell(0, 0, 'A.M.U. ALIGARH',0,0,'L');
            $pdf->SetXY(2, 1);
            $pdf->Cell(0,0,'ID No. '.$r['std_id']);
            //$pdf->Cell(14.5, 1.5,strtoupper($h['hall_name']),0,0,'C');
            //header part ends here
          
            //student image
            if(file_exists(ROOT.'public/student_photos/'.$std_regn.'.jpg')){
                $pdf->Image(URL.'public/student_photos/'.$std_regn.'.jpg', 14.5, 2.9, 2.5, 2.4);
            }
 
			//$pdf->Image('images/logo.jpg',9.5,.2);
			$pdf->SetFont('Arial','',10);
			
			$pdf->SetXY(14.5,2.6);
			$pdf->Cell(0,0,"Dated: ".date('M d, Y'));//Date of receipt change here
         
			$pdf->SetFont('Arial','',11);
			$pdf->SetXY(2,2);
			$pdf->Cell(0,0,"To");		
			$pdf->SetXY(2,2.5);
			$pdf->Cell(0,0,"The Provost ".$h['hall_name']." Hall");
			$pdf->SetXY(2,3);
			$pdf->Cell(0,0,"The name of the following student has been cancelled/removed:");

           //titles starts here
            $pdf->SetFont('Arial', '', 11);
            $pdf->SetXY(2, 3.6);
            $pdf->Cell(0,0,'Name:');
            $pdf->SetXY(2, 4);
            $pdf->Cell(0,0,'En.No:');
            $pdf->SetXY(2, 4.4);
            $pdf->Cell(0,0,'Class:');
            $pdf->SetXY(2, 4.8);
            $pdf->Cell(0,0,'Fac.No:');
            $pdf->SetXY(2, 5.2);
            $pdf->Cell(0,0,'Faculty:');
            //titles ends here
            
            //students data
            $pdf->SetFont('Arial', 'B', 11);
            $pdf->SetXY(3.5, 3.6);
            $pdf->Cell(0,0,$r['s_name']);
            $pdf->SetXY(3.5, 4);
            $pdf->Cell(0,0,$std_regn);
            $pdf->SetXY(3.5, 4.4);
            $pdf->Cell(0,0,$r['course_name'].' '.$r['year']);
            $pdf->SetXY(3.5, 4.8);
            $pdf->Cell(0,0,$r['faculty_no']);
            $pdf->SetXY(3.5, 5.2);
            $pdf->Cell(0,0,$r['faculty_id']);
            //student data ends

            $pdf->SetXY(13.5, 6);
            $pdf->Cell(0,0,'Dean',0,0,'C');
            $pdf->SetXY(13.5, 6.4);
            $pdf->Cell(0,0,'Faculty of '.$r['faculty_id'],0,0,'C');
            $pdf->SetXY(13.5, 6.8);
            $pdf->Cell(0,0,'A.M.U. Aligarh',0,0,'C'); 
			
	    $pdf->SetXY(2, 6.8);
            $pdf->Cell(0,0,'Copy to: '. $copyto[$i],0,0,'L');  
			        
       }
 
            $pdf->Output();
        }
    }
    
}