<?php

class Assignments extends Controller {

    private $tbl;
    private $file_name;

    function __construct() {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("assignments", "id");
        $this->tbl = "tbl_assignments";
    }

    private function checkFileExtension($ext)
    {
        if ($ext == 'pdf' || $ext == 'jpg' || $ext == 'jpeg' || $ext ==
            'gif' || $ext == 'png' || $ext == 'xls' || $ext ==
            'xlsx' || $ext == 'doc' || $ext == 'docx' || $ext == 'ppt' || $ext == 'pptx' ||
            $ext == 'zip') {
            return 1;
        } else {
            return 0;
        }
    }

    private function uploadDoc($new_name){

        $filename = $_FILES['a_doc']['name'];
        $ext = explode(".",$filename);
        $cnt=(count($ext)-1);
        $ext=$ext[$cnt];

        if($this->checkFileExtension($ext)==0) {
            Controller::$view['message']="Invalid file type.".$ext;
            return 0;
        }
        $file_size = $_FILES['a_doc']['size'];

        if (($file_size > 5242880)){
            Controller::$view['message'] = 'File too large. File must be less than 5 megabytes.';
            return 0;
        }
            //return ROOT . 'public/student_photos/' . $name . '.jpg';
            $this->file_name = 'public/docs/' . $new_name . $ext;
            return move_uploaded_file($_FILES['a_doc']['tmp_name'], $this->file_name);
    }

    public function index() {
        $this->Reset('assignments');

        if (isset($_POST['publish'])) {
            $this->checkPermission("edit");
            Controller::$view['message'] = $this->Activate($this->tbl, 'id');
        }
        if (isset($_POST['unpublish'])) {
            $this->checkPermission("edit");
            Controller::$view['message'] = $this->deActivate($this->tbl, 'id');
        }

        Controller::$view['title'] = "Assignments ";
        $t = array('School', 'Dept', 'Course', 'Paper','Title','Type','Date', 'ID');
        $f = array('faculty_id', 'dept_id', 'course_id','paper_code','title','type','date', 'id');
        $user=Session::get('user');
        Controller::$view['grid'] = $this->db->GetRecords($t, $f, $this->tbl, " username='$user' ",$this->link['add'], false, false, FALSE, TRUE, $this->link['publish'], array('Publish', 'active'));
        $this->view();
    }

    public function add() {
        $this->checkPermission("add");
        if (isset($_POST['btnsubmit'])) {
            $faculty_id = $_POST['faculty_id'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];
            $paper_code = $_POST['paper_code'];
            $title = trim($_POST['title']);
            $a_desc = trim($_POST['a_desc']);


            $type = trim($_POST['type']);
            $a_type = trim($_POST['a_type']);
            $date = trim($_POST['date']);
            $username = Session::get('user');

            if($type=="Vid"){
                $a_link = trim($_POST['a_link']);
            } else {
                $a_link=$this->uploadDoc($paper_code.$date.date('H-i-s').".");
                if($a_link==0){

                    Controller::$view['title'] = 'Upload New Assignment/Lecture';
                    Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");
                    $this->view('addassignment');
                    return;
                }
                $a_link=URL.$this->file_name;
            }


            $t = array('faculty_id','dept_id','course_id','paper_code','title','a_desc','a_link','type','date','a_type','username');
            $v = array($faculty_id,$dept_id,$course_id,$paper_code,$title,$a_desc,$a_link,$type,$date,$a_type,$username);

            if ($this->db->Insert($this->tbl, $t, $v)) {
                Controller::$view['message'] = "Assignment/Lecture uploaded.";
            } else {
                Controller::$view['message'] = "Error! please try later";
            }
        }

        Controller::$view['title'] = 'Upload New Assignment/Lecture';
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', "WHERE active=1");
        $this->view('addassignment');
    }

    public function edit($id) {
        $this->checkPermission("edit");
        Controller::$view['title'] = "Edit Batch";
        if (isset($_POST['sub'])) {
            $title = trim($_POST['title']);
            $des = trim($_POST['des']);
            $start_date = trim($_POST['start_date']);
            $end_date = trim($_POST['end_date']);
            $c_status = $_POST['c_status'];

            $mons = array(1 => "Jan", 2 => "Feb", 3 => "Mar", 4 => "Apr", 5 => "May", 6 => "Jun", 7 => "Jul", 8 => "Aug", 9 => "Sep", 10 => "Oct", 11 => "Nov", 12 => "Dec");

            $f_month=explode("-",$start_date);
            $t_month=explode("-",$end_date);

            $f_month=intval($f_month[1]);
            $t_month=intval($t_month[1]);

            $total_mo="";
            if($f_month > $t_month) {
                for($i=$f_month;$i<=12;$i++){
                    $total_mo.=$mons[$i].",";
                }
                for($i=1;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            } else {
                for($i=$f_month;$i<=$t_month;$i++){
                    $total_mo.=$mons[$i].",";
                }
            }



            $f = array('title', 'des', 'start_date', 'end_date', 'c_status','total_mo');
            $v = array($title, $des, $start_date, $end_date, $c_status,$total_mo);
            $f = $this->db->Update($this->tbl, $f, $v, 'id', $id);
            if ($f == true) {
                Controller::$view['message'] = 'Record updated.';
            }
        }
        Controller::$view['batch'] = $this->db->Fetch("*", "view_batches", "WHERE id='$id'");
        Controller::$view['id'] = $id;
        $this->view('editbatch');
    }
}