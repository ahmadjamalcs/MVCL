<?php
class activestudents extends Controller
{
    function __construct(){
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("activestudents", "std_regn");

        $this->tbl = "tbl_students";
    }
    public function index() {
       $this->Reset('activestudents');
        if(isset($_POST['del_sub'])){
            $this->checkPermission("del");
            Controller::$view['message']="Delete function is disabled for now";
        }
        if(isset($_POST['publish'])){
            $this->checkPermission("edit");
            Controller::$view['message']=$this->Activate($this->tbl, 'id');
        }
        if(isset($_POST['unpublish'])){
            $this->checkPermission("edit");
            Controller::$view['message']=$this->deActivate($this->tbl, 'id');
        }
        
        Controller::$view['grid']='<form method="POST">
        Search: <select name="faculty_id" id="faculty_id">
        <option value="" selected="selected">All Schools</option>
        '.$this->getOptions('faculty_id,faculty_name', 'tbl_faculty').'
        </select>
        <select name="dept_id" id="dept_id"></select>
        <select name="course_id" id="course_id"></select>
        <select name="batch_id" id="batch_id"></select>
        <input type="text" name="date" id="datepick">
        
        <p align="right">
        <input type="submit" name="s_dept" value="Search" />
        <input type="submit" name="reset" value="Clear Search" />
        </p></form>';
        
        if(isset($_POST['s_dept'])){
            $faculty_id=$_POST['faculty_id'];
            $dept_id=$_POST['dept_id'];

            $course_id=$_POST['course_id'];
            $batch_id=$_POST['batch_id'];
            $date=$_POST['date'];
            if($faculty_id==""){Session::set('find',"");}
            elseif($dept_id==""){Session::set('find',"faculty_id='$faculty_id'");}
            elseif($course_id==""){Session::set('find',"faculty_id='$faculty_id' AND dept_id='$dept_id'");}
            elseif($batch_id==""){
                Session::set('find',"faculty_id='$faculty_id' AND dept_id='$dept_id' AND course_id='$course_id'");}
            elseif($date==""){
                Session::set('find',"faculty_id='$faculty_id' AND dept_id='$dept_id' AND course_id='$course_id' 
                AND batch_id='$batch_id'");
            }
            else{
                Session::set('find',"faculty_id='$faculty_id' AND dept_id='$dept_id' AND course_id='$course_id' 
                AND batch_id='$batch_id' AND registration_date='$date' ");

            }
    }

        if(isset($_POST['reset'])){
            Session::set('find',"");
          
        }
        if($this->link['expre']==""){$this->link['expre']=Session::get('find');}
        else {$this->link['expre'].=" AND ".Session::get('find');}

        $titles = array('Enrol. No.', 'Name','Father Name','Batch', 'course', 'Dob',  'Mobile','Gender','Category','State',  'Religion','Address','pincode','Registration Date');
      $fields = array('std_regn', 'std_name', 'std_father' ,'title','course_id', 'dob', 'ph_mobile','gender','category','state', 'religion','address1','pincode','assign_date');

    Controller::$view['title'] = "List of Active Students";
    Controller::$view['grid'].= $this->db->GetRecords($titles, $fields, 'view_active_students', $this->link['expre'], false,false , false, false, TRUE, $this->link['publish'], false, true);
      
        $this->view();
    }
    public function edit($id){

        Controller::$view['title']="Student Details";

        $this->view('editpaper');
    }

    public function add() {
        $this->checkPermission("add");
        Controller::$view['title'] = "Add New Paper";
        if (isset($_POST['add'])) {
            $faculty_id = $_POST['faculty_id'];
            $dept_id = $_POST['dept_id'];
            $course_id = $_POST['course_id'];

            $code = trim($_POST['code']);
            $title = trim($_POST['title']);
            $marks_sessional = 20;
            $marks_mid_sem = 30;
            $marks_end_sem = 50;
            $category = trim($_POST['category']);
            $type = trim($_POST['type']);
            //$fac_code = trim($_POST['fac_code']);

            $credits = trim($_POST['credits']);
            //$type = trim($_POST['type']);
            $f = array('code','title','faculty_id','marks_sessional','marks_mid_sem','marks_end_sem','category','type','dept_id','course_id','credits');
            $v = array($code,$title,$faculty_id,$marks_sessional,$marks_mid_sem,$marks_end_sem,$category,$type,$dept_id,$course_id,$credits);
            if($this->db->Insert($this->tbl, $f, $v)){
                Controller::$view['message'] = 'Record inserted.';
            } else {
                Controller::$view['message'] = 'There\'s an error.';
            }
            
        }
        Controller::$view['faculty'] = $this->getOptions('faculty_id,faculty_name', 'tbl_faculty', 'WHERE active=1');
        $this->view('addpaper');
    }
}
