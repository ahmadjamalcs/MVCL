<?php
class attMarkSyncJson extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->CheckAuth();
        $this->getPermissions("attMarkSyncJson", "id");
    }
    public function attendnaceMarksInsertor($std_regn,$batch_id,$paper_id,$group_id,$marks,$marksDistributionID,$acc_session_id)
    {
        $flag=true;
        $marks_distribution_pattern=$this->db->Fetch("*",'tbl_marks',"WHERE paper_id='$paper_id' AND std_regn='$std_regn' AND batch_id='$batch_id' AND group_id='$group_id' AND acc_session_id=5 ");
        $pattern = json_decode($marks_distribution_pattern['marks'],true);

        if($pattern==false)
        {
            $flag=false;
        }
        else {
            $newJsonData="{";
            $total=0;

            foreach ($pattern as $key => $value) {

                if($key=='Total' || $key=='total')
				{		
							$newJsonData .= '"' . $key . '":';
							$newJsonData .= '"' . $total . '",';
				}
				else{
						if ($key == 'Attendance') {
							$newJsonData .= '"' . $key . '":';
							$newJsonData .= '"' . $marks . '",';
							$total=$total+$marks;
						} else {
							$newJsonData .= '"' . $key . '":';
							$newJsonData .= '"' . $value . '",';
							$total=$total+$value;
						}
				}
			}
            $newJsonData=rtrim($newJsonData,',');
            $newJsonData.="}";
        }
        if($flag==true)
        {
            $id=$marks_distribution_pattern['id'];
            date_default_timezone_set('Asia/Kolkata');
            $date=date('Y-m-d h:m:s');

            $f=array('marks','total','markSyncDate');
            $v=array($newJsonData,$total,$date);

            $update=$this->db->Update('tbl_marks',$f,$v,'id',$id);
            //$update=true;
            if($update==true)
            {
                return "batch-Id : ".$batch_id.", Paper-Id :".$paper_id."-".$group_id."-".$marks."-".$std_regn;
            }
            else{
                return false;
            }

        }
        else{
            return $batch_id."NOT".$batch_id.'-'.$paper_id.'-'.$group_id;
        }

    }
    public function attendanceMarksCalculator($std_regn,$batch_id,$paper_id,$group_id,$number_of_classes,$from,$to,$reg_date)
    {
        return 5;
        $attendance_array=$this->db->FetchList("*",'tbl_attendance',"WHERE paper_id='$paper_id' AND group_id='$group_id' AND batch_id='$batch_id' AND std_regn='$std_regn' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");
        if($attendance_array==false)
        {
            $marks='None';
        }
        else{
            $absent=0;
            $persent=0;
            $j=0;
            foreach($attendance_array as $attendance)
            {
                if($attendance['absent']==0)
                    $persent++;
                elseif($attendance['absent']==1)
                    $absent++;
                $j++;

            }

            $percentage=round((($persent/$number_of_classes)*100),0);
            $attendance = 0;
            switch ($percentage) {
                case $percentage >= 96:
                    $attendance = 5;
                    break;
                case ($percentage <= 95 && $percentage >= 91):
                    $attendance = 4;
                    break;
                case ($percentage <= 90 && $percentage >= 86):
                    $attendance = 3;
                    break;
                case ($percentage <= 85 && $percentage >= 81):
                    $attendance = 2;
                    break;
                case ($percentage <= 80 && $percentage >= 76):
                    $attendance = 1;
                    break;
                default:
                    $attendance = 0;
            }
			if($percentage==0)
            {
			$attendance = 0;
			}
        }
       
       //return $attendance."#".$j."#".$persent."#".$absent."$".$percentage."#$".$number_of_classes;
       return $attendance;
    }
    public function index()
    {
        Controller::$view['title'] = "Attendance Marks Sync";

        $batches_list=$this->db->FetchList('*','tbl_batches',"WHERE active=1");
        $from='2021-08-15';
        $to='2021-12-15';
        $acc_session_id=15;

        foreach ($batches_list as $batches)
        {
            $batch_id=$batches['id'];
            $batch_sem=$batches['sem'];
            $paper_list=$this->db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' ");

            foreach($paper_list as $papers)
            {
                $paper_id=$papers['paper_id'];
                //$number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
                //$number_of_classes=$number_of_classes_count['date'];
               // $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND group_id='$group_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'");
				//$number_of_classes=$number_of_classes_count['date'];
                
                $group=$papers['group'];
                $marksDistributionID=$papers['marks_distribution_id'];
                
                if($group==1)
                {
                    $group_ids=$this->db->FetchList("group_id","tbl_assign_paper_staff","WHERE paper_id='$paper_id'");

                    foreach($group_ids as $ids)
                    {
                        $group_id=$ids['group_id'];
                        $student_list=$this->db->FetchList('*','tbl_assign_group',"where group_id='$group_id' AND active=1");
                        $stu_list_gv="";
                        foreach ($student_list as $stu)
                        {
                            $stu_list_gv.="'";
                            $stu_list_gv.=$stu['std_regn'];
                            $stu_list_gv.="'";
                            $stu_list_gv.=",";
                        }

                        $stu_list_gv=rtrim($stu_list_gv,',');

                        $student_list=$this->db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' AND std_regn IN ($stu_list_gv) ORDER BY std_regn");

                        $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND group_id='$group_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'");
                        $number_of_classes=$number_of_classes_count['date'];

                        foreach($student_list as $student)
                        {
                            $std_regn=$student['std_regn'];
                            $registration_date=$student['assign_date'];
                            // $marks=$this->attendanceMarksCalculator($std_regn,$batch_id,$paper_id,$group_id,$number_of_classes,$from,$to,$registration_date);
                            $marks = 5;
                            $marksInsertor=$this->attendnaceMarksInsertor($std_regn,$batch_id,$paper_id,$group_id,$marks,$marksDistributionID,$acc_session_id);

                            if($marksInsertor==true)
                            {
                                Controller::$view['paper_list'].="Marks Insert".$marksInsertor."#$#Marks is: ".$marks;
                            }

                            Controller::$view['paper_list'].="<br>";
                        }
                    }

                }
                else{
                    $student_list=$this->db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");
					
                    $group_id=0;
                    $number_of_classes_count=$this->db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND group_id='$group_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'");
                    $number_of_classes=$number_of_classes_count['date'];

                    
                    foreach($student_list as $student)
                    {
                        $std_regn=$student['std_regn'];
                        $registration_date=$student['assign_date'];
                        //$marks=$this->attendanceMarksCalculator($std_regn,$batch_id,$paper_id,$group_id,$number_of_classes,$from,$to,$registration_date);
                        $marks = 5;
                        $marksInsertor=$this->attendnaceMarksInsertor($std_regn,$batch_id,$paper_id,$group_id,$marks,$marksDistributionID,$acc_session_id);

                        if($marksInsertor==true)
                        {
                            Controller::$view['paper_list'].="Marks Insert".$marksInsertor;
                        }

                        Controller::$view['paper_list'].="<br>";
                    }

                }

            }


        }
        
        $this->view('attendancemarksync');

    }
}
