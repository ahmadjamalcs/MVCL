<?php
function sendmail($to,$subject,$body,$from){
	require_once 'swift_required.php';
$transport = Swift_SmtpTransport::newInstance('ssl://smtp.gmail.com', 465)
    ->setUsername('webadmin@glocaluniversity.edu.in') // Your Gmail Username
    ->setPassword('Koijj8&89hgOih'); // Your Gmail Password

$mailer = Swift_Mailer::newInstance($transport);

$message = Swift_Message::newInstance($subject)
    ->setFrom($from) // can be $_POST['email'] etc...
    ->setTo($to) // your email / multiple supported.
    ->setBody($body, 'text/html');

	return $mailer->send($message);
}

if(sendmail(array("ahmad@theglocaluniversity.in","ahmadjamalcs@gmail.com","jamal.ahmad64@gmail.com"),"Test Subject","Test <b>Email</b>",array("webadmin@glocaluniversity.edu.in"=>"Glocal University"))) {
		echo "Message Sent";
} else {
		echo "failed";
}
