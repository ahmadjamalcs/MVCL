<?php
function sendmail($to,$subject,$body,$from){
	require_once 'swift_required.php';
$transport = Swift_SmtpTransport::newInstance('smtp.elasticemail.com', 2525)
    ->setUsername('ahmadjamalcs@gmail.com') // Your Gmail Username
    ->setPassword('f7cd96ef-8ad4-4e6b-9116-03fafa913093'); // Your Gmail Password
$mailer = Swift_Mailer::newInstance($transport);
$message = Swift_Message::newInstance($subject)
    ->setFrom($from) // can be $_POST['email'] etc...
    ->setTo($to) // your email / multiple supported.
    ->setBody($body, 'text/html');
	return $mailer->send($message);
}
