<?php
include("swift_mail/mail.inc.php");
class Controller {

    public static $view;
    protected $permission;
    protected $link;
    protected $db;
    
    function __construct() {
        $this->db = new Database();
        Controller::$view = array();
        $this->permission = array();
        $this->link = array();
    }

    public static function printMessage() {
        if(isset(Controller::$view['message'])) {
            return '<div class="alert alert-warning alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <strong>'.Controller::$view['message'].'</strong>
            </div>';
        }
    }
	public static function checkDisciplinaryAction($std_regn,$batch_id,$date)
    {
        $db=new Database();
        $check=$db->Fetch("*","tbl_disciplinary_action","WHERE std_regn='$std_regn' AND batch_id='$batch_id' AND active=1 AND ( from_date<='$date' AND to_date>='$date' )  ");
        if($check==true)
        {
            return "1#_#".$check['reason'];
        }
        else{
            return "0#_#"."No Disciplinary Action".$std_regn.$batch_id.$date;
        }
    }

    public function getdate() {
        date_default_timezone_set('Asia/Kolkata');
        return date('Y-m-d');
    }

    public function gettime() {
        date_default_timezone_set('Asia/Kolkata');
        return date('H:i:s');
    }

    public function view($page = 'index') {
        require 'skins/' . SKIN . '/' . $page . '.php';
    }

    public function Activate($table, $key) {
        if (!isset($_POST['checkbox'])) {
            return "Please select atleast one record.";
        }
        $checkbox = $_POST['checkbox'];
        $countCheck = count($_POST['checkbox']);
        for ($i = 0; $i < $countCheck; $i++) {
            $id = $checkbox[$i];
            $flag = $this->db->Update($table, array('active'), array(1), $key, $id);
        }
        if ($flag == FALSE) {
            return "There is an error";
        } else {
            return $countCheck . ' Record(s) Enabled.';
        }
    }

    public function deActivate($table, $key) {
        if (!isset($_POST['checkbox'])) {
            return "Please select atleast one record.";
        }
        $checkbox = $_POST['checkbox'];
        $countCheck = count($_POST['checkbox']);
        for ($i = 0; $i < $countCheck; $i++) {
            $id = $checkbox[$i];
            $flag = $this->db->Update($table, array('active'), array(0), $key, $id);
        }
        if ($flag == FALSE) {
            return "There is an error";
        } else {
            return $countCheck . ' Record(s) Disabled.';
        }
    }

    public function delRecord($table, $key) {
        if (!isset($_POST['checkbox'])) {
            return "Please select atleast one record.";
        }
        $checkbox = $_POST['checkbox'];
        $countCheck = count($_POST['checkbox']);
        for ($i = 0; $i < $countCheck; $i++) {
            $id = $checkbox[$i];
            $flag = $this->db->Delete($table, $key, $id);
        }
        if ($flag == FALSE) {
            return "There is an error";
        } else {
            return $countCheck . ' Record(s) Deleted.';
        }
    }

    private function status($type) {
        switch ($type) {
            case 'FC':
                $r = '<option>Active</option>
                    <option>Suspend</option>
                    <option>Terminate</option>
                    <option>Disciplinary</option>';
                break;
            case 'HL':
                $r = '<option>Active</option>
                    <option>Hall Transfer</option>
                    <option>Transfer to NRSC</option>
                    <option>Disciplinary</option>';
                break;
            case 'CL':
                $r = '<option>Active</option>
                    <option value="Archive">Archive</option>
                    <option>Suspend</option>
                    <option>Terminate</option>
                    <option>Disciplinary</option>';
                break;
            case 'HT':
                $r = '<option>Active</option>
                    <option>Transfer to other hostel</option>
                    <option>Transfer to other room</option>
                    <option>Disciplinary</option>';
                break;
            default :
                $r = '';
                break;
        }
        return $r;
    }

    protected function getActions($tid, $type, $url) {
        if (isset($_POST['ac'])) {
            $f = array('t_id', 'type', 'action', 'date', 'time', 'remarks');
            $v = array($tid, $type, $_POST['action'], $this->getdate(), $this->gettime(), $_POST['remarks']);
            if ($this->db->Insert("tbl_actions", $f, $v)) {
                $r.='<br><b>Status updated successfully.</b><br>';
            } else {
                $r.='<br><b>Status update failed...!!</b><br>';
            }
        }
        $r = '<br /><br /><h3><b>Update Current Status</b></h3><form method="POST">';
        $r.='Select Action: <select name="action" '.Controller::$view['dis'].'>' . $this->status($type) . '</select> ';
        $r.='Remarks: <input type="text" name="remarks" '.Controller::$view['dis'].'> ';
        $r.='Remarks: <input type="submit" name="ac" value="Update" '.Controller::$view['dis'].' onclick="return del();"></form><br /><br /> ';
        $r.='<h3><b>Status History</b></h3>';
        $this->Reset($url);
        $t = array('ID', 'Action', 'Date', 'Time', 'Remarks');
        $f = array('id', 'action', 'date', 'time', 'remarks');
        $r.=$this->db->GetRecords($t, $f, "tbl_actions", "t_id='$tid' AND type='$type'");

        return $r;
    }

    public function CheckAuth() {
        Session::init();
        //Session::set('login',false);
        $logged = Session::get('login');
        if ($logged == false) {
            Session::destroy();
            header('Location: ' . URL . 'auth/login');
            exit;
        }
    }

    public function getPermissions($url, $id=FALSE) {
        $role_id = Session::get('role_id');
        if ($role_id == 1) {
            $this->permission['add'] = 1;
            $this->permission['edit'] = 1;
            $this->permission['del'] = 1;
            $this->link['add'] = URL . "$url/add";
            $this->link['edit'] = array('View/Edit', URL . "$url/edit", $id);
            $this->link['del'] = $id;
            $this->link['publish'] = $id;
            $this->link['expre'] = FALSE;
            return;
        }
        $r = $this->db->Fetch("*", "tbl_permissions", "WHERE role_id='$role_id' AND mod_url='$url' LIMIT 0,1");
        if (!isset($r['id']) || $r['active'] == 0) {
            header("Location:" . URL . "error");
            exit;
        }

        $this->link['add'] = false;
        $this->link['edit'] = false;
        $this->link['del'] = false;
        $this->link['publish'] = false;

        $this->permission['add'] = $r['addp'];
        $this->permission['edit'] = $r['editp'];
        $this->permission['del'] = $r['delp'];
        if ($r['addp'] == 1) {
            $this->link['add'] = URL . "$url/add";
        }
        if ($r['editp'] == 1) {
            $this->link['edit'] = array('View/Edit', URL . "$url/edit", $id);
            $this->link['publish'] = $id;
        }
        if ($r['delp'] == 1) {
            $this->link['del'] = $id;
        }
        
        if($r['expre']==""){
			$this->link['expre'] = FALSE;
		} else {
				$this->link['expre'] = $r['expre'];
		}
        

        /*$ex = explode("=", $r['expre']);
        if ((isset($ex[0]) && isset($ex[1])) || (count($ex) == 2)) {
            $this->link['expre'] = "$ex[0]='$ex[1]'";
        } else {
            $this->link['expre'] = FALSE;
        }*/
    }

    public function checkPermission($function) {
        if ($this->permission[$function] == 0) {
            header("Location:" . URL . "error");
            exit;
        }
    }

	public function checkCanPermission($url,$button)
    {
        $role_id = Session::get('role_id');
        if ($role_id == 1)
        {
            return true;
        }
        else{
            $r = $this->db->Fetch("*","tbl_permissions","WHERE role_id='$role_id' AND mod_url='$url' LIMIT 0,1");
            if($r[$button]==true)
            {
              return true;
            }
            else{
              return false;
            }
        }
    }

    public function isAdmin() {
        if (Session::get("role_id") != 1) {
            header("Location:" . URL . "error");
            exit;
        }
    }

    public function getOptions($fields, $table, $query=false) {
        $r = $this->db->FetchList($fields, $table, $query);
        //return $r;
        $ret = "";
        $f = explode(",", $fields);
        //if(!isset ($r[$temp])){
        //   return '<option value="">--Error--</option>';
        //}
        if (isset($f[1])) {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] . '">' . $rec[$f[1]] . '</option>';
            }
        } else {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] . '">' . $rec[$f[0]] . '</option>';
            }
        }
        return $ret;
    }
    public function getOptions_papers($fields, $table, $query=false) {
        $r = $this->db->FetchList($fields, $table, $query);
        // return $r;
        $ret = "";
        $f = explode(",", $fields);
        //if(!isset ($r[$temp])){
        //   return '<option value="">--Error--</option>';
        //}
        if (isset($f[1])) {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] . "-".$rec[$f[2]].'">' . $rec[$f[1]] .'-'.$rec[$f[3]].'</option>';
            }
        } else {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] . '">' . $rec[$f[0]] . '</option>';
            }
        }
        return $ret;
    }

    public function Reset($url) {
        if (!isset($_SERVER['HTTP_REFERER']))
            return;
        if ($_SERVER['HTTP_REFERER'] != URL . $url) {
            Session::set('order', "");
            Session::set('page', 1);
            Session::set('condition', FALSE);
            Session::set('find', "");
        }
    }

    protected function get_Password() {
        $n = rand(7, 10);
        $p = "";
        while ($n != 0) {
            $p.=chr(rand(97, 122));
            $n--;
        }
        return $p;
    }

    public function checkExistance($table, $field, $value, $message) {
        
        $rc = $this->db->Fetch($field, $table, "WHERE $field='$value'");
        if (isset($rc[$field])) {
            return "This $message is already exist please choose another.";
        }
        return FALSE;
    }

    public static function navigation() {
        $role_id = Session::get('role_id');
        $d = new Database();
        if ($role_id == '1') {
            $mod = $d->FetchList("url,name,type,subType", "tbl_modules"," WHERE active=1 ORDER BY name");
        } else {
            $mod = $d->FetchList("mod_url,name,type,subType", "view_permissions", "WHERE role_id='$role_id' AND active=1 AND mod_active=1 ORDER BY name");
        }

        $menu = '<li><a href="' . URL . '"><i class="fa fa-dashboard"></i>Dashboard (Home)</a></li>';
        if($role_id!=158) {

        
        $menu.='<li class="sub-menu"><a href="#"><i class="fa fa-graduation-cap"></i>Academics</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "Academics") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-child"></i>Student</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "Student") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-university"></i>Central Library</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "Library" && $m['subType'] == "Central") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-book"></i>Medical Library</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "Library" && $m['subType'] == "Medical") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-h-square"></i>Helpdesk</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "HelpDesk") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-rupee"></i>Finance</a><ul class="sub">';
        foreach ($mod as $m) {
            if ($m['type'] == "Finance") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }
       /* $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-cogs"></i>Inventory</a><ul class="sub">';
            foreach ($mod as $m) {
                if ($m['type'] == "IT") {
                    $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
                }
            }
*/

         /*   $menu.='</ul></li><li class="sub-menu"><a href="#">HelpDesk</a><ul class="sub">';
            foreach ($mod as $m) {
                if ($m['type'] == "HelpDesk") {
                    $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
                }
            }

            */$menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-envelope"></i>Admissions</a><ul class="sub">';

        foreach ($mod as $m) {
            if ($m['type'] == "Admission") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
        }

            $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-th"></i>Examination</a><ul class="sub">';
            foreach ($mod as $m) {
                if ($m['type'] == "Examination") {
                    $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
                }
            }


        $menu.='</ul></li><li class="sub-menu"><a href="#"><i class="fa fa-bar-chart-o"></i>Reports</a><ul class="sub">';
         /*$menu.='<li><a href="' . URL . 'studentsgeneral">Students General</a></li>
            <li><a href="' . URL . 'statistics">Statistics</a></li>
            <li><a href="' . URL . 'graphs">Graphs</a></li>';*/
         foreach ($mod as $m) {
            if ($m['type'] == "Report") {
                $menu.='<li><a href="' . URL . $m[0] . '">' . $m[1] . '</a></li>';
            }
            }
        $menu.='</ul>
        </li>';
        /*$menu.='<li><a href="#">Help</a>
        <ul>
            <li><a href="' . URL . 'facultyhelp">Faculties</a></li>
            <li><a href="' . URL . 'depthelp">Departments</a></li>
            <li><a href="' . URL . 'coursehelp">Courses</a></li>
            <li><a href="' . URL . 'hallhelp">Halls</a></li>
            <li><a href="' . URL . 'hostelhelp">Hostels</a></li>
            <li><a href="' . URL . 'roomhelp">Rooms</a></li>
            <li><a href="' . URL . 'mischelp">Miscellenous</a></li>
            <li><a href="' . URL . 'paperhelp">Papers</a></li>
            <li><a href="' . URL . 'staffhelp">Staff</a></li>
            <li><a href="' . URL . 'statehelp">States</a></li>
        </ul>
        </li>';*/
        if ($role_id == '1') {
            $menu.='<li class="sub-menu"><a href="#"><i class="fa fa-cogs"></i>Administrator</a>
     <ul class="sub">
        <li><a href="' . URL . 'module">Modules</a></li> 
        <li><a href="' . URL . 'roles">User Roles</a>
        <li><a href="' . URL . 'permissions">Permissions</a>
        <li><a href="' . URL . 'users">Users</a></li>
        <li><a href="' . URL . 'useractivity">User Activities</a></li>
        <li><a href="' . URL . 'settings">Configuration</a></li>
     
      <!--  <li><a href="' . URL . 'databases">Databases</a></li>
        -->
        </ul>
    </li>';
        }
    }
        return $menu;
    }
    
    
    
     protected function generateReceipt($std_regn,$rect_no) {


        $rect=$this->db->Fetch("*","tbl_fee_rect", "WHERE id='$rect_no'");
        $std=$this->db->Fetch("std_name,std_father,faculty_id,dept_id,course_id","view_academics", "WHERE std_regn='$std_regn' AND active=1");
        $fee=$this->db->FetchList("*","tbl_fee_payments","WHERE rect_no='$rect_no' ORDER BY id");


        require_once(ROOT . 'libs/fpdf/fpdf.php');
        $p = array(29.8, 21);
        //$pdf = new FPDF(P, cm, $p)
        $pdf = new FPDF('P', 'cm', $p);
        $pdf->SetMargins(0, 0, 0, 0);
        $pdf->AddPage();
        $pdf->SetAutoPageBreak(0);

        //Central line
        $pdf->Line(14.9,0,14.9,21);

        //Logo
        $pdf->Image('skins/glocal/images/logo.jpg', 1, 1,3.5);
        $pdf->Image('skins/glocal/images/logo.jpg', 16, 1,3.5);


         $pdf->SetFont('Arial', '', 10);

         // Copy Details
         $pdf->SetXY(11.5,1);
         $pdf->Cell(0,0,'Office Copy');

         $pdf->SetXY(26.5,1);
         $pdf->Cell(0,0,'Student Copy');

         $pdf->SetFont('Arial', 'B', 10);

         //Receipt title and number

         $pdf->SetXY(9, 1.5);
        $pdf->Cell(0,0,'Fee Receipt #'.$rect_no);
        $pdf->SetXY(24, 1.5);
        $pdf->Cell(0,0,'Fee Receipt #'.$rect_no);


        //Details titles
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetFillColor(230,230,230);

        //Receipt details titles
        $pdf->SetXY(1, 2.5);
        $pdf->Cell(13, .5, 'Receipt Details',0,0,'C',true);
        $pdf->SetXY(16, 2.5);
        $pdf->Cell(13, .5, 'Receipt Details',0,0,'C',true);

        //Student Details titles
        $pdf->SetXY(1, 4);
        $pdf->Cell(13, .5, 'Student Details',0,0,'C',true);
        $pdf->SetXY(16, 4);
        $pdf->Cell(13, .5, 'Student Details',0,0,'C',true);

        //Fee details titles
        $pdf->SetXY(1, 5.6);
        $pdf->Cell(13, .5, 'Fee Details',0,0,'C',true);
        $pdf->SetXY(16, 5.6);
        $pdf->Cell(13, .5, 'Fee Details',0,0,'C',true);
        $pdf->SetFont('Arial', '', 8);

        //Receipt details 1
        $pdf->SetXY(1, 3.3);
        $pdf->Cell(0,0,'Date: '.$rect['date']);
        $pdf->SetXY(7.5, 3.3);
        $pdf->Cell(0,0,'Manual Receipt No.: '.$rect['man_rect_no']);
        $pdf->SetXY(1, 3.7);
        $pdf->Cell(0,0,'Payment Mode: '.$rect['payment_mode']);
        $pdf->SetXY(7.5, 3.7);
        $pdf->Cell(0,0,'Cheque/DD/Trans. No.: '.$rect['trans_no']);

        //Receipt Details 2
        $pdf->SetXY(16, 3.3);
        $pdf->Cell(0,0,'Date: '.$rect['date']);
        $pdf->SetXY(22.5, 3.3);
        $pdf->Cell(0,0,'Manual Receipt No.: '.$rect['man_rect_no']);
        $pdf->SetXY(16, 3.7);
        $pdf->Cell(0,0,'Payment Mode: '.$rect['payment_mode']);
        $pdf->SetXY(22.5, 3.7);
       $pdf->Cell(0,0,'Cheque/DD/Trans. No.: '.$rect['trans_no']);
         //$pdf->MultiCell(4,.5,'Cheque/DD/Transaction No.: '.$rect['trans_no']);

        //Student details 1
        $pdf->SetXY(1, 4.8);
        $pdf->Cell(0,0,'Enrollment No.: '.$std_regn);
        $pdf->SetXY(7.5, 4.8);
        $pdf->Cell(0,0,'Name: '.$std['std_name']);
        $pdf->SetXY(1, 5.3);
        $pdf->Cell(0,0,'Father\'s Name: '.$std['std_father']);
        $pdf->SetXY(7.5, 5.3);
        $pdf->Cell(0,0,'Course: '.$std['course_id'].' ('.$std['faculty_id'].' - '.$std['dept_id'].')');

        //Student details 2
        $pdf->SetXY(16, 4.8);
        $pdf->Cell(0,0,'Enrollment No.: '.$std_regn);
        $pdf->SetXY(22.5, 4.8);
        $pdf->Cell(0,0,'Name: '.$std['std_name']);
        $pdf->SetXY(16, 5.3);
        $pdf->Cell(0,0,'Father\'s Name: '.$std['std_father']);
        $pdf->SetXY(22.5, 5.3);
        $pdf->Cell(0,0,'Course: '.$std['course_id'].' ('.$std['faculty_id'].' - '.$std['dept_id'].')');

        //Lines
        $pdf->SetDrawColor(230,230,230);
        $pdf->Line(1,6.1,1,6.6);
        $pdf->Line(2,6.1,2,6.6);
        $pdf->Line(6,6.1,4,6.6);
        $pdf->Line(8,6.1,8,6.6);
        $pdf->Line(11,6.1,11,6.6);
        $pdf->Line(14,6.1,14,6.6);

        $pdf->Line(16,6.1,16,6.6);
        $pdf->Line(17,6.1,17,6.6);
        $pdf->Line(19,6.1,19,6.6);
        $pdf->Line(23,6.1,23,6.6);
        $pdf->Line(26,6.1,26,6.6);
        $pdf->Line(29,6.1,29,6.6);

        $pdf->Line(1,6.6,14,6.6);
        $pdf->Line(16,6.6,29,6.6);

        //Text

        $pdf->SetFont('Arial', 'B', 8);

        $pdf->SetXY(1.1, 6.4);
        $pdf->Cell(0,0,'S.No.');
        $pdf->SetXY(2.1, 6.4);
        $pdf->Cell(0,0,'Batch');
        $pdf->SetXY(4.1, 6.4);
        $pdf->Cell(0,0,'Description');
        $pdf->SetXY(8.1, 6.4);
        $pdf->Cell(0,0,'Payment(INR)');
        $pdf->SetXY(11.1, 6.4);
       // $pdf->Cell(0,0,'Discount(INR)');


        $pdf->SetXY(16.1, 6.4);
        $pdf->Cell(0,0,'S.No.');
        $pdf->SetXY(17.1, 6.4);
        $pdf->Cell(0,0,'Batch');
        $pdf->SetXY(19.1, 6.4);
        $pdf->Cell(0,0,'Description');
        $pdf->SetXY(23.1, 6.4);
        $pdf->Cell(0,0,'Payment(INR)');
        $pdf->SetXY(26.1, 6.4);
        //$pdf->Cell(0,0,'Discount(INR)');

        $pdf->SetFont('Arial', '', 8);

        $i=1;
        $gap=.5;

        $totalAmount=0;
        $totalDiscount=0;

        foreach ($fee as $f){

            $pdf->Line(1,6.1+$gap,1,6.6+$gap);
            $pdf->Line(2,6.1+$gap,2,6.6+$gap);
            $pdf->Line(4,6.1+$gap,4,6.6+$gap);
            $pdf->Line(8,6.1+$gap,8,6.6+$gap);
            $pdf->Line(11,6.1+$gap,11,6.6+$gap);
            $pdf->Line(14,6.1+$gap,14,6.6+$gap);

            $pdf->Line(16,6.1+$gap,16,6.6+$gap);
            $pdf->Line(17,6.1+$gap,17,6.6+$gap);
            $pdf->Line(19,6.1+$gap,19,6.6+$gap);
            $pdf->Line(23,6.1+$gap,23,6.6+$gap);
            $pdf->Line(26,6.1+$gap,26,6.6+$gap);
            $pdf->Line(29,6.1+$gap,29,6.6+$gap);

            $pdf->Line(1,6.6+$gap,14,6.6+$gap);
            $pdf->Line(16,6.6+$gap,29,6.6+$gap);

            //Text

            //Get Fee name
            $fname=$this->db->Fetch("name,batch_title","view_student_fees","WHERE id='".$f['student_fees_id']."'");

            $pdf->SetXY(1.1, 6.4+$gap);
            $pdf->Cell(0,0,$i.".");
            $pdf->SetXY(2.1, 6.4+$gap);
            $pdf->Cell(0,0,$fname['batch_title']);
            $pdf->SetXY(4.1, 6.4+$gap);
            $pdf->Cell(0,0,$fname['name']);
            $pdf->SetXY(8.1, 6.4+$gap);
            $pdf->Cell(2.8,0,$f['amount_paid'],0,0,'R');
            $pdf->SetXY(11.1, 6.4+$gap);
           // $pdf->Cell(2.8,0,$f['discount'],0,0,'R');


            $pdf->SetXY(16.1, 6.4+$gap);
            $pdf->Cell(0,0,$i.".");
            $pdf->SetXY(17.1, 6.4+$gap);
            $pdf->Cell(0,0,$fname['batch_title']);
            $pdf->SetXY(19.1, 6.4+$gap);
            $pdf->Cell(0,0,$fname['name']);
            $pdf->SetXY(23.1, 6.4+$gap);
            $pdf->Cell(2.8,0,$f['amount_paid'],0,0,'R');
            $pdf->SetXY(26.1, 6.4+$gap);
          //  $pdf->Cell(2.8,0,$f['discount'],0,0,'R');

            $gap+=.5;
            $i++;
            $totalAmount+=$f['amount_paid'];
            $totalDiscount+=$f['discount'];
        }


        $pdf->Line(1,6.1+$gap,1,6.6+$gap);
        $pdf->Line(8,6.1+$gap,8,6.6+$gap);
        $pdf->Line(11,6.1+$gap,11,6.6+$gap);
        $pdf->Line(14,6.1+$gap,14,6.6+$gap);

        $pdf->Line(16,6.1+$gap,16,6.6+$gap);
        $pdf->Line(23,6.1+$gap,23,6.6+$gap);
        $pdf->Line(26,6.1+$gap,26,6.6+$gap);
        $pdf->Line(29,6.1+$gap,29,6.6+$gap);

        $pdf->Line(1,6.6+$gap,14,6.6+$gap);
        $pdf->Line(16,6.6+$gap,29,6.6+$gap);

        $pdf->SetFont('Arial', 'B', 8);

        $pdf->SetXY(6.6, 6.4+$gap);
        $pdf->Cell(0,0,"Total:");
        $pdf->SetXY(8.1, 6.4+$gap);
        $pdf->Cell(2.8,0,$totalAmount,0,0,'R');
        $pdf->SetXY(11.1, 6.4+$gap);
      //  $pdf->Cell(2.8,0,$totalDiscount,0,0,'R');


        $pdf->SetXY(21.6, 6.4+$gap);
        $pdf->Cell(0,0,"Total:");
        $pdf->SetXY(23.1, 6.4+$gap);
        $pdf->Cell(2.8,0,$totalAmount,0,0,'R');
        $pdf->SetXY(26.1, 6.4+$gap);
       // $pdf->Cell(2.8,0,$totalDiscount,0,0,'R');

        //Notes

        $pdf->SetXY(1, 6.4+$gap+.5);
        $pdf->Cell(0,0,"Notes:");
        $pdf->SetXY(16, 6.4+$gap+.5);
        $pdf->Cell(0,0,"Notes:");

        $pdf->SetFont('Arial', '', 8);

        $pdf->SetXY(1, 6.4+$gap+1);
        $pdf->MultiCell(13,.5,$rect['notes']);
        $pdf->SetXY(16, 6.4+$gap+1);
        $pdf->MultiCell(13,.5,$rect['notes']);

         $pdf->SetFont('Arial', 'B', 8);
         $pdf->SetXY(1.3, 19.2);
         $pdf->Cell(0,0,$rect['received_by']);

         $pdf->SetFont('Arial', '', 8);
         $pdf->SetXY(1, 19.5);
        $pdf->Cell(0,0,"[Received By]");

         $pdf->SetFont('Arial', 'B', 8);
         $pdf->SetXY(16.3, 19.2);
         $pdf->Cell(0,0,$rect['received_by']);

		$pdf->SetFont('Arial', '', 8);
         $pdf->SetXY(16, 19.5);
        $pdf->Cell(0,0,"[Received By]");
    
         $pdf->SetXY(11, 19.5);
         $pdf->Cell(0,0,"[Authorised Signatory]");

        $pdf->SetXY(26, 19.5);
        $pdf->Cell(0,0,"[Authorised Signatory]");


        $pdf->Output();
    }

   /* public static function getFeeSum($id, $field,$field_id="student_fees_id") {
     //   $d = new Database();
       // $t = $d->Fetch(" SUM(".$field.") as total ", "tbl_fee_payments", "WHERE $field_id='$id'");
       // return $t;
       // return $t['total'];
    }*/

   public static function getFeeSum($id, $field,$field_id="student_fees_id",$rDate=false) {
        $d = new Database();
        if($rDate==true)
        {
            $t = $d->Fetch(" SUM(".$field.") as total ", "tbl_fee_payments", "WHERE $field_id='$id' AND `rDate`<='$rDate'");
        }
        else{
            $t = $d->Fetch(" SUM(".$field.") as total ", "tbl_fee_payments", "WHERE $field_id='$id'");
        }
        //  $t = $d->Fetch(" SUM(".$field.") as total ", "tbl_fee_payments", "WHERE $field_id='$id'");
        return $t['total'];
    }
    
    
    
    
    
    protected function sendEmail($to, $subject, $body, $fromEmail = 'noreply@glocal.university', $fromName = 'Glocal University')
    {
        
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

		// More headers
		$headers .= 'From: Glocal University<noreply@glocal.university>' . "\r\n";
		//$headers .= 'Cc: myboss@example.com' . "\r\n";

		return mail($to,$subject,$body,$headers);
                
        
        /*require_once(ROOT.'libs/mailer/class.phpmailer.php');

        //$this->private_email($subject,'To: '.$to.'<br/><br/>'.$body);


        $mail = new PHPMailer();

        $mail->IsSMTP(); // telling the class to use SMTP
        //$mail->Host = "mail.glocaluniversity.edu.in"; // SMTP server
//$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
// 1 = errors and messages
// 2 = messages only
        $mail->SMTPAuth = true; // enable SMTP authentication

        $mail->Host = "mail.glocal.university"; // sets the SMTP server
        $mail->Port = 25; // set the SMTP port for the GMAIL server
        $mail->Username = "admin@glocal.university"; // SMTP account username
        $mail->Password = "mM2APTlp#17xB~5"; // SMTP account password

        $mail->SetFrom($fromEmail, $fromName);

        $mail->AddReplyTo($fromEmail, $fromName);

        $mail->Subject = $subject;

//$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

        $mail->MsgHTML($body);

        $address = $to;
        $mail->AddAddress($address, $to);


        if (!$mail->Send()) {
            return "Mailer Error: " . $mail->ErrorInfo;
        } else {
            return true;
        }*/
    }

    public static function LoginInfo() {
        $d = new Database();
        $info = Session::get('user');
        $u = $d->Fetch("date,in_time,ip", "tbl_session", "WHERE username='$info' ORDER BY id DESC LIMIT 1,1");
        if (isset($u['ip'])) {
            $info = 'Last login on ' . $u[0] . ' at ' . $u[1] . ' from 
                  <a href="http://www.geoiptool.com/en/?IP=' . $u['ip'] . '" target="_blank">' . $u['ip'] . '</a>';
        } else {
            $info = "Last Login: no login history yet.";
        }
        return $info;
    }
    
    public static function getTeacher($paper_code){
        $d= new Database();
         return $d->Fetch("staff_regn,staff_name,ab_name", "view_jobassign", "WHERE paper_code='$paper_code' LIMIT 0,1");
    }

    public static function GetName($table, $field, $value, $return,$oField=false,$oValue=false) {
        $d = new Database();
        if($oField==true)
        {
            $rc = $d->Fetch($return, $table, "WHERE $field='$value' AND $oField='$oValue'");
        }
        else{
            $rc = $d->Fetch($return, $table, "WHERE $field='$value'");
        }
        //return $rc;
        return $rc[$return];
    }

    public function dateformat($date)
    {
        $date=date_create($date);
        $date=date_format($date,"Y-m-d");
        return $date;
    }

      public function RegNumUpdater($oldRegNum,$newRegNum)
    {
        if($oldRegNum && $newRegNum)
        {
            $d= new Database();
            $key="std_regn";
            $value=$oldRegNum;
            $failvalue=$newRegNum;

            $fields=array("std_regn","new","registration_num","active");
            $values=array($newRegNum,0,$oldRegNum,1);
            $failValues=array($oldRegNum,1);

            $f=array("std_regn");
            $v=array($newRegNum);
            $failv=array($oldRegNum);

            $update1=$d->Update("tbl_students",$fields,$values,$key,$value);
            if($update1) {
                $update2 = $d->Update("tbl_assign_class", $f, $v, $key, $value);
                if ($update2) {
                    $update3 = $d->Update("tbl_book_issue_stu", array("stu_id"), $v, $key, $value);
                    $update4 = $d->Update("tbl_student_fees", $f, $v, $key, $value);
                    $update5 = $d->Update("tbl_fee_rect", $f, $v, $key, $value);
                    return true;
                }
            }
            else{
                    return false;
                }
            }

    }

    public function checkConfig($check)
    {
        $d= New Database();
        $r=$d->Fetch("*","tbl_config");
        return $r[$check];
      }

      public function StudentDashboard($stdRegn)
      {
          $d= New Database();
          $students=$d->Fetch("*","tbl_students", "WHERE std_regn='$stdRegn'");
          $assignClass=$d->Fetch("*","tbl_assign_class","WHERE std_regn='$stdRegn' AND active=1 LIMIT 0,1");

          return true;
      }
      public function communication($contactNumber,$message,$type){

        $f=array('contactNumber','message','type');
        $v=array($contactNumber,$message,$type);
        return $this->db->Insert("tbl_communication_sms",$f,$v);
    }
    
     public static function imsMail($to,$subject,$body){

        $from="webmail@theglocaluniversity.in";
       if($val=sendmail($to,$subject,$body,$from)){
           return($val);
       }else{
           return($val);
       }

    }
    
    
}
