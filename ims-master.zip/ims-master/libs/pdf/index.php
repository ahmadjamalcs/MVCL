<?php
require('fpdf.php');
//$pdf = new FPDF();
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial','',10);
//$pdf->Cell(200,100,'Glocal University Marksheet',1);
$pdf->Image('background.jpg',0,0,213,297,'JPG');

$student_name="Ahmad Jamal";
$father_name="Mohd. Shahid Anwar";
$mother_name="Tabbassum Parveen";
$enrollment_number="20130001";

$year="2015";
$dept="Computer Science and Engineering";
$school="School of Technology";
$sem="5th";
$exam_held="March 2014";
$pdf->SetXY(20, 50);

$pdf->Cell(0,10,'The following are the grades obtained by '.$student_name.'',0,1);
$pdf->SetXY(20, 60);
$pdf->Cell(0,10,'Son/Daughter of '.$father_name.' and '.$mother_name.'',0,1);
$pdf->SetXY(20, 70);
$pdf->Cell(0,10,'Enrollment Number :'.$enrollment_number.'                                                                                               Year :'.$year.'',0,1);
$pdf->SetXY(20, 80);
$pdf->Cell(0,10,'of the Department of  '.$dept.'',0,1);
$pdf->SetXY(20, 90);
$pdf->Cell(0,10,'under  '.$school.' in '.$sem.' Semester examination, held in '.$exam_held.'. ',0,1);

$pdf->SetXY(20, 110);
$pdf->Cell(40,10,'Course Code',1,0,'C');
$pdf->Cell(40,10,'Subject',1,0,'C');
$pdf->Cell(40,10,'Credit',1,0,'C');

$pdf->Cell(40,10,'Grade',1,1,'C');

$pdf->SetXY(20, 120);
$table_top="120";
$i=0;
for($i=0;$i<6;$i++){
    //$pdf->SetXY(20, 130);
    $pdf->SetXY(20, $table_top);
    $pdf->Cell(40,10,'101','L',0,'C');
    $pdf->Cell(40,10,'Computer Science','L',0,'C');
    $pdf->Cell(40,10,'4','L',0,'C');
    $pdf->Cell(40,10,'A','LR',1,'C');
    $table_top+=10;
}
$pdf->SetXY(20, $table_top);
$pdf->Cell(120,10,'SGPA','1',0,'C');
$pdf->Cell(40,10,'3.2',1,1,'C');






//$pdf->Cell(60,10,'Powered by FPDF.',0,1,'C');
//$pdf->Cell(60,10,'Powered by FPDF.',0,1,'C');
$pdf->Output();
?>
