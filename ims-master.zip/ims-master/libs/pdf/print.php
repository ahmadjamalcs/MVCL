<?php
require_once 'excel/Classes/PHPExcel.php';
//error_reporting(E_ALL);
require("conn.php");
require("fpdf/fpdf.php");

function gaz12()
{
	if(isset($_POST['sub_gaz12']))
	{
		
		if($_POST['c_code']=="")
		{
			error("Please type center code.");
			return;
		}
		$code=trim($_POST['c_code']);
		$year=$_POST['year'];
		$q=mysql_query("SELECT * FROM centers WHERE code='$code'");
		if(mysql_num_rows($q)==0)
		{
			error("Center code does not exist.");
			return;
		}
		$r=mysql_fetch_array($q);
		$q2=mysql_query("select * from student where class='12' AND c_code=$code AND year='$year'");
	
		$objPHPExcel = new PHPExcel();

		$objPHPExcel->getProperties()->setCreator("Hoztech Online Services")
							 ->setLastModifiedBy("Hoztech Online Services")
							 ->setTitle("12th class gazette")
							 ->setSubject("12th class gazette for the year ".$year)
							 ->setDescription("12th class gazette for the year ".$year." of center 
							 code: ".$code);
		
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'CENTER CODE: ')
            ->setCellValue('B1', $code)
			->setCellValue('C1', 'COLLEGE NAME: ')
			->setCellValue('D1', $r['name'])
            ->setCellValue('E1', 'ADDRESS')
			->setCellValue('F1', $r['address'])
            ->setCellValue('G1', 'STATE')
			->setCellValue('H1', $r['state'])
			->setCellValue('G1', 'CLASS')
			->setCellValue('H1', 'High School')
			->setCellValue('G1', 'YEAR')
			->setCellValue('H1', $year);
			
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A3', 'SR.NO.')
            ->setCellValue('B3', 'ENROLLMENT NO.')
			->setCellValue('C3', 'ROLL NO.')
			->setCellValue('D3', 'STUDENT NAME')
            ->setCellValue('E3', 'FATHER NAME')
			->setCellValue('F3', 'MOTHER NAME')
            ->setCellValue('G3', 'SUBJECT1')
			->setCellValue('H3', 'SUBJECT2')
			->setCellValue('I3', 'SUBJECT3')
			->setCellValue('J3', 'SUBJECT4')
			->setCellValue('K3', 'SUBJECT5')
			->setCellValue('L3', 'CATEGORY')
			->setCellValue('M3', 'TOTAL')
			->setCellValue('N3', 'PERCENTAGE')
			->setCellValue('O3', 'DIVISION')
			->setCellValue('P3', 'RESULT');
			$i=1;
		$l=array('G','H','I','J','K','Z','AA','AB','AC','AD','AE','AF','AG');
		while($r2=mysql_fetch_array($q2))
		{
			$rn=$r2['rn'];
			$q3=mysql_query("select * from marks12 where rn='$rn' AND year='$year'");
			$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.($i+3), $i)
            ->setCellValue('B'.($i+3), $r2['s_no'])
			->setCellValue('C'.($i+3), $r2['rn'])
			->setCellValue('D'.($i+3), $r2['name'])
            ->setCellValue('E'.($i+3), $r2['father'])
			->setCellValue('F'.($i+3), $r2['mother']);
			$j=0;
			$mmTotal=0;
			$omTotal=0;
			while($r3=mysql_fetch_array($q3))
			{
				$objPHPExcel->setActiveSheetIndex(0)
            	->setCellValue($l[$j].($i+3),$r3['s_name'].', '.($r3['mo']+$r3['pm']).'/'.($r3['mm']+$r3['pmm']) );
				$mmTotal+=($r3['mm']+$r3['pmm']);
				$omTotal+=($r3['mo']+$r3['pm']);
				$j++;
			}
			$per=0;
			$div="";
			$res="";
			if($mmTotal==500)
			{
				$per=round(($omTotal*100)/$mmTotal,1);
				$div=res1($per);
				$res=res2($per);
			}
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('L'.($i+3), $r2['cat'])
				->setCellValue('M'.($i+3), $omTotal.'/'.$mmTotal)
				->setCellValue('N'.($i+3), $per)
				->setCellValue('O'.($i+3), $div)
				->setCellValue('P'.($i+3), $res);
			$i++;
		}
			
		$objPHPExcel->setActiveSheetIndex(0);

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
		$objWriter->save('gazettes/12th_'.$code.'_'.$year.'.xlsx');
		
		echo '<h3>Gazette generated! <a href="gazettes/12th_'.$code.'_'.$year.'.xlsx">Click here</a> to download.</h3>';
	}
}

function gaz10()
{
	if(isset($_POST['sub_gaz10']))
	{
		
		if($_POST['c_code']=="")
		{
			error("Please type center code.");
			return;
		}
		$code=trim($_POST['c_code']);
		$year=$_POST['year'];
		$q=mysql_query("SELECT * FROM centers WHERE code='$code'");
		if(mysql_num_rows($q)==0)
		{
			error("Center code does not exist.");
			return;
		}
		$r=mysql_fetch_array($q);
		$q2=mysql_query("select * from student where class='10' AND c_code=$code AND year='$year'");
	
		$objPHPExcel = new PHPExcel();

		$objPHPExcel->getProperties()->setCreator("Hoztech Online Services")
							 ->setLastModifiedBy("Hoztech Online Services")
							 ->setTitle("10th class gazette")
							 ->setSubject("10th class gazette for the year ".$year)
							 ->setDescription("10th class gazette for the year ".$year." of center 
							 code: ".$code)
							 ->setKeywords("Board of secondary education madhya bharat gwalior")
							 ->setCategory("Board of secondary education madhya bharat gwalior");
		
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'CENTER CODE: ')
            ->setCellValue('B1', $code)
			->setCellValue('C1', 'COLLEGE NAME: ')
			->setCellValue('D1', $r['name'])
            ->setCellValue('E1', 'ADDRESS')
			->setCellValue('F1', $r['address'])
            ->setCellValue('G1', 'STATE')
			->setCellValue('H1', $r['state'])
			->setCellValue('G1', 'CLASS')
			->setCellValue('H1', 'High School')
			->setCellValue('G1', 'YEAR')
			->setCellValue('H1', $year);
			
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A3', 'SR.NO.')
            ->setCellValue('B3', 'ENROLLMENT NO.')
			->setCellValue('C3', 'ROLL NO.')
			->setCellValue('D3', 'STUDENT NAME')
            ->setCellValue('E3', 'FATHER NAME')
			->setCellValue('F3', 'MOTHER NAME')
            ->setCellValue('G3', 'SUBJECT1')
			->setCellValue('H3', 'SUBJECT2')
			->setCellValue('I3', 'SUBJECT3')
			->setCellValue('J3', 'SUBJECT4')
			->setCellValue('K3', 'SUBJECT5')
			->setCellValue('L3', 'SUBJECT6')
			->setCellValue('M3', 'CATEGORY')
			->setCellValue('N3', 'TOTAL')
			->setCellValue('O3', 'PERCENTAGE')
			->setCellValue('P3', 'DIVISION')
			->setCellValue('Q3', 'RESULT');
			$i=1;
		$l=array('G','H','I','J','K','L','Z','AA','AB','AC','AD','AE','AF','AG');
		while($r2=mysql_fetch_array($q2))
		{
			$rn=$r2['rn'];
			$q3=mysql_query("select * from marks10 where rn='$rn' AND year='$year'");
			$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.($i+3), $i)
            ->setCellValue('B'.($i+3), $r2['s_no'])
			->setCellValue('C'.($i+3), $r2['rn'])
			->setCellValue('D'.($i+3), $r2['name'])
            ->setCellValue('E'.($i+3), $r2['father'])
			->setCellValue('F'.($i+3), $r2['mother']);
			$j=0;
			$mmTotal=0;
			$omTotal=0;
			while($r3=mysql_fetch_array($q3))
			{
				$objPHPExcel->setActiveSheetIndex(0)
            	->setCellValue($l[$j].($i+3),$r3['s_name'].', '.($r3['mo']+$r3['pm']).'/'.($r3['mm']+$r3['pmm']) );
				$mmTotal+=($r3['mm']+$r3['pmm']);
				$omTotal+=($r3['mo']+$r3['pm']);
				$j++;
			}
			$per=0;
			$div="";
			$res="";
			if($mmTotal==600)
			{
				$per=round(($omTotal*100)/$mmTotal,1);
				$div=res1($per);
				$res=res2($per);
			}
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('M'.($i+3), $r2['cat'])
				->setCellValue('N'.($i+3), $omTotal.'/'.$mmTotal)
				->setCellValue('O'.($i+3), $per)
				->setCellValue('P'.($i+3), $div)
				->setCellValue('Q'.($i+3), $res);
			$i++;
		}
			
		$objPHPExcel->setActiveSheetIndex(0);

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
		$objWriter->save('gazettes/10th_'.$code.'_'.$year.'.xlsx');
		
		echo '<h3>Gazette generated! <a href="gazettes/10th_'.$code.'_'.$year.'.xlsx">Click here</a> to download.</h3>';
	}
}

function mrk10()
{	
	$p=array(19.4,15.2);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetXY(2,2.3);
	$pdf->Cell(0,0,$_POST['s_no']);
	$pdf->SetXY(13,3.15);
	$pdf->Cell(0,0,'('.$_POST['dob'].')');
	
	$pdf->SetXY(16.1,3.8);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(3.5,3);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(6.5,3.6);
	$pdf->Cell(0,0,$_POST['mother']);

	$pdf->SetXY(6.5,4.2);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(4.3,4.8);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(17.2,5.5);
	$pdf->Cell(0,0,$_POST['c_code']);
	
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(1.8,$y);
		$pdf->Cell(0,0,$_POST['s-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(2.8,$y);
		$pdf->Cell(0,0,$_POST['sub-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(6.8,$y);
		$pdf->Cell(0,0,$_POST['mm-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(8.9,$y);
		$pdf->Cell(0,0,$_POST['th-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(10.5,$y);
		$pdf->Cell(0,0,$_POST['pr-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(11.5,$y);
		$pdf->Cell(0,0,$_POST['ttl-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(12.5,$y);
		$pdf->Cell(0,0,$_POST['wrd-'.$i.'']);
		$y+=.5;
	}
	$y=7.8;
	for($i=1;$i<=6;$i++)
	{
		$pdf->SetXY(15.6,$y);
		$pdf->Cell(0,0,$_POST['grd-'.$i.'']);
		$y+=.5;
	}
	
	$pdf->SetXY(14.6,5.8);
	$pdf->MultiCell(1.5,.5,$_POST['cat']);
	
	$pdf->SetXY(17,8);
	$pdf->MultiCell(1.8,.5,$_POST['pos']);
	
	$pdf->SetXY(12.1,11.7);
	$pdf->Cell(0,0,$_POST['total']);
	
	$pdf->SetXY(16,11.6);
	$pdf->Cell(0,0,$_POST['result']);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(4,14);
	$pdf->Cell(0,0,$_POST['date']);
	$pdf->Output();
}
function mc10()
{
	$p=array(20,26.5);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetXY(4.3,6.8);
	$pdf->Cell(0,0,$_POST['s_no']);
	
	$pdf->SetXY(6,12.5);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(14.7,14.3);
	$pdf->Cell(0,0,$_POST['mother']);
	
	$pdf->SetXY(3.5,14.2);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(3,15.8);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(4,16.6);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(10.5,17.7);
	$pdf->Cell(0,0,$_POST['class']);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(3.5,-2.5);
	$pdf->Cell(0,0,$_POST['date']);
	
	$pdf->Output();
}
function cer10()
{
	$p=array(18.6,30.4);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(4.5,2.9);
	$pdf->Cell(0,0,$_POST['s_no']);
	
	$file='../student_images/'.$_POST['rn'].'10.jpg';
	if(file_exists($file)){ 
		$pdf->Image($file,13.9,5,3.5,4);
	}
	$pdf->SetXY(7,9.8);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(3.5,12);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(3.5,13.2);
	$pdf->Cell(0,0,$_POST['mother']);
	
	$pdf->SetXY(3.5,14.3);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(4,15.7);
	$pdf->Cell(0,0,$_POST['dobw'].' ('.$_POST['dob'].')');
	
	$pdf->SetXY(4,18.2);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(2.5,20.4);
	$pdf->Cell(0,0,$_POST['sub-1']);
	
	$pdf->SetXY(8,20.4);
	$pdf->Cell(0,0,$_POST['sub-2']);
	
	$pdf->SetXY(14,20.4);
	$pdf->Cell(0,0,$_POST['sub-3']);
	
	$pdf->SetXY(2.5,21.4);
	$pdf->Cell(0,0,$_POST['sub-4']);
	
	$pdf->SetXY(8,21.4);
	$pdf->Cell(0,0,$_POST['sub-5']);
	
	$pdf->SetXY(14,21.4);
	$pdf->Cell(0,0,$_POST['sub-6']);
	
	$pdf->SetXY(4,23.3);
	$pdf->Cell(0,0,$_POST['div']);
	
	$pdf->SetXY(3.5,26.3);
	$pdf->Cell(0,0,$_POST['date']);
	
	$pdf->SetXY(9,26.3);
	$pdf->Cell(0,0,$_POST['cat']);
	
	$pdf->Output();
	
}
function mrk12()
{
	$p=array(19.1,15);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetXY(1.3,2.3);
	$pdf->Cell(0,0,$_POST['s_no']);
	
	$pdf->SetXY(16,4);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(4,3.3);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(6.5,4);
	$pdf->Cell(0,0,$_POST['mother']);

	$pdf->SetXY(6.5,4.5);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(5,5);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(17.5,5.6);
	$pdf->Cell(0,0,$_POST['c_code']);
	
	$subjects=5;
	if($_POST['c_code']=='412' || $_POST['c_code']=='410'){ $subjects=6; }
	
	
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(1.8,$y);
		$pdf->Cell(0,0,$_POST['s-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(3,$y);
		$pdf->Cell(0,0,$_POST['sub-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(7,$y);
		$pdf->Cell(0,0,$_POST['mm-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(8.6,$y);
		$pdf->Cell(0,0,$_POST['th-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(10.3,$y);
		$pdf->Cell(0,0,$_POST['pr-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(11.3,$y);
		$pdf->Cell(0,0,$_POST['ttl-'.$i.'']);
		$y+=.5;
	}
	$y=7.5;
	
	
	for($i=1;$i<=$subjects;$i++)
	{
		$pdf->SetXY(12.5,$y);
		$pdf->Cell(0,0,$_POST['wrd-'.$i.'']);
		$y+=.5;
	}
	
	$pdf->SetXY(14.9,5.5);
	$pdf->MultiCell(1.5,.5,$_POST['cat']);
	
	$pdf->SetXY(16.5,7.8);
	$pdf->MultiCell(1.8,.5,$_POST['pos']);
	
	$pdf->SetXY(12.3,11.2);
	$pdf->Cell(0,0,$_POST['total']);
	
	$pdf->SetXY(16,11.2);
	$pdf->Cell(0,0,$_POST['result']);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(3.5,13.8);
	$pdf->Cell(0,0,$_POST['date']);
	$pdf->Output();
}
function mc12()
{
	$p=array(20,26.5);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetXY(4.3,6.8);
	$pdf->Cell(0,0,$_POST['s_no']);
	
	$pdf->SetXY(6,12.5);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(14.7,14.3);
	$pdf->Cell(0,0,$_POST['mother']);
	
	$pdf->SetXY(3.5,14.2);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(3.5,15.8);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(4,16.7);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(10.7,17.7);
	$pdf->Cell(0,0,$_POST['class']);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(3.5,-2.5);
	$pdf->Cell(0,0,$_POST['date']);
	
	$pdf->Output();
}
function cer12()
{
	$p=array(18.9,30.4);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0);
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetAutoPageBreak(1,0);
	$pdf->SetXY(4,2.7);
	$pdf->Cell(0,0,$_POST['s_no']);
	
	$file='../student_images/'.$_POST['rn'].'12.jpg';
	if(file_exists($file)){ 
		$pdf->Image($file,13.9,5,3.5,4);
	}
	
	$pdf->SetXY(7,9.6);
	$pdf->Cell(0,0,$_POST['name']);
	
	$pdf->SetXY(3.5,12);
	$pdf->Cell(0,0,$_POST['rn']);
	
	$pdf->SetXY(3.5,13.2);
	$pdf->Cell(0,0,$_POST['mother']);
	
	$pdf->SetXY(3.5,14.1);
	$pdf->Cell(0,0,$_POST['father']);
	
	$pdf->SetXY(4,17);
	$pdf->Cell(0,0,$_POST['school']);
	
	$pdf->SetXY(2.5,19.7);
	$pdf->Cell(0,0,$_POST['sub-1']);
	
	$pdf->SetXY(8,19.7);
	$pdf->Cell(0,0,$_POST['sub-2']);
	
	$pdf->SetXY(14,19.7);
	$pdf->Cell(0,0,$_POST['sub-3']);
	
	$pdf->SetXY(2.5,20.7);
	$pdf->Cell(0,0,$_POST['sub-4']);
	
	$pdf->SetXY(8,20.7);
	$pdf->Cell(0,0,$_POST['sub-5']);
	
	if($_POST['c_code']=='412' || $_POST['c_code']=='410'){
		$pdf->SetXY(14,20.7);
		$pdf->Cell(0,0,$_POST['sub-6']);
	}
	
	$pdf->SetXY(4,23.2);
	$pdf->Cell(0,0,$_POST['div']);
	
	$pdf->SetXY(3.5,26);
	$pdf->Cell(0,0,$_POST['date']);
	
	$pdf->SetXY(9,26);
	$pdf->Cell(0,0,$_POST['cat']);
	
	$pdf->Output();
}
?>
