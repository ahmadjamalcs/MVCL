<?php
//require("conn.php");
require("result.php");
require("fpdf/fpdf.php");

function CheckRange($rn1,$rn2){
	if($rn1=="" || $rn2=="" || $_POST['date']==""){
		return error("Please enter all fields (Roll no From, TO and Date)");
	}
	if($rn1>$rn2){
		return error("Invalid range.");
	}	
	if(($rn2-$rn1)>50){
		return error("Please enter a valid range. (Maximum 50 records are acceptabe.)");
	}
	return TRUE;
}
function mrk10ii()
{	
	
	$rn1=1;
	$rn2=2;
	
	$date="8-11-1991";
	
	$p=array(19.4,15.2);
	$pdf=new FPDF(P,cm,$p);
	$pdf->SetMargins(0,0,0,0);
	
	$zero="";
	for($k=0;$k<25;$k++){
		$c=substr($rn1,$k,1);
		if($c!='0') { break; }
		$zero.=$c;
	}
	$rn1=(double)$rn1;
	$rn2=(double)$rn2;
	
	
		$rn=$zero.$j;
	//$q=mysql_query("select * from student where rn='$rn'");
	//$q2=mysql_query("select year from res10 where rn='$rn'");
	//$q3=mysql_query("select * from result10 where rn='$rn'");
	//if(mysql_num_rows($q)==0 || mysql_num_rows($q2)==0 || mysql_num_rows($q3)==0) { continue; }
	
	//$r=mysql_fetch_array($q);
	//$r2=mysql_fetch_assoc($q2);
	$ccode="1";
	$ccode=$r['c_code'];
	//$qs=mysql_query("SELECT name from centers WHERE code='$ccode'");
	//$rs=mysql_fetch_array($qs);
	
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->SetXY(2,2.3);
	//$pdf->Cell(0,0,$r['s_no']);
	
	$pdf->Cell(0,0,"20130001");
	
	
	$pdf->SetXY(13,3.15);
	//$pdf->Cell(0,0,'('.$r['dob'].')');
	
	$pdf->Cell(0,0,'('."7-11-1991".')');
	
	
	$pdf->SetXY(16.1,3.8);
	//$pdf->Cell(0,0,$rn);
	$pdf->Cell(0,0,"123");
	
	
	$pdf->SetXY(3.5,3);
//	$pdf->Cell(0,0,$r['name']);

	$pdf->Cell(0,0,"Ahmad Jamal");

	
	$pdf->SetXY(6.5,3.6);
//	$pdf->Cell(0,0,$r['mother']);

	$pdf->Cell(0,0,"Mother NAME");


	$pdf->SetXY(6.5,4.2);
	$pdf->Cell(0,0,"father name");
	
	$pdf->SetXY(4.3,4.8);
	$pdf->Cell(0,0,"rs_name");
	
	$pdf->SetXY(17.2,5.5);
	$pdf->Cell(0,0,"code");
    
	
	
	$subject="My subject";
	$t_mm="t mm:";
	$m_o="mo";
	$p_m="pmo";
	$t_o="tmo";
	$word="word";
	$grad="grad";
	
		
	$pdf->Output();
}
	
?>
