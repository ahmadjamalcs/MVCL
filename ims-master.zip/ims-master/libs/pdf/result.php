<?php

function div12($rn){

	$q=mysql_query("select * from student where rn='$rn'");

	$q2=mysql_query("select year from res12 where rn='$rn'");

	$q3=mysql_query("select * from result12 where rn='$rn'");

	

	$r=mysql_fetch_array($q);

		$tmm=0;

		$tom=0;

		$gr="";

	while($r3=mysql_fetch_array($q3))

	   { 

	   if($r3['pract']==1)

	   {

	   		$pmm=$r3['pmm'];

			$pm=$r3['pm'];

	   }

	   else

	   {

	   		$pmm='-';

			$pm='-';

	   }

	   $tmm2=$tmm2+($r3['mm']+$r3['pmm']);

	   $tmm=($r3['mm']+$r3['pmm']);

	   $tom=$tom+($r3['mo']+$r3['pm']);

	   $tm=$r3['mm']+$r3['pmm'];

	   $to=$r3['mo']+$r3['pm'];

	}

	$n=round(($tom*100)/$tmm2,2);

	if($n>=75 && $n<=100)		{ return 'DISTINCTION'; }

	elseif($n>=60 && $n<75)		{ return 'FIRST'; }

	elseif($n>=45 && $n<60)		{ return 'SECOND'; }

	elseif($n>=33 && $n<45)		{ return 'THIRD'; }

	elseif($n<=32)				{ return 'FAILED'; }

}

function div10($rn){

	$q=mysql_query("select * from student where rn='$rn'");

	$q2=mysql_query("select year from res10 where rn='$rn'");

	$q3=mysql_query("select * from result10 where rn='$rn'");

	$r=mysql_fetch_array($q);

		$tmm=0;

		$tom=0;

	while($r3=mysql_fetch_array($q3))

	   { 

	   if($r3['pract']==1)

	   {

	   		$pmm=$r3['pmm'];

			$pm=$r3['pm'];

	   }

	   else

	   {

	   		$pmm='-';

			$pm='-';

	   }

	   $tmm2=$tmm2+($r3['mm']+$r3['pmm']);

	   $tmm=($r3['mm']+$r3['pmm']);

	   $tom=$tom+($r3['mo']+$r3['pm']);

	   $tm=$r3['mm']+$r3['pmm'];

	   $to=$r3['mo']+$r3['pm'];

	   $g=($to*100)/$tm;

	}

	$n=round(($tom*100)/$tmm2,2);

	if($n>=75 && $n<=100)		{ return 'DISTINCTION'; }

	elseif($n>=60 && $n<75)		{ return 'FIRST'; }

	elseif($n>=45 && $n<60)		{ return 'SECOND'; }

	elseif($n>=33 && $n<45)		{ return 'THIRD'; }

	elseif($n<=32)				{ return 'FAILED'; }

}

function viewhall(){

	if(isset($_REQUEST['rn'])){

		$rn=$_REQUEST['rn'];

		if(isset($_POST['ch_photo'])){

			list($w,$h,$type,$att)=getimagesize($_FILES['photo']['tmp_name']);

			if($type != 2) { error("Please upload an Image file of .jpg extension only."); }

			elseif($w>600 || $h>800) { error("Image is too large, maximum 600x800 pixels size is allowed."); }

			else

			{

	$r=move_uploaded_file($_FILES['photo']['tmp_name'],"../student_images/".$rn.$_POST['cls'].".jpg");

				if($r) { done("Photo is changed successfully."); }

				else { error("There's an error, please try later."); }

			}

		}

		if(isset($_POST['update'])){

			$course_code=trim($_POST['course_code']);

			$study_center=trim($_POST['study_center']);

			$exam_center=trim($_POST['exam_center']);

			$r=mysql_query("UPDATE hall SET course_code='$course_code',

			study_center='$study_center',exam_center='$exam_center' 

			WHERE rn='$rn'");

			if($r) { done("Information updated successfully."); }

			else { error("There's an error, please try later."); }

		}

		$q=mysql_query("SELECT * from hall WHERE rn='$rn'");

		$q2=mysql_query("SELECT * from hall_sub WHERE rn='$rn'");

		$q3=mysql_query("SELECT s_no,name,father from student WHERE rn='$rn'");

		$r3=mysql_fetch_array($q3);

		$r=mysql_fetch_array($q);

		echo '<table width="100%" border="1" cellspacing="0" cellpadding="0">

  <tr>

    <td width="18%" rowspan="4"><img src="../images/logo3.jpg" border="0" width="130px" /></td>

    <td width="82%" align="right"><strong>Sr. No.: '.$r3['s_no'].'</strong></td>

  </tr>

  <tr>

    <td align="center"><h2>BOARD OF SECONDARY EDUCATION MADHYA BHARAT, GWALIOR</h2></td>

  </tr>

  <tr>

    <td align="center"><h3>N-13, GANDHI NAGAR, GWALIOR</h3></td>

  </tr>

  <tr>

    <td align="center"><strong>HALL TICKET FOR '.$r['sess'].' EXAMINATION</strong></td>

  </tr>

</table>

<form method="post" enctype="multipart/form-data">

<table width="100%" border="1" cellspacing="0" cellpadding="0">

  <tr>

    <td width="27%"><strong>Roll No.:</strong></td>

    <td width="57%">'.$r['rn'].'</td>

    <td width="16%" rowspan="6"><img src="../student_images/'.$r['rn'].$r['class'].'.jpg" width="140px" /><br />

<input type="file" name="photo" /> <input type="submit" name="ch_photo" value="Change Photo" /></td>

  </tr>

  <tr>

    <td><strong>Name of the Candidate:</strong></td>

    <td>'.$r3['name'].'</td>

  </tr>

  <tr>

    <td><strong>Father Name:</strong></td>

    <td>'.$r3['father'].'</td>

  </tr>

  <tr>

    <td><strong>Course Name/Code:</strong></td>

    <td>'.$r['class'].'th / <input type="text" name="course_code" value="'.$r['course_code'].'" />

	<input type="hidden" name="cls" value="'.$r['class'].'" />

	</td>

  </tr>

  <tr>

    <td><strong>Study Center:</strong></td>

    <td><input type="text" name="study_center" value="'.$r['study_center'].'" /></td>

  </tr>

  <tr>

    <td><strong>Examination Center:</strong></td>

    <td><input type="text" name="exam_center" value="'.$r['exam_center'].'" />

	 <input type="submit" name="update" value="Update Details" />

	</td>

  </tr>

</table>

</form>

<br />

<center><b>SUBJECTS APPEARING</b></center><br />

<table width="100%" border="1" cellspacing="0" cellpadding="0">

  <tr align="center">

    <td width="4%"><strong>S.No.</strong></td>

    <td width="14%"><strong>Sem/Yr</strong></td>

    <td width="21%"><strong>Subject Code</strong></td>

    <td width="46%"><strong>Subject Name</strong></td>

    <td width="15%"><strong>Date/Session</strong></td>

  </tr>';

  $i=1;

  while($r2=mysql_fetch_array($q2)){  

    echo '<tr><td>'.$i.'</td>

    <td>'.$r2['year'].'</td>

    <td>'.$r2['sub_code'].'</td>

    <td>'.$r2['sub_name'].'</td>

    <td>'.$r2['date'].'</td></tr>'; $i++;

  }

  echo '</table>

<table width="100%" border="1" cellspacing="0" cellpadding="0">

  <tr align="center">

    <td><p>&nbsp;</p>

    <p>&nbsp;</p>

    <blockquote>

      <p>Signature of the Candidate</p>

    </blockquote></td>

    <td><p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>Signature of the Principal</p></td>

    <td><br />

	<img src="../images/sign.jpg" border="0" width="100px" />

    <br>Controller of Examination</td>

  </tr>

</table>';

	}

}

function add_hall12()

{

	echo '<table border="0" width="100%"><tr><td><h3>Add New 12th Hall Ticket</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=hall12" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	

	if(@isset($_POST['add_hall12']))

	{

	

		list($w,$h,$type,$att)=getimagesize($_FILES['photo']['tmp_name']);

			if($type != 2) { error("Please upload an Image file of .jpg extension only."); }

			elseif($w>600 || $h>800) { error("Image is too large, maximum 600x800 pixels size is allowed."); }

			else

			{

		

			$rn=trim($_POST['rn']);

			$q=mysql_query("SELECT rn from student where class='12' AND rn='$rn'");

			$q2=mysql_query("SELECT rn from hall where class='12' AND rn='$rn'");

			if(mysql_num_rows($q)==0){

				error("This roll no. does not exist");

			} else if(mysql_num_rows($q2)>0){

				error("Hall ticket for this roll no. is already created.");

			} else {

					

					$sess=trim($_POST['sess']);

					$course_code=trim($_POST['course_code']);

					$study_center=trim($_POST['study_center']);

					$exam_center=trim($_POST['exam_center']);

					$class='12';

					$r=mysql_query("insert into hall

					 (rn,sess,course_code,study_center,exam_center,class) 

						values('$rn','$sess', '$course_code','$study_center','$exam_center','$class')");

					

				move_uploaded_file($_FILES['photo']['tmp_name'],"../student_images/".$rn.$class.".jpg");

					

					for($i=1;$i<=5;$i++){

						$year=trim($_POST['year'.$i]);

						$sub_code=trim($_POST['sub_code'.$i]);

						$sub_name=trim($_POST['sub_name'.$i]);

						$date=trim($_POST['date'.$i]);

						$r=mysql_query("insert into hall_sub

					 (rn,year,sub_code,sub_name,date) 

						values('$rn','$year', '$sub_code','$sub_name','$date')");

					}

					ch($r);

			}

		}

	}

echo '<form action="" method="post" enctype="multipart/form-data">

  <table width="100%" border="0">

    <tr>

      <td>Session:</td>

      <td><span id="sprytextfield1">

        <input type="text" name="sess" id="sess" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Roll No:</td>

      <td><span id="sprytextfield2">

        <input type="text" name="rn" id="rn" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Course Code:</td>

      <td><span id="sprytextfield3">

        <input type="text" name="course_code" id="course_code" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Study Center:</td>

      <td><span id="sprytextfield4">

        <input type="text" name="study_center" id="study_center" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Examination Center:</td>

      <td><span id="sprytextfield5">

        <input type="text" name="exam_center" id="exam_center" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Photo:</td>

      <td><input type="file" name="photo" id="photo" /></td>

    </tr>

  </table>

  <br />

  <table width="100%" border="0">

    <tr align="center">

      <td><strong>S.NO.</strong></td>

	  <td width="13%"><strong>Sem/Yr.</strong></td>

      <td width="14%"><strong>Subject Code</strong></td>

      <td width="54%"><strong>Subject Name</strong></td>

      <td width="19%"><strong>Date/Session</strong></td>

    </tr>';

    for($i=1;$i<=5;$i++){

		echo '<tr>

		<td>'.$i.'</td>

      <td><span id="sprytextfield'.(5+$i).'">

        <input type="text" name="year'.$i.'" id="year'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(6+$i).'">

        <input type="text" name="sub_code'.$i.'" id="sub_code'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(7+$i).'">

        <input type="text" name="sub_name'.$i.'" id="sub_name'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(8+$i).'">

        <input type="text" name="date'.$i.'" id="date'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>';

	}

  echo '</table>

  <p>

    <center><input type="submit" name="add_hall12" id="add_hall12" value="Create Ticket" /></center>

  </p>

</form>

<script type="text/javascript">

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");

var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");

var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");

var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");

var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");

var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");

var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9");

</script><br />';

}

function add_hall10()

{

	echo '<table border="0" width="100%"><tr><td><h3>Add New 10th Hall Ticket</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=hall10" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	

	if(@isset($_POST['add_hall10']))

	{

	

		list($w,$h,$type,$att)=getimagesize($_FILES['photo']['tmp_name']);

			if($type != 2) { error("Please upload an Image file of .jpg extension only."); }

			elseif($w>600 || $h>800) { error("Image is too large, maximum 600x800 pixels size is allowed."); }

			else

			{

		

			$rn=trim($_POST['rn']);

			$q=mysql_query("SELECT rn from student where class='10' AND rn='$rn'");

			$q2=mysql_query("SELECT rn from hall where class='10' AND rn='$rn'");

			if(mysql_num_rows($q)==0){

				error("This roll no. does not exist");

			} else if(mysql_num_rows($q2)>0){

				error("Hall ticket for this roll no, is already created.");

			} else {

					

					$sess=trim($_POST['sess']);

					$course_code=trim($_POST['course_code']);

					$study_center=trim($_POST['study_center']);

					$exam_center=trim($_POST['exam_center']);

					$class='10';

					$r=mysql_query("insert into hall

					 (rn,sess,course_code,study_center,exam_center,class) 

						values('$rn','$sess', '$course_code','$study_center','$exam_center','$class')");

					

				move_uploaded_file($_FILES['photo']['tmp_name'],"../student_images/".$rn.$class.".jpg");

					

					for($i=1;$i<=6;$i++){

						$year=trim($_POST['year'.$i]);

						$sub_code=trim($_POST['sub_code'.$i]);

						$sub_name=trim($_POST['sub_name'.$i]);

						$date=trim($_POST['date'.$i]);

						$r=mysql_query("insert into hall_sub

					 (rn,year,sub_code,sub_name,date) 

						values('$rn','$year', '$sub_code','$sub_name','$date')");

					}

					ch($r);

			}

		}

	}

echo '<form action="" method="post" enctype="multipart/form-data">

  <table width="100%" border="0">

    <tr>

      <td>Session:</td>

      <td><span id="sprytextfield1">

        <input type="text" name="sess" id="sess" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Roll No:</td>

      <td><span id="sprytextfield2">

        <input type="text" name="rn" id="rn" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Course Code:</td>

      <td><span id="sprytextfield3">

        <input type="text" name="course_code" id="course_code" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Study Center:</td>

      <td><span id="sprytextfield4">

        <input type="text" name="study_center" id="study_center" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Examination Center:</td>

      <td><span id="sprytextfield5">

        <input type="text" name="exam_center" id="exam_center" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Photo:</td>

      <td><input type="file" name="photo" id="photo" /></td>

    </tr>

  </table>

  <br />

  <table width="100%" border="0">

    <tr align="center">

      <td><strong>S.NO.</strong></td>

	  <td width="13%"><strong>Sem/Yr.</strong></td>

      <td width="14%"><strong>Subject Code</strong></td>

      <td width="54%"><strong>Subject Name</strong></td>

      <td width="19%"><strong>Date/Session</strong></td>

    </tr>';

    for($i=1;$i<=6;$i++){

		echo '<tr>

		<td>'.$i.'</td>

      <td><span id="sprytextfield'.(5+$i).'">

        <input type="text" name="year'.$i.'" id="year'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(6+$i).'">

        <input type="text" name="sub_code'.$i.'" id="sub_code'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(7+$i).'">

        <input type="text" name="sub_name'.$i.'" id="sub_name'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

      <td><span id="sprytextfield'.(8+$i).'">

        <input type="text" name="date'.$i.'" id="date'.$i.'" />

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>';

	}

  echo '</table>

  <p>

    <center><input type="submit" name="add_hall10" id="add_hall10" value="Create Ticket" /></center>

  </p>

</form>

<script type="text/javascript">

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");

var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");

var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");

var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");

var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");

var sprytextfield8 = new Spry.Widget.ValidationTextField("sprytextfield8");

var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9");

</script><br />';

}

function hall10(){

	echo '<table border="0" width="100%"><tr><td><h3>Hall Tickets for High School</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=add_hall10"><img src="add.gif" border="0" /></a>

	</td></tr></table>';

	if(isset($_POST['publish']))

	{

		echo publish('rn','hall');

	}

	if(isset($_POST['unpublish']))

	{

		echo unpublish('rn','hall');

	}

	if(isset($_POST['p_all']))

	{

		echo publish_all('hall');

	}

	if(isset($_POST['u_all']))

	{

		echo unpublish_all('hall');

	}

	if(isset($_POST['delete'])) 

	{

		echo delete("rn","hall");

		delete("rn","hall_sub");

		if(isset($_POST['checkbox']))

		{

			$checkbox = $_POST['checkbox'];

			$countCheck = count($_POST['checkbox']);

			for($i=0;$i<$countCheck;$i++)

			{

				$id  = $checkbox[$i];

				unlink('../student_images/'.$id.'10.jpg');

			}

		}

	}

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$rn="";

	if(isset($_POST['roll_search'])){

		$rn=trim($_POST['roll']);

		$rn="rn='$rn' AND ";

	}

	

	$s= ($p-1)*30;

	$q=mysql_query("select * from hall where $rn class='10' limit $s, 30");

	$r2=mysql_query("select id from hall where $rn class='10'");

	echo '<br>

	<form method="post" name="search">

	Type Student Roll No.: <input type="text" name="roll" /> 

	<input type="submit" name="roll_search" value="Search" /> 

	<input type="submit" name="reset_search" value="Reset Search" />

	</form><br />

	<form method="post" name="form2" action="">

<input class="but" type="submit" name="delete" id="delete" value="Delete" onclick="return del();" />

	 <input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />

	 <table width="100%" cellspacing="0" id="tab">';

	echo '<tr><th></th><th>Roll No.</th><th>Study Center</th><th>Exam Center</th><th>Session</th><th>View</th><th>Publish</th></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td><input type="checkbox" name="checkbox[]" id="checkbox[]"  value="'.$r['rn'].'" /></td>

		<td>'.$r['rn'].'</td>

		<td>'.$r['study_center'].'</td>

		<td>'.$r['exam_center'].'</td>

		<td>'.$r['sess'].'</td>

		<td><a href="index.php?a=viewhall&rn='.$r['rn'].'">View Ticket</a></td>

		<td><img src="'.$r['pub'].'.png" /></td></tr>';

		

	}	

	echo '</table>

	

	<input class="but" type="submit" name="delete" id="delete" value="Delete" onclick="return del();" />

	<input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/30);

	echo '<center><table border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td align="left"><a href="index.php?a=hall10&page='.$pg.'">Previous Page</a></td>';



	}

	echo '<td>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align="right"><a href="index.php?a=hall10&page='.$pg.'">Next Page</a></td>';

	}

	echo '</tr></table></center>';

}

function hall12(){

	echo '<table border="0" width="100%"><tr><td><h3>Hall Tickets for Intermediate</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=add_hall12"><img src="add.gif" border="0" /></a>

	</td></tr></table>';

	if(isset($_POST['publish']))

	{

		echo publish('rn','hall');

	}

	if(isset($_POST['unpublish']))

	{

		echo unpublish('rn','hall');

	}

	if(isset($_POST['p_all']))

	{

		echo publish_all('hall');

	}

	if(isset($_POST['u_all']))

	{

		echo unpublish_all('hall');

	}

	if(isset($_POST['delete'])) 

	{

		echo delete("rn","hall");

		delete("rn","hall_sub");

		if(isset($_POST['checkbox']))

		{

			$checkbox = $_POST['checkbox'];

			$countCheck = count($_POST['checkbox']);

			for($i=0;$i<$countCheck;$i++)

			{

				$id  = $checkbox[$i];

				unlink('../student_images/'.$id.'12.jpg');

			}

		}

	}

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$rn="";

	if(isset($_POST['roll_search'])){

		$rn=trim($_POST['roll']);

		$rn="rn='$rn' AND ";

	}

	$s= ($p-1)*30;

	$q=mysql_query("select * from hall where $rn class='12' limit $s, 30");

	$r2=mysql_query("select id from hall where $rn class='12'");

	echo '<br>

	<form method="post" name="search">

	Type Student Roll No.: <input type="text" name="roll" /> 

	<input type="submit" name="roll_search" value="Search" /> 

	<input type="submit" name="reset_search" value="Reset Search" />

	</form><br />

	<form method="post" name="form2" action="">

	<input class="but" type="submit" name="delete" id="delete" value="Delete" onclick="return del();" />

	 <input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />

	 <table width="100%" cellspacing="0" id="tab">';

	echo '<tr><th></th><th>Roll No.</th><th>Study Center</th><th>Exam Center</th><th>Session</th><th>View</th><th>Publish</th></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td><input type="checkbox" name="checkbox[]" id="checkbox[]"  value="'.$r['rn'].'" /></td>

		<td>'.$r['rn'].'</td>

		<td>'.$r['study_center'].'</td>

		<td>'.$r['exam_center'].'</td>

		<td>'.$r['sess'].'</td>

		<td><a href="index.php?a=viewhall&rn='.$r['rn'].'">View Ticket</a></td>

		<td><img src="'.$r['pub'].'.png" /></td></tr>';

	}	

	echo '</table>

	<input class="but" type="submit" name="delete" id="delete" value="Delete" onclick="return del();" />

	<input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/30);

	echo '<center><table border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td align="left"><a href="index.php?a=hall12&page='.$pg.'">Previous Page</a></td>';



	}

	echo '<td>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align="right"><a href="index.php?a=hall12&page='.$pg.'">Next Page</a></td>';

	}

	echo '</tr></table></center>';

}



function view_result10()

{

	if(!isset($_REQUEST['rn'])) { return; }

	$rn=$_REQUEST['rn'];

	$q=mysql_query("select * from student where rn='$rn'");

	$q2=mysql_query("select year from res10 where rn='$rn'");

	$q3=mysql_query("select * from result10 where rn='$rn'");

	if(mysql_num_rows($q3)==0) { error("No result to display"); return; }	

	

	

	$r=mysql_fetch_array($q);

	$r2=mysql_fetch_array($q2);

	

	echo '<table width="900" border="1" align="center" cellspacing="0">

  <tr bordercolor="#969696">

    <td bordercolor="#D5D5D5"><h2 align="center">Board of Secondary Education, Madhya Bharat, Gwalior (M.P.)</h2>

      <h3 align="center">High School Result - '.$r2['year'].'</h3>

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr>

          <td width="13%" bgcolor="#EAEAEA"><strong>Roll No.</strong> :</td>

          <td width="21%">'.$r['rn'].'</td>

          <td width="13%" bgcolor="#EAEAEA"><strong>Serial No.</strong> :</td>

          <td width="21%">'.$r['s_no'].'</td>

          <td width="13%" bgcolor="#EAEAEA"><strong>Name</strong> :</td>

          <td width="20%">'.$r['name'].'</td>

        </tr>

        <tr>

          <td bgcolor="#EAEAEA"><strong>Father Name</strong>:</td>

          <td>'.$r['father'].'</td>

          <td bgcolor="#EAEAEA"><strong>Mother Name</strong>:</td>

          <td>'.$r['mother'].'</td>

          <td bgcolor="#EAEAEA"><strong>Date of Birth</strong>:</td>

          <td>'.$r['dob'].'</td>

        </tr>

        <tr>

          <td bgcolor="#EAEAEA"><strong>School</strong>:</td>

          <td>'.$r['school'].'</td>

          <td bgcolor="#EAEAEA"><strong>Center Code</strong>:</td>

          <td>'.$r['c_code'].'</td>

          <td bgcolor="#EAEAEA"><strong>Category</strong>:</td>

          <td>'.$r['cat'].'</td>

        </tr>

      </table>

      <br />

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr bgcolor="#EAEAEA">

          <td width="5%"><strong>S.No</strong></td>

          <td width="45%"><strong>Subject</strong></td>

          <td width="10%"><strong>MM</strong></td>

          <td width="10%"><strong>OM</strong></td>

          <td width="10%"><strong>PMM</strong></td>

          <td width="10%"><strong>POM</strong></td>';

		  if(intval($r2['year'])>2010){

          echo '<td width="10%"><strong>Grade</strong></td>';

		  }

        echo '</tr>';

		$i=1;

		$tmm=0;

		$tom=0;

		$gr="";

       while($r3=mysql_fetch_array($q3))

	   { 

	   if($r3['pract']==1)

	   {

	   		$pmm=$r3['pmm'];

			$pm=$r3['pm'];

	   }

	   else

	   {

	   		$pmm='-';

			$pm='-';

	   }

	   $tmm=$tmm+($r3['mm']+$r3['pmm']);

	   $tom=$tom+($r3['mo']+$r3['pm']);

	   $tm=$r3['mm']+$r3['pmm'];

	   $to=$r3['mo']+$r3['pm'];

	   $g=($to*100)/$tm;

		echo '<tr>

          <td>'.$i.'.</td>

          <td>'.$r3['s_name'].'</td>

          <td>'.$r3['mm'].'</td>

          <td>'.$r3['mo'].'</td>

          <td>'.$pmm.'</td>

          <td>'.$pm.'</td>';

          if(intval($r2['year'])>2010){

		  echo '<td>'.grade($g).'</td>';

		  }

        echo '</tr>';

		$i++;

		}

		$per=round(($tom*100)/$tmm,2);

      echo '</table>

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr bordercolor="#EAEAEA" bgcolor="#EAEAEA">

          <td width="25%"><div align="center"></div></td>

          <td width="25%"><div align="center"><strong>Total</strong></div></td>

          <td width="25%"><div align="center"><strong>Percentage</strong></div></td>

          <td width="25%"><div align="center"><strong>Result</strong></div></td>

        </tr>

        <tr>

          <td><div align="center"></div></td>

          <td><div align="center">'.$tom.'/'.$tmm.'</div></td>

          <td><div align="center">'.$per.'%</div></td>

          <td><div align="center">'.result($per).'</div></td>

        </tr>

      </table>

      <br />

      <strong>Abbreviation:</strong><br />

MM=Maximum Marks<br />

OM=Obtained Marks<br />

PMM=Practical Maximum Marks<br />

POM=Practical Obtained Marks<br /></td>

  </tr>

</table>';

	

	

	

}



function view_result12()

{

	if(!isset($_REQUEST['rn'])) { return; }

	$rn=$_REQUEST['rn'];

	$q=mysql_query("select * from student where rn='$rn'");

	$q2=mysql_query("select year from res12 where rn='$rn'");

	$q3=mysql_query("select * from result12 where rn='$rn'");

	if(mysql_num_rows($q3)==0) { error("No result to display"); return; }	

	

	

	$r=mysql_fetch_array($q);

	$r2=mysql_fetch_array($q2);

	

	echo '<table width="900" border="1" align="center" cellspacing="0">

  <tr bordercolor="#969696">

    <td bordercolor="#D5D5D5"><h2 align="center">Board of Secondary Education, Madhya Bharat, Gwalior (M.P.)</h2>

      <h3 align="center">Intermediate Result - '.$r2['year'].'</h3>

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr>

          <td width="13%" bgcolor="#EAEAEA"><strong>Roll No.</strong> :</td>

          <td width="21%">'.$r['rn'].'</td>

          <td width="13%" bgcolor="#EAEAEA"><strong>Serial No.</strong> :</td>

          <td width="21%">'.$r['s_no'].'</td>

          <td width="13%" bgcolor="#EAEAEA"><strong>Name</strong> :</td>

          <td width="20%">'.$r['name'].'</td>

        </tr>

        <tr>

          <td bgcolor="#EAEAEA"><strong>Father Name</strong>:</td>

          <td>'.$r['father'].'</td>

          <td bgcolor="#EAEAEA"><strong>Mother Name</strong>:</td>

          <td>'.$r['mother'].'</td>

          <td bgcolor="#EAEAEA"><strong>Date of Birth</strong>:</td>

          <td>'.$r['dob'].'</td>

        </tr>

        <tr>

          <td bgcolor="#EAEAEA"><strong>School</strong>:</td>

          <td>'.$r['school'].'</td>

          <td bgcolor="#EAEAEA"><strong>Center Code</strong>:</td>

          <td>'.$r['c_code'].'</td>

          <td bgcolor="#EAEAEA"><strong>Category</strong>:</td>

          <td>'.$r['cat'].'</td>

        </tr>

      </table>

      <br />

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr bgcolor="#EAEAEA">

          <td width="5%"><strong>S.No</strong></td>

          <td width="43%"><strong>Subject</strong></td>

          <td width="13%"><strong>MM</strong></td>

          <td width="13%"><strong>OM</strong></td>

          <td width="13%"><strong>PMM</strong></td>

          <td width="13%"><strong>POM</strong></td>

    

        </tr>';

		$i=1;

		$tmm=0;

		$tom=0;

       while($r3=mysql_fetch_array($q3))

	   { 

	   if($r3['pract']==1)

	   {

	   		$pmm=$r3['pmm'];

			$pm=$r3['pm'];

	   }

	   else

	   {

	   		$pmm='-';

			$pm='-';

	   }

	   $tmm=$tmm+($r3['mm']+$r3['pmm']);

	   $tom=$tom+($r3['mo']+$r3['pm']);

		echo '<tr>

          <td>'.$i.'.</td>

          <td>'.$r3['s_name'].'</td>

          <td>'.$r3['mm'].'</td>

          <td>'.$r3['mo'].'</td>

          <td>'.$pmm.'</td>

          <td>'.$pm.'</td>

        </tr>';

		$i++;

		}

		$per=round(($tom*100)/$tmm,2);

      echo '</table>

      <table width="100%" border="1" cellspacing="0" bordercolor="#D5D5D5">

        <tr bordercolor="#EAEAEA" bgcolor="#EAEAEA">

          <td width="25%"><div align="center"></div></td>

          <td width="25%"><div align="center"><strong>Total</strong></div></td>

          <td width="25%"><div align="center"><strong>Percentage</strong></div></td>

          <td width="25%"><div align="center"><strong>Result</strong></div></td>

        </tr>

        <tr>

          <td><div align="center"></div></td>

          <td><div align="center">'.$tom.'/'.$tmm.'</div></td>

          <td><div align="center">'.$per.'%</div></td>

          <td><div align="center">'.result($per).'</div></td>

        </tr>

      </table>

      <br />

      <strong>Abbreviation:</strong><br />

MM=Maximum Marks<br />

OM=Obtained Marks<br />

PMM=Practical Maximum Marks<br />

POM=Practical Obtained Marks<br /></td>

  </tr>

</table>';

}





function del_res12()

{

	$id=$_REQUEST['id'];

	$q=mysql_query("delete from result12 where id='$id'");

	if($q) {  done('Record deleted Successfully. <a href="index.php?a=result12">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }	

}



function as_sub12()

{

	$rn=$_REQUEST['rn'];

	echo '<table border="0" width="100%"><tr><td><h3>Assign Subjects to Roll No. '.$rn.'</h3></td>';

	echo '<td align="right">';

	$q=mysql_query("select * from result12 where rn='$rn'");

	if(mysql_num_rows($q)<=15)

	{

	echo '<form id="form1" name="form1" method="post" action="index.php?a=as_sub12&rn='.$rn.'">

  <table width="100%" border="0" cellspacing="1">

    <tr>

      <td>Select Subject ID:</td>

      <td>Obtained Marks:</td>

      <td>Practical Marks (If applicable):</td>

      <td>&nbsp;</td>

    </tr>

    <tr>

      <td><span id="spryselect1">

        <label>

        <select name="s_id" id="s_id">

		<option selected="selected">-Select-</option>';

        $qs=mysql_query("select id from sub12 order by id");

		while($rs=mysql_fetch_array($qs))

		{

			echo '<option value="'.$rs['id'].'">'.$rs['id'].'</option>';

		}

		echo '</select>

        </label>

      <span class="selectRequiredMsg">Please select an item.</span></span></td>

      <td><input name="mo" type="text" id="mo" size="10" value="0" /></td>

      <td><input name="pm" type="text" id="pm" size="10" value="0" /></td>

      <td><label>

        <input type="submit" name="as_sub12" id="as_sub10" value="Assign" />

      </label></td>

    </tr>

  </table>

</form>

<script type="text/javascript">

<!--

var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");

//-->

</script>';

}

	echo '</td></tr></table>';

	

	if(isset($_POST['as_sub12']))

	{

		$s_id=$_POST['s_id'];

		$q2=mysql_query("select * from sub12 where id='$s_id'");

		$r2=mysql_fetch_array($q2);

		$s_name=$r2['name'];

		$mm=$r2['mm'];

		$pract=$r2['pract'];

		$pmm=$r2['pmm'];

		$mo=$_POST['mo'];

		if($pract==1) { $pm=$_POST['pm']; } else { $pm=0; }

		

		if(mysql_query("insert into result12 (rn, s_id, s_name, mm, mo, pract, pmm, pm) values('$rn', '$s_id', '$s_name', '$mm', '$mo', '$pract', '$pmm', '$pm')"))

		{

			done("Subject Assigned successfully.");

		}

		else

		{

			error("There is an error, please try later.");

		}

		

	}

	$q=mysql_query("select * from result12 where rn='$rn' limit 0, 15");	

	echo '<br><table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td bgcolor="#00FFFF"><b>Sub. ID</b><td bgcolor="#00FFFF"><b>Subject</b></td><td bgcolor="#00FFFF"><b>Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Marks Obtained</b></td><td bgcolor="#00FFFF"><b>Prac. MM</b></td><td bgcolor="#00FFFF"><b>Prac. MO</b></td><td bgcolor="#00FFFF"><b>Delete</b></td><td bgcolor="#00FFFF"><b>Edit Marks</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td>'.$r['s_id'].'</td><td>'.$r['s_name'].'</td><td>'.$r['mm'].'</td><td>'.$r['mo'].'</td><td>'.$r['pmm'].'</td><td>'.$r['pm'].'</td><td><a href="index.php?a=del_res12&id='.$r['id'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td>

		<td><a href="index.php?a=edit_mrk12&id='.$r['id'].'&rn='.$rn.'">Edit</a></td></tr>';

	}	

	echo '</table>';

}

function del_result12()

{

	$rn=$_REQUEST['rn'];

	$q=mysql_query("delete from res12 where rn='$rn'");

	$q2=mysql_query("delete from result12 where rn='$rn'");

	if($q && q2) {  done('Result deleted Successfully. <a href="index.php?a=result12">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }

}





function result12()

{

		echo '<table border="0" width="100%"><tr><td><h3>Results for Intermediate</h3></td>';

	echo '<td align="right">

	<form id="form1" name="form1" method="post" action="index.php?a=result12">

	Select Year:

	<select name="year" id="year">';

	$y=date('Y');

	for($i=$y;$i>=1975;$i--)

	{

	echo '<option value="'.$i.'">'.$i.'</option>';

	}

	echo '</select>

  Enter Roll No. : 

  <label><span id="sprytextfield1">

  <input type="text" name="rn" id="rn" />

  <br />

  <span class="textfieldRequiredMsg">A value is required.</span></span></label>

  <label>

  <input type="submit" name="add_res12" id="add_res12" value="Add" />

  </label>

</form>

<script type="text/javascript">

<!--

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

//-->

</script>

	</td></tr></table>';

	if(isset($_POST['add_res12']))

	{

		$rn=$_POST['rn'];

		$year=$_POST['year'];

		$r=mysql_query("select rn from student where class=12 AND rn='$rn'");

		$r2=mysql_query("select * from res12 where rn='$rn'");

		

		if(mysql_num_rows($r)==0) { error("This roll no does not exist."); }

		elseif(mysql_num_rows($r2)>0) { error("The result for this roll no is already exist."); }

		else 

		{ 

			if(mysql_query("insert into res12(rn,year) values ('$rn','$year')"))

			{

				done("Result Created");

			}

			 else

			 {

			 	error("There is an error.");

			 }



		}

	}

	

	echo '<form name="s_res" method="post" action="index.php?a=result12">

    <table width="240px" border="0" cellspacing="2">

    <tr>

    <td width="120px">Enter Roll No.</td>

    <td width="120px"></td>

    </tr>

    <tr>

    <td width="120px"><input type="text" name="keyw" id="keyw" /></td>

    <td width="120px"><input type="submit" name="search" id="search" value="Go!" />

    <a href="index.php?a=result12" title="Clear Search">Reset</a>

    </td>

    </tr>

    </table>

    </form>';

	if(isset($_POST['publish']))

	{

		echo publish('rn','res12');

	}

	if(isset($_POST['unpublish']))

	{

		echo unpublish('rn','res12');

	}

	if(isset($_POST['p_all']))

	{

		echo publish_all('res12');

	}

	if(isset($_POST['u_all']))

	{

		echo unpublish_all('res12');

	}

	$lm=30;	

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$s= ($p-1)*$lm;

	if(isset($_POST['search']))

	{

		$k=$_POST['keyw'];

		$qr="select * from res12 where rn='$k' limit $s, $lm";

		$qr2="select * from res12 where rn='$k'";

	}

	else

	{

		$qr="select * from res12 order by id desc limit $s, $lm";

		$qr2="select * from res12";

	}



	$q=mysql_query($qr);

	$r2=mysql_query($qr2);

	echo '<form method="post" enctype="multipart/form-data">';

	echo '<input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />

	<table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td></td><td bgcolor="#00FFFF"><b>Year</b></td><td bgcolor="#00FFFF"><b>Student Roll No.</b></td><td bgcolor="#00FFFF"><b>Subjects</b></td><td bgcolor="#00FFFF"><b>View Complete Result</b></td><td bgcolor="#00FFFF"><b>Delete</b></td><td bgcolor="#00FFFF"><b>Publish</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td><input type="checkbox" name="checkbox[]" id="checkbox[]"  value="'.$r['rn'].'" /></td><td>'.$r['year'].'</td><td>'.$r['rn'].'</td><td><a href="index.php?a=as_sub12&rn='.$r['rn'].'">Assign Subjects</a></td><td><a href="index.php?a=view_result12&rn='.$r['rn'].'" target="_blank">View Result</a></td><td><a href="index.php?a=del_result12&rn='.$r['rn'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td><td><img src="'.$r['pub'].'.png" /></td></tr>';

	}	

	echo '</table></form>';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/$lm);

	echo '<table align="center" border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td><a href="index.php?a=result12&page='.$pg.'" title="Previous Page"><img src="p.jpg" border="0" /></a></td>';

	}

	echo '<td align=center>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align=right><a href="index.php?a=result12&page='.$pg.'" title="Next Page"><img src="n.jpg" border="0" /></a></td>';

	}

	echo '</tr></table>';

}





function del_res10()

{

	$id=$_REQUEST['id'];

	$q=mysql_query("delete from result10 where id='$id'");

	if($q) {  done('Record deleted Successfully. <a href="index.php?a=result10">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }	

}



function as_sub10()

{

	$rn=$_REQUEST['rn'];

	

	echo '<table border="0" width="100%"><tr><td><h3>Assign Subjects to Roll No. '.$rn.'</h3></td>';

	echo '<td align="right">';

	$q=mysql_query("select * from result10 where rn='$rn'");

	if(mysql_num_rows($q)<=15)

	{

	echo '<form id="form1" name="form1" method="post" action="index.php?a=as_sub10&rn='.$rn.'">

  <table width="100%" border="0" cellspacing="1">

    <tr>

      <td>Select Subject ID:</td>

      <td>Obtained Marks:</td>

      <td>Practical Marks (If applicable):</td>

      <td>&nbsp;</td>

    </tr>

    <tr>

      <td><span id="spryselect1">

        <label>

        <select name="s_id" id="s_id">

		<option selected="selected">-Select-</option>';

        $qs=mysql_query("select id from sub10 order by id");

		while($rs=mysql_fetch_array($qs))

		{

			echo '<option value="'.$rs['id'].'">'.$rs['id'].'</option>';

		}

		echo '</select>

        </label>

      <span class="selectRequiredMsg">Please select an item.</span></span></td>

      <td>

        <input name="mo" type="text" id="mo" size="10" value="0" />

        </td>

      <td>

        <input name="pm" type="text" id="pm" size="10" value="0" />

        </td>

      <td><label>

        <input type="submit" name="as_sub10" id="as_sub10" value="Assign" />

      </label></td>

    </tr>

  </table>

</form>

<script type="text/javascript">

<!--

var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");

//-->

</script>';

}

	echo '</td></tr></table>';

	

	if(isset($_POST['as_sub10']))

	{

		$s_id=$_POST['s_id'];

		$q2=mysql_query("select * from sub10 where id='$s_id'");

		$r2=mysql_fetch_array($q2);

		$s_name=$r2['name'];

		$mm=$r2['mm'];

		$pract=$r2['pract'];

		$pmm=$r2['pmm'];

		$mo=$_POST['mo'];

		if($pract==1) { $pm=$_POST['pm']; } else { $pm=0; }

		

		if(mysql_query("insert into result10 (rn, s_id, s_name, mm, mo, pract, pmm, pm) values('$rn', '$s_id', '$s_name', '$mm', '$mo', '$pract', '$pmm', '$pm')"))

		{

			done("Subject Assigned successfully.");

		}

		else

		{

			error("There is an error, please try later.");

		}

		

	}

	$q=mysql_query("select * from result10 where rn='$rn' limit 0, 15");	

	echo '<br><table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td bgcolor="#00FFFF"><b>Sub. ID</b><td bgcolor="#00FFFF"><b>Subject</b></td><td bgcolor="#00FFFF"><b>Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Marks Obtained</b></td><td bgcolor="#00FFFF"><b>Prac. MM</b></td><td bgcolor="#00FFFF"><b>Prac. MO</b></td><td bgcolor="#00FFFF"><b>Delete</b></td><td bgcolor="#00FFFF"><b>Edit Marks</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td>'.$r['s_id'].'</td><td>'.$r['s_name'].'</td><td>'.$r['mm'].'</td><td>'.$r['mo'].'</td><td>'.$r['pmm'].'</td><td>'.$r['pm'].'</td><td><a href="index.php?a=del_res10&id='.$r['id'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td><td><a href="index.php?a=edit_mrk10&id='.$r['id'].'&rn='.$rn.'">Edit</a></td></tr>';

	}	

	echo '</table>';

}

function edit_mrk10()

{

	$rn=$_REQUEST['rn'];

	$id=$_REQUEST['id'];

	echo '<table border="0" width="100%"><tr><td><h3>Edit Marks for Roll No.: '.$rn.'</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=as_sub10&rn='.$rn.'" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	if($_POST['sub']) 

	{

		if($_POST['pract']==1) { $pm=$_POST['pm']; } else { $pm=0; }

		$mo=$_POST['mo'];

		if(mysql_query("UPDATE result10 set mo=$mo,pm=$pm where id=$id")) {

			done("Marks updated successfully.");

		} else {

			error("There is an error: ".mysql_error());

		}

	}

	$q=mysql_query("SELECT mo,pm,pract from result10 where id=$id");

	$r=mysql_fetch_array($q);

	echo '<form method="post" style="padding-left:50px;">';

	echo 'Obtained Marks: <input type="text" name="mo" value="'.$r['mo'].'" /><br />';

	echo 'Obtained Marks: <input type="text" name="pm" value="'.$r['pm'].'" /><br />';

	echo 'Obtained Marks: <input type="hidden" name="pract" value="'.$r['pract'].'" />';

	echo '<input type="submit" name="sub" value="Update" /></form><br />';

}

function edit_mrk12()

{

	$rn=$_REQUEST['rn'];

	$id=$_REQUEST['id'];

	echo '<table border="0" width="100%"><tr><td><h3>Edit Marks for Roll No.: '.$rn.'</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=as_sub12&rn='.$rn.'" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	if($_POST['sub']) 

	{

		if($_POST['pract']==1) { $pm=$_POST['pm']; } else { $pm=0; }

		$mo=$_POST['mo'];

		if(mysql_query("UPDATE result12 set mo=$mo,pm=$pm where id=$id")) {

			done("Marks updated successfully.");

		} else {

			error("There is an error: ".mysql_error());

		}

	}

	$q=mysql_query("SELECT mo,pm,pract from result12 where id=$id");

	$r=mysql_fetch_array($q);

	echo '<form method="post" style="padding-left:50px;">';

	echo 'Obtained Marks: <input type="text" name="mo" value="'.$r['mo'].'" /><br />';

	echo 'Obtained Marks: <input type="text" name="pm" value="'.$r['pm'].'" /><br />';

	echo 'Obtained Marks: <input type="hidden" name="pract" value="'.$r['pract'].'" />';

	echo '<input type="submit" name="sub" value="Update" /></form><br />';

}

function del_result10()

{

	$rn=$_REQUEST['rn'];

	$q=mysql_query("delete from res10 where rn='$rn'");

	$q2=mysql_query("delete from result10 where rn='$rn'");

	if($q && q2) {  done('Result deleted Successfully. <a href="index.php?a=result10">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }

}





function result10()

{

		echo '<table border="0" width="100%"><tr><td><h3>Results for High School</h3></td>';

	echo '<td align="right">

	<form id="form1" name="form1" method="post" action="index.php?a=result10">

  Select Year:

	<select name="year" id="year">';

	$y=date('Y');

	for($i=$y;$i>=1975;$i--)

	{

	echo '<option value="'.$i.'">'.$i.'</option>';

	}

	echo '</select>

  Enter Roll No. : 

  <label><span id="sprytextfield1">

  <input type="text" name="rn" id="rn" />

  <br />

  <span class="textfieldRequiredMsg">A value is required.</span></span></label>

  <label>

  <input type="submit" name="add_res10" id="add_res10" value="Add" />

  </label>

</form>

<script type="text/javascript">

<!--

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

//-->

</script>

	</td></tr></table>';

	if(isset($_POST['add_res10']))

	{

		$rn=$_POST['rn'];

		$year=$_POST['year'];

		$r=mysql_query("select rn from student where class=10 AND rn='$rn'");

		$r2=mysql_query("select * from res10 where rn='$rn'");

		

		if(mysql_num_rows($r)==0) { error("This roll no does not exist."); }

		elseif(mysql_num_rows($r2)>0) { error("The result for this roll no is already exist."); }

		else 

		{ 

			if(mysql_query("insert into res10(rn,year) values ('$rn','$year')"))

			{

				done("Result Created");

			}

			 else

			 {

			 	error("There is an error.");

			 }



		}

	}	

	echo '<form name="s_res" method="post" action="index.php?a=result10">

    <table width="240px" border="0" cellspacing="2">

    <tr>

    <td width="120px">Enter Roll No.</td>

    <td width="120px"></td>

    </tr>

    <tr>

    <td width="120px"><input type="text" name="keyw" id="keyw" /></td>

    <td width="120px"><input type="submit" name="search" id="search" value="Go!" />

    <a href="index.php?a=result10" title="Clear Search">Reset</a>

    </td>

    </tr>

    </table>

    </form>';

	if(isset($_POST['publish']))

	{

		echo publish('rn','res10');

	}

	if(isset($_POST['unpublish']))

	{

		echo unpublish('rn','res10');

	}

	if(isset($_POST['p_all']))

	{

		echo publish_all('res10');

	}

	if(isset($_POST['u_all']))

	{

		echo unpublish_all('res10');

	}

	$lm=30;

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$s= ($p-1)*$lm;

	

	if(isset($_POST['search']))

	{

		$k=$_POST['keyw'];

		$qr="select * from res10 where rn='$k' limit $s, $lm";

		$qr2="select * from res10 where rn='$k'";

	}

	else

	{

		$qr="select * from res10 order by id desc limit $s, $lm";

		$qr2="select * from res10";

	}

	$q=mysql_query($qr);

	$r2=mysql_query($qr2);

	echo '<form method="post" enctype="multipart/form-data">

	<input class="but" type="submit" name="publish" id="publish" value="Publish" />

	 <input class="but" type="submit" name="unpublish" id="unpublish" value="Unpublish" />

	 <input class="but" type="submit" name="p_all" value="Publish All" />

	 <input class="but" type="submit" name="u_all" value="Unpublish All" />';

	echo '<table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td></td><td bgcolor="#00FFFF"><b>Year</b><td bgcolor="#00FFFF"><b>Student Roll No.</b></td><td bgcolor="#00FFFF"><b>Subjects</b></td><td bgcolor="#00FFFF"><b>View Complete Result</b></td><td bgcolor="#00FFFF"><b>Delete</b></td><td bgcolor="#00FFFF"><b>Publish</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td><input type="checkbox" name="checkbox[]" id="checkbox[]"  value="'.$r['rn'].'" /></td><td>'.$r['year'].'</td><td>'.$r['rn'].'</td><td><a href="index.php?a=as_sub10&rn='.$r['rn'].'">Assign Subjects</a></td><td><a href="index.php?a=view_result10&rn='.$r['rn'].'" target="_blank">View Result</a></td><td><a href="index.php?a=del_result10&rn='.$r['rn'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td><td><img src="'.$r['pub'].'.png" /></td></tr>';

	}	

	echo '</table></form>';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/$lm);

	echo '<table align="center" border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td><a href="index.php?a=result10&page='.$pg.'" title="Previous Page"><img src="p.jpg" border="0" /></a></td>';

	}

	echo '<td align=center>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align=right><a href="index.php?a=result10&page='.$pg.'" title="Next Page"><img src="n.jpg" border="0" /></a></td>';

	}

	echo '</tr></table>';

}

function del_sub12()

{

	$id=$_REQUEST['id'];

	$q=mysql_query("delete from sub12 where id='$id'");

	if($q) {  done('Subject deleted Successfully. <a href="index.php?a=sub12">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }	

}

function sub12()

{

	echo '<table border="0" width="100%"><tr><td><h3>Subjects for Intermediate</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=add_sub12"><img src="add.gif" border="0" /></a>

	</td></tr></table>';

	

	$lm=30;

	

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$s= ($p-1)*$lm;

	$q=mysql_query("select * from sub12 limit $s, $lm");

	$r2=mysql_query("select id from sub12");

	echo '<br><table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td bgcolor="#00FFFF"><b>ID</b></td><td bgcolor="#00FFFF"><b>Name</b></td><td bgcolor="#00FFFF"><b>Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Practical Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Delete</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td>'.$r['id'].'</td><td>'.$r['name'].'</td><td>'.$r['mm'].'</td><td>'.$r['pmm'].'</td><td><a href="index.php?a=del_sub12&id='.$r['id'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td></tr>';

	}	

	echo '</table>';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/$lm);

	echo '<table align="center" border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td><a href="index.php?a=sub12&page='.$pg.'" title="Previous Page"><img src="p.jpg" border="0" /></a></td>';

	}

	echo '<td align=center>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align=right><a href="index.php?a=sub12&page='.$pg.'" title="Next Page"><img src="n.jpg" border="0" /></a></td>';

	}

	echo '</tr></table>';

}



function add_sub12()

{

	echo '<table border="0" width="100%"><tr><td><h3>Subject for Intermediate</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=sub12" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	

	if(@isset($_POST['sub12']))

	{

		$name=$_POST['name'];

		$mm=$_POST['mm'];

		$pract=$_POST['pract'];

		$pmm=$_POST['pmm'];

		$r=mysql_query("insert into sub12 (name, mm, pract,pmm) values('$name','$mm','$pract','$pmm')");

		if(isset($r)) { done("Subject Added Successfully."); }	

		else { error("There is an error, please try later.");  } 

					

	}

	

	

	echo '<form id="form1" name="form1" method="post" action="index.php?a=add_sub12">

  <table width="100%" border="0" cellspacing="2">

    <tr>

      <td>Subject Name:</td>

      <td><span id="sprytextfield1">

        <label>

        <input name="name" type="text" id="name" size="30" />

        </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Maximum Marks</td>

      <td><span id="sprytextfield2">

      <label>

      <input name="mm" type="text" id="mm" size="30" />

      </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Practical</td>

      <td><span id="spryselect1">

        <label>

        <select name="pract" id="pract">

          <option>--Select--</option>

          <option value="1">Yes</option>

          <option value="0">No</option>

        </select>

        </label>

      <span class="selectRequiredMsg">Please select an item.</span></span></td>

    </tr>

    <tr>

      <td>Practical Maximum Marks</td>

      <td><span id="sprytextfield3">

      <label>

      <input name="pmm" type="text" id="pmm" size="30" value="0" />

      </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>&nbsp;</td>

      <td>&nbsp;</td>

    </tr>

    <tr>

      <td>&nbsp;</td>

      <td><label>

        <input type="submit" name="sub12" id="sub10" value="Add Subject" />

      </label></td>

    </tr>

  </table>

</form>

<script type="text/javascript">

<!--

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");

var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");

var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");

//-->

</script>';

}

function del_sub10()

{

	$id=$_REQUEST['id'];

	$q=mysql_query("delete from sub10 where id='$id'");

	if($q) {  done('Subject deleted Successfully. <a href="index.php?a=sub10">Click here</a> to go back'); }

	else { error("An Error is occured, please contact your system administrator."); }	

}

function sub10()

{

	echo '<table border="0" width="100%"><tr><td><h3>Subjects for High School</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=add_sub10"><img src="add.gif" border="0" /></a>

	</td></tr></table>';

	

	$lm=30;

	

	if(!isset($_REQUEST['page'])) { $p=1; }

	else { $p=$_REQUEST['page']; }

	$s= ($p-1)*$lm;

	$q=mysql_query("select * from sub10 limit $s, $lm");

	$r2=mysql_query("select id from sub10");

	echo '<br><table width="100%" border="0" cellpadding="0" cellspacing="5" bordercolor="#00FFFF">';

	echo '<tr><td bgcolor="#00FFFF"><b>ID</b></td><td bgcolor="#00FFFF"><b>Name</b></td><td bgcolor="#00FFFF"><b>Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Practical Maximum Marks</b></td><td bgcolor="#00FFFF"><b>Delete</b></td></tr>';

	while($r=mysql_fetch_array($q))

	{

		echo '<tr><td>'.$r['id'].'</td><td>'.$r['name'].'</td><td>'.$r['mm'].'</td><td>'.$r['pmm'].'</td><td><a href="index.php?a=del_sub10&id='.$r['id'].'"><img src="d.jpg" border="0" onclick="return del();" /></a></td></tr>';

	}	

	echo '</table>';

	$total=mysql_num_rows($r2);

	$tpage=ceil($total/$lm);

	echo '<table align="center" border=0><tr>';

	if($p>1)

	{

		$pg=$p-1;

		echo '<td><a href="index.php?a=sub10&page='.$pg.'" title="Previous Page"><img src="p.jpg" border="0" /></a></td>';

	}

	echo '<td align=center>Page No. '.$p.' of '.$tpage.' Page(s)</td>';

	if($tpage>$p)

	{

		$pg=$p+1;

		echo '<td align=right><a href="index.php?a=sub10&page='.$pg.'" title="Next Page"><img src="n.jpg" border="0" /></a></td>';

	}

	echo '</tr></table>';

}



function add_sub10()

{

	echo '<table border="0" width="100%"><tr><td><h3>Subject for High School</h3></td>';

	echo '<td align="right">

	<a href="index.php?a=sub10" title="Cancel"><img src="cancel.gif" border="0" /></a>

	</td></tr></table>';

	

	if(@isset($_POST['sub10']))

	{

		$name=$_POST['name'];

		$mm=$_POST['mm'];

		$pract=$_POST['pract'];

		$pmm=$_POST['pmm'];

		$r=mysql_query("insert into sub10 (name, mm, pract,pmm) values('$name','$mm','$pract','$pmm')");

		if(isset($r)) { done("Subject Added Successfully."); }	

		else { error("There is an error, please try later.");  } 

					

	}

	

	

	echo '<form id="form1" name="form1" method="post" action="index.php?a=add_sub10">

  <table width="100%" border="0" cellspacing="2">

    <tr>

      <td>Subject Name:</td>

      <td><span id="sprytextfield1">

        <label>

        <input name="name" type="text" id="name" size="30" />

        </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Maximum Marks</td>

      <td><span id="sprytextfield2">

      <label>

      <input name="mm" type="text" id="mm" size="30" />

      </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>Practical</td>

      <td><span id="spryselect1">

        <label>

        <select name="pract" id="pract">

          <option>--Select--</option>

          <option value="1">Yes</option>

          <option value="0">No</option>

        </select>

        </label>

      <span class="selectRequiredMsg">Please select an item.</span></span></td>

    </tr>

    <tr>

      <td>Practical Maximum Marks</td>

      <td><span id="sprytextfield3">

      <label>

      <input name="pmm" type="text" id="pmm" size="30" value="0" />

      </label>

      <span class="textfieldRequiredMsg">A value is required.</span></span></td>

    </tr>

    <tr>

      <td>&nbsp;</td>

      <td>&nbsp;</td>

    </tr>

    <tr>

      <td>&nbsp;</td>

      <td><label>

        <input type="submit" name="sub10" id="sub10" value="Add Subject" />

      </label></td>

    </tr>

  </table>

</form>

<script type="text/javascript">

<!--

var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");

var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");

var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");

//-->

</script>';

}



?>