<?php

require '../config/database.php';
require 'Database.php';
require 'Session.php';

function Dataupdate() {
    $db = new Database();

    if (isset($_POST['second_list_data'])) {

        $batchid=$_POST['batchid'];


        $batch_id=$batchid;

        $second=$_POST['second_list_data'];
     
        

//$batch_id="1";

        $delete=$db->runQuery("DELETE FROM tbl_assign_paper_batch where batch_id=".$batch_id);
        $flag=0;

        if($second=="")
        {
            $msg="Please Select Papers";
            $flag=1;
            // echo "blank value";
        }
        else if($second!="")
        {
            $second=rtrim($second, ",");
            $second=explode(",",$second);
            foreach($second as $s)
            {
                $fields="paper_id,batch_id,active";
                $value="'$s',$batch_id,'1'";
                $condition='id='.$s;

                $insert = $db->runSQL("INSERT INTO tbl_assign_paper_batch (" . $fields . ") VALUES (" . $value . ")");
                if($insert!="")
                {
                    $update=$db->runSQL("UPDATE tbl_papers SET assign=$batch_id WHERE id=$s");
                    $flag=1;
                $msg="Paper Assign";
                }
                
            }
        }
        if($flag==1)
        {
            echo $msg;
        }
        else{
            echo "Error occured";
        }





    }

}
function Dataupdatepaperstaff() {
    $db = new Database();
    //echo "success";

    if (isset($_POST['staff_id'])) {


        $staffid=trim($_POST['staff_id']);
        $selected_papers_id=$_POST['selected_papers_id'];
        //echo $selected_papers_id;
        $selected_papers_id=rtrim($selected_papers_id,",");
        //echo $selected_papers_id;





        $delete=$db->runSQL("DELETE FROM tbl_assign_paper_staff where staff_id='".$staffid."'");
        $flag=0;

        if($selected_papers_id=="")
        {
            $msg="Please Select Papers";
            $flag=1;
            // echo "blank value";
        }
        else if($selected_papers_id!="")
        {
            
            $selected_papers_id=rtrim($selected_papers_id, ",");
            $select_list=explode(",",$selected_papers_id);
            foreach($select_list as $s)
            {

                $select_list_ids=explode("-",$s);

                $fields="staff_id,paper_id,batch_id,active";
                $value="'$staffid','$select_list_ids[0]',$select_list_ids[1],'1'";

                $insert = $db->runSQL("INSERT INTO tbl_assign_paper_staff (" . $fields . ") VALUES (" . $value . ")");
                if($insert!="")
                {
                    $flag=1;
                    $msg="Paper Assign";
                }

            }
        }
        if($flag==1)
        {
            echo $msg;
        }
        else{
            echo "Error occured";
        }






    }

}
function Batchupdate(){
    $db = new Database();
    if (isset($_POST['batchid'])) {


        $assign_papers =$db->FetchList('paper_id', 'tbl_assign_paper_batch',"WHERE active=1 AND batch_id=".$_POST['batchid']);
        $assign_papers_staff =$db->FetchList('paper_id', 'tbl_assign_paper_staff',"WHERE active=1 AND batch_id=".$_POST['batchid']);
        $papersid="";
        foreach($assign_papers as $a)
        {
            $papersid.=$a[0].",";
        }
        $papersid;
        $papers_staff_id="";

        foreach($assign_papers_staff as $a)
        {
            $papers_staff_id.=$a[0].",";
        }

        //$paperid="3,6,8,7";
        $papersid=rtrim($papersid,",");
        $papers_staff_id=rtrim($papers_staff_id,",");
        $fields="id,title";
        $table='tbl_papers';
            if($papersid=="")
            {
                        echo "No Record Found";
                        exit();
                        $query = "WHERE active=1";
            }
            else
            {
                    //echo $query = "WHERE active=1 AND id IN (" . $papersid . ") AND id NOT IN (".$papers_staff_id.")";
                if($papers_staff_id=="")
                {
                    $query = "WHERE active=1 AND id IN (" . $papersid . ") ";

                }
                else{
                    $query = "WHERE active=1 AND id IN (" . $papersid . ") AND id NOT IN (".$papers_staff_id.")";
                }
            }

       // echo "SELECT ".$fields." from ".$table." ".$query;
        $r =$db->FetchList($fields, $table, $query);
        //return $r;
        $ret = "";
        $f = explode(",", $fields);
        //if(!isset ($r[$temp])){
        //   return '<option value="">--Error--</option>';
        //}
        if (isset($f[1])) {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] ."-".$_POST['batchid']. '">' . $rec[$f[1]] . '</option>';
            }
        } else {
            foreach ($r as $rec) {
                $ret.='<option value="' . $rec[$f[0]] ."-".$_POST['batchid']. '">' . $rec[$f[0]] . '</option>';
            }
        }
        echo $ret;

    }
    //echo "test";

}
function checkusername() {
    $db = new Database();
    if (isset($_POST['username'])) {
        $u = trim($_POST['username']);
        $user = $db->Fetch('username', 'tbl_users', "WHERE username='$u'");
        echo $user['username'];
    }
}

function checkEnrollment() {
    $db = new Database();
    if (isset($_POST['std_regn'])) {
        $en = trim($_POST['std_regn']);
        $user = $db->Fetch('std_id', 'tbl_students', "WHERE std_regn='$en'");
        echo $user['std_id'];
    }
}

function checkEmpCode() {
    $db = new Database();
    if (isset($_POST['staff_regn'])) {
        $emc = trim($_POST['staff_regn']);
        $user = $db->Fetch('staff_regn', 'tbl_staff', "WHERE staff_regn='$emc'");
        echo $user['staff_regn'];

    }
}

function studentFaculty() {
    $db = new Database();
    if (isset($_POST['std_regn'])) {
        $en = trim($_POST['std_regn']);
        $value = $db->FetchList("faculty_id,faculty_name", "view_studentfaculty", "WHERE std_regn='$en' AND active=1");
        $output = "";
        $output.= "<option value=''>--Select--</option>";
        foreach ($value as $val) {
            $output.='<option value="' . $val[0] . '">' . $val[1] . '</option>';
        }
        echo $output;
    }
}

function studentHall() {
    $db = new Database();
    if (isset($_POST['std_regn'])) {
        $en = trim($_POST['std_regn']);
        $value = $db->FetchList("hall_code,hall_name", "view_studenthall", "WHERE std_regn='$en' AND active=1");
        $output = "";
        $output.= "<option value=''>--Select--</option>";
        foreach ($value as $val) {
            $output.='<option value="' . $val[0] . '">' . $val[1] . '</option>';
        }
        echo $output;
    }
}

function getlist() {
    $db = new Database();
    $table = $_POST['table'];
    $field = $_POST['field'];
    $query = $_POST['query'];
    $qfield = $_POST['qfield'];
    $condition = $_POST['condition'];
    if ($condition != "") {
        $condition = "AND $condition";
    }
    $value = $db->FetchList($field, $table, "WHERE $qfield='$query' $condition");
    $output = "";
    $output.= "<option value=''>--Select--</option>";
    if($table=="tbl_papers" || $table=="view_papers"){
        foreach ($value as $val) {
            $output.='<option value="' . $val[0] . '">' . $val[1] . '('.$val[0].')</option>';
        }
    }else {
        foreach ($value as $val) {
            $output.='<option value="' . $val[0] . '">' . $val[1] . '</option>';
        }
    }


    echo $output;
}

function glist() {
    $db = new Database();
    if (isset($_POST['c'])) {
        $c = $_POST['c'];
    } else {
        $c = "";
    }
    $q = $_REQUEST['q'];
    $t = $_REQUEST['t'];
    $f = $_REQUEST['f'];
    $value = $db->FetchList($f, $t, "WHERE $f LIKE '$q%' $c");
    foreach ($value as $val) {
        $id = $val[$f];
        echo "$id\n";
    }
}

function checkAccessionNum() {
    $db=new Database();
    if(isset($_POST['booknum'])) {
        $accnum=trim($_POST['booknum']);
        $libName=trim($_POST['libName']);
        if($libName=='central')
        {
            $number=$db->Fetch('id','tbl_book_master',"WHERE acc_num='$accnum'" );
            echo $number['id'];
        }elseif($libName=='medical')
        {
            $number=$db->Fetch('id','tbl_book_masterMed',"WHERE acc_num='$accnum'" );
            echo $number['id'];
        }else{
            echo null;
        }

    }
}
function checkBookAccessionNum() {
    $db=new Database();
    if(isset($_POST['book_num'])) {
        $accnum=trim($_POST['book_num']);
        $libName=trim($_POST['libName']);
        if($libName=='central')
        {
            $number=$db->Fetch('*','tbl_book_master',"WHERE acc_num='$accnum'" );
            $book_issue_stu=$db->Fetch('*','tbl_book_issue_stu',"WHERE acc_num='$accnum' AND date_of_return='' ");
            $book_issue_fac=$db->Fetch('*','tbl_book_issue_fac',"WHERE acc_num='$accnum' AND date_of_return='' ");
            if($number['id']==true){
                echo $number['title']."|_|".$number['author']."|_|".$number['book_type'].
                    "|_|".$book_issue_stu['id']."|_|".$book_issue_stu['stu_id']."|_|".
                    $book_issue_fac['id']."|_|".$book_issue_fac['fac_id']."|_|".$number['status'];
            }

        }elseif($libName=='medical')
        {
            $number=$db->Fetch('*','tbl_book_masterMed',"WHERE acc_num='$accnum'" );
            $book_issue_stu=$db->Fetch('*','tbl_book_issue_stuMed',"WHERE acc_num='$accnum' AND date_of_return='' ");
            $book_issue_fac=$db->Fetch('*','tbl_book_issue_facMed',"WHERE acc_num='$accnum' AND date_of_return='' ");
            if($number['id']==true){
                echo $number['title']."|_|".$number['author']."|_|".$number['book_type'].
                    "|_|".$book_issue_stu['id']."|_|".$book_issue_stu['stu_id']."|_|".
                    $book_issue_fac['id']."|_|".$book_issue_fac['fac_id']."|_|".$number['status'];
            }

        }else{
            $number=null;
            echo null;
        }
    }


}
function checkStudentDetails() {
    $db=new Database();
    if(isset($_POST['reg_no'])) {
        $reg_no=trim($_POST['reg_no']);
        $stu_details=$db->Fetch('*','tbl_students',"WHERE std_regn='$reg_no'");
        $stu_course_details=$db->Fetch('*','tbl_assign_class',"WHERE std_regn='$reg_no'");
        $course_id=$stu_course_details['course_id'];
        //$course_id='isbb';
        $course_name=$db->Fetch('*','tbl_courses',"WHERE course_id='$course_id'");
        if($stu_details['std_regn']==true)
        {
            echo $stu_details['std_name']."|_|".$course_name['course_name'];
            //echo $reg_no;
        }
        else
        {
            echo "";
        }
    }
}

function checkStaffDetails(){
    $db=new Database();
    if(isset($_POST['staff_id'])){
        $staff_id=trim($_POST['staff_id']);
        $staff_details=$db->Fetch('*','tbl_staff',"WHERE staff_regn='$staff_id' ");
        $staff_designation=$staff_details['design_code'];
        $staff_designation_name=$db->Fetch('*','tbl_designations',"WHERE code='$staff_designation' ");
        if($staff_details['staff_regn']==true)
        {
            echo $staff_details['staff_name']."|_|".$staff_designation_name['design'];
        }
        else{
            echo "";
        }
    }
}

function checkpaperstaff(){
        $db=new Database();
        if(isset($_POST['paper_id']))
        {
            $paper_id=$_POST['paper_id'];
            $batch_id=$_POST['batchid'];

            $staff_id_array=$db->Fetch("staff_id",'tbl_assign_paper_staff',"WHERE batch_id='$batch_id' AND paper_id='$paper_id' ");

            $staff_id=$staff_id_array['staff_id'];

            $staff_details=$db->Fetch('*','tbl_staff',"WHERE staff_regn='$staff_id' ");

            if($staff_details=="")
            {
                echo "";
            }
            else {
                echo $staff_details['staff_name']."+".$staff_details['staff_regn'];
          //      echo $staff_details['staff_name'];
            }


        }
}

function bookreturn(){
    $db=new Database();
    if(isset($_POST['id'])){
        $id=$_POST['id'];
        $libName=trim($_POST['libName']);
        $ids=explode('#-#',$id);
        
        sleep(1);

        $acc_num=$ids[0];
        $transaction_num=$ids[1];


        $return_date = date("Y-m-d");
        if($libName=='central')
        {
            $issue_details=$db->Fetch("*",'view_issue_stu',"WHERE id='$transaction_num'");
        }elseif($libName=='medical')
        {
            $issue_details=$db->Fetch("*",'view_issue_stuMed',"WHERE id='$transaction_num'");
        }
            else{
            $issue_details=false;
        }


        $std_regn=$issue_details['stu_id'];
        $lost = 0;
        $paid = "N";

        $diff=date_diff(date_create($issue_details['date_of_issue']),date_create($return_date));

        $fine= (int)$diff->format("%a");
        if($fine>10) {
            $fine = $fine - 10;
            $fine = $fine * 5;
        }
        else{
            $fine=0;
        }
        $remarks = "none";
        Session::init();
        $receiver_id=Session::get('user');

        $f = array("id", "stu_id", "acc_num", "date_of_return", "fine_amount", "paid", "lost", "receiver_id","remarks");
        $v = array($transaction_num,$issue_details['stu_id'] , $acc_num,$return_date, $fine, $paid, $lost, $receiver_id, $remarks);

        if($libName=='central')
        {
            $result = $db->Update("tbl_book_issue_stu", $f, $v, 'id',$transaction_num);
        }elseif($libName=='medical')
        {
            $result = $db->Update("tbl_book_issue_stuMed", $f, $v, 'id',$transaction_num);
        }
        else{
            $result=false;
        }


        if($result==true) {
            if($libName=='central')
            {
                $book_issue_details = $db->FetchList("*", "view_issue_stu", "WHERE stu_id='$std_regn' AND date_of_return='0000-00-00' ORDER BY id ");
                $fine_details = $db->Fetchlist("*", 'view_issue_stu', "WHERE stu_id='$std_regn' AND fine_amount > '0' AND (paid='N' OR paid='no')  ORDER BY id");
                $issue_history = $db->FetchList("*", "view_issue_stu", "WHERE stu_id='$std_regn' ORDER BY id");
                $update_field = array('status');
                $update_value = array('Available');
                $update_book_info = $db->Update("tbl_book_master", $update_field, $update_value, 'acc_num', $acc_num);
            }
            elseif($libName=='medical')
            {
                $book_issue_details = $db->FetchList("*", "view_issue_stuMed", "WHERE stu_id='$std_regn' AND date_of_return='0000-00-00' ORDER BY id ");
                $fine_details = $db->Fetchlist("*", 'view_issue_stuMed', "WHERE stu_id='$std_regn' AND fine_amount > '0' AND (paid='N' OR paid='no')  ORDER BY id");
                $issue_history = $db->FetchList("*", "view_issue_stuMed", "WHERE stu_id='$std_regn' ORDER BY id");
                $update_field = array('status');
                $update_value = array('Available');
                $update_book_info = $db->Update("tbl_book_masterMed", $update_field, $update_value, 'acc_num', $acc_num);
            }

            $issue_details1="<tr>
                        <th>Accession Number</th>
                        <th style='text-align: center;'>Action</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Date of Issue</th>
                        <th>Issued By</th>
                        <th>Remarks</th>
                        <th>Transaction I.D.</th>
                    </tr>";
                foreach($book_issue_details as $issued_list)
                {

                    $issue_details1.= '<tr>';
                    $issue_details1.= "<td class='alert-danger' style='text-align: center; font-weight: bold;'>".$issued_list['acc_num'].'</td>';
                    $issue_details1.="<td><button type=submit name=bookreturn  value=".$issued_list['acc_num'].'#-#'.$issued_list['id']." class='bookreturn btn btn-round btn-primary btn-sm' style='margin-left:20px;'>Return</button></td>";
                    $issue_details1.= '<td>'.$issued_list['book_title'].'</td>';
                    $issue_details1.= '<td>'.$issued_list['author'].'</td>';
                    $issue_details1.= '<td>'.$issued_list['date_of_issue'].'</td>';
                    $issue_details1.= '<td>'.$issued_list['issuer_id'].'</td>';
                    $issue_details1.= '<td>'.$issued_list['remarks'].'</td>';
                    $issue_details1.= '<td>'.$issued_list['id'].'</td>';
                    $issue_details1.= '</tr>';

                }

            $fine_details1="<tr>
                        <th>Transaction I.D.</th>
                        <th>Accession Number</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Fine</th>
                        <th>Action</th>
                        <th>Date of Issue</th>
                        <th>Date of Return</th>
                        <th>Issued By</th>
                        <th>Return By</th>

                        <th>Remarks</th>
                    </tr>";

                foreach($fine_details as $fine_list)
                {
                    $fine_details1.= '<tr>';
                    $fine_details1.= '<td>'.$fine_list['id'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['acc_num'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['book_title'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['author'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['fine_amount'].'</td>';
                    $fine_details1.= "<td><button class='btn btn-theme02 btn-xs fine-deposite' value=".$fine_list['id']."#-#".$fine_list['acc_num'].">Fine Deposit</button></td>";
                    $fine_details1.= '<td>'.$fine_list['date_of_issue'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['date_of_return'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['issuer_id'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['receiver_id'].'</td>';
                    $fine_details1.= '<td>'.$fine_list['remarks'].'</td>';
                    $fine_details1.= '</tr>';
                }

            $issue_history1="<tr>
                            <th>Transaction I.D.</th>
                            <th>Accession Number</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Fine</th>
                            <th>Paid</th>
                            <th>Fine Received By</th>
                            <th>Fine Received Date</th>
                            <th>Date of Issue</th>
                            <th>Date of Return</th>
                            <th>Issued By</th>
                            <th>Return By</th>
                            <th>Remarks</th>
                        </tr>";


                        foreach($issue_history as $fine_list)
                        {
                            $issue_history1.= '<tr>';
                            $issue_history1.= '<td>'.$fine_list['id'].'</td>';
                            $issue_history1.='<td>'.$fine_list['acc_num'].'</td>';
                            $issue_history1.='<td>'.$fine_list['book_title'].'</td>';
                            $issue_history1.='<td>'.$fine_list['author'].'</td>';
                            $issue_history1.='<td>'.$fine_list['fine_amount'].'</td>';

                            $issue_history1.='<td>';
                            if($fine_list['fine_amount']>0)
                            {

                                if ($fine_list['paid'] == 'Y') {
                                    $issue_history1.="<span class='label label-success label-mini'>Paid</span>";
                                } else {
                                    $issue_history1.="<span class='label label-warning label-mini'>Due</span>";

                                }
                            }
                            else{
                                $issue_history1.="";
                            }

                            $issue_history1.='</td>';

                            $issue_history1.='<td>'.$fine_list['fine_received_by'].'</td>';
                            $issue_history1.='<td>'.$fine_list['fine_received_date'].'</td>';


                            $issue_history1.='<td>'.$fine_list['date_of_issue'].'</td>';
                            $issue_history1.='<td>'.$fine_list['date_of_return'].'</td>';
                            $issue_history1.='<td>'.$fine_list['issuer_id'].'</td>';
                            $issue_history1.='<td>'.$fine_list['receiver_id'].'</td>';
                            $issue_history1.='<td>'.$fine_list['remarks'].'</td>';
                            $issue_history1.='</tr>';
                        }

//echo "hi";
           echo $issue_details1."-#-#".$fine_details1."-#-#".$issue_history1."-#-#".$fine;
       //echo "<input type=submit name=bookreturn value='rrrr' class=gg id='gg1'>";
        }
        else{
            echo "";
        }



    }
}

function attendreportpaper()
{
    $db=new Database();
    if(isset($_POST['from'])) {

        $from=$_POST['from'];
        $to=$_POST['to'];
        $paper_id=$_POST['paper_id'];
        $batch_id=$_POST['batch_id'];
        $group_id=$_POST['group_id'];
        $username=$_POST['username'];
        $role_id=$_POST['username'];


        sleep(1);
        $paper_details=$db->Fetch("*",'tbl_papers',"WHERE id='$paper_id' ");
        $batch_details=$db->Fetch("*",'tbl_batches',"WHERE id='$batch_id' ");
        
        $batch_sem=$batch_details['sem'];
        
            
        if($group_id==0)
        {
            $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");

        }
        else{

            $student_list=$db->FetchList('*','tbl_assign_group',"where group_id='$group_id' AND active=1");
            $stu_list_gv="";
            foreach ($student_list as $stu)
            {
                $stu_list_gv.="'";
                $stu_list_gv.=$stu['std_regn'];
                $stu_list_gv.="'";
                $stu_list_gv.=",";
            }
            $stu_list_gv=rtrim($stu_list_gv,',');

            $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' AND std_regn IN ($stu_list_gv) ORDER BY std_regn");

        }
        $staff_details=$db->Fetch("*","tbl_staff","WHERE staff_regn='$username' ");
        $r="";

        //date_format(date_create(Controller::$view['current_date']),"l, F dS, Y")

        $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND group_id='$group_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
        $number_of_classes=$number_of_classes_count['date'];
        $toptable="</br><h4>>Report From <span style='color: darkred;'>".date_format(date_create($from),"l, F dS, Y")."</span> To <span style='color:darkred;'> ".date_format(date_create($to),"l, F dS, Y")."</span></h4>";
        $toptable.="</br><table class='table table-striped table-advance table-hover' border='0'>";
        $toptable.="<thead><tr><th width='10%'>Batch  ::</th><th width='20%'>";
        $toptable.=$batch_details['title']."</th>";
        $toptable.="<td width='10%'></td>";
        $toptable.="<th width='20%'>Paper  ::</th><th width='30%'>";
        $toptable.=$paper_details['title'].'</th></tr></thead>';
        $toptable.="<tr><td>Faculty ::</td><td>".$staff_details['staff_name'];

        $middletable= "<table class='table table-bordered table-striped table-condensed'>";
        $middletable.="<tr><th>S.No.</th><th>Reg. No.</th><th>Name</th><th>Registration Date(Year-Month-Day)</th>";
        if($batch_sem=='1')
        {
        $middletable.="<th>Attendance<br><span style='font-weight:100; color:blue;'>AT ( % ) TCS</span></th></tr>";
		}
		else
		{
		$middletable.="<th>Attendance</th></tr>";
		}
		
        $i=1;

        foreach($student_list as $students)
        {
			$reg_date=$students['assign_date'];
            $std_regn=$students['std_regn'];
                
            $attendance_array=$db->FetchList("*",'tbl_attendance',"WHERE paper_id='$paper_id' AND group_id='$group_id' AND batch_id='$batch_id' AND std_regn='$std_regn' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");
					
			
					
            if($attendance_array==false)
            {
                $persent='NULL';
                //echo "NA";
                //return false;
            }
            $middletable.="<tr>";
            $middletable.="<td>";
            $middletable.=$i;
            $middletable.="</td>";

            $middletable.="<td>";
            $middletable.=$students['std_regn'];
            $middletable.="</td>";

            $middletable.="<td>";
            $middletable.=$students['std_name'];
            $middletable.="</td>";

			$middletable.="<td>";
            $middletable.=$reg_date;
            $middletable.="</td>";



            $absent=0;
            $persent=0;
            $j=0;
            foreach($attendance_array as $attendance)
            {
                if($attendance['absent']==0)
                $persent++;
                elseif($attendance['absent']==1)
                    $absent++;
            $j++;


            }



			
            
            if($batch_sem=='1')
			{
			
			$number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND group_id='$group_id'  AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");
			$number_of_classes=$number_of_classes_count['date'];
			$percentage=round((($persent/$number_of_classes)*100),2);
			if($percentage<50)
                {
					$middletable.="<td style='color:red; font-weight:900; '>";
                }
                else{
					$middletable.="<td>";
                }
			$middletable.=$persent." (".$percentage." % )"." #".$number_of_classes;
            
            }
			else
			{
            $percentage=round((($persent/$number_of_classes)*100),2);
            if($percentage<50)
                {
					$middletable.="<td style='color:red; font-weight:900; '>";
                }
                else{
					$middletable.="<td>";
                }
            $middletable.=$persent." (".$percentage." % )";
			
			}
            $middletable.="</td>";


            $middletable.="</tr>";
            
             $i++;

        }
        
        $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND group_id='$group_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
        $number_of_classes=$number_of_classes_count['date'];
        
        if($batch_sem=='1')
        {
					$middletable.="</table>"."<span style='color:red;'>Abbreviation :: </span><span style='color:blue;'></span>  AT : Total no of attendance, TCS : Total no. of classes of student from the date of registration</span>";
    
		}
		else
		{
		$middletable.="</table>";
		}	
	    $toptable.="<td></td>";
        $toptable.="<td>No. of classes ::</td><td>".$number_of_classes;
        $toptable.="</tr></table>";

        echo $toptable.$middletable;

    }

//    echo $batch_details['title'];

}
function attendancereport()
{
    $db=new Database();
    if(isset($_POST['from']))
    {


        $from=$_POST['from'];
        $to=$_POST['to'];
        
        $batch_id=$_POST['batch_id'];
        
        
        $batch_details=$db->Fetch("*",'tbl_batches',"WHERE id='$batch_id' ");
        
        $batch_sem=$batch_details['sem'];
        
        
        $paper_list=$db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' ");

        $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");

        $toptable="";
        $toptable.="</br><h4>> Report From <span style='color: darkred;'>".date_format(date_create($from),"l, F dS, Y")."</span> To <span style='color:darkred;'> ".date_format(date_create($to),"l, F dS, Y")."</span></h4>";

        $toptable.="</br><table class='table table-striped table-advance table-hover exporttable' border='1'>";


        $toptable.="<tr>";
        $toptable.="<th>Reg. No.</th>";
        $toptable.="<th>Name</th>";
         $toptable.="<th>Reg. Date.</th>";

        foreach($paper_list as $papers)
        {
            $paper_id=$papers['paper_id'];
            $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
            $number_of_classes=$number_of_classes_count['date'];
			
            $toptable.="<th>";
            $toptable.=$papers['paper_title']." (".$number_of_classes." )";
            $toptable.="</th>";

        }
        $toptable.="<th>Total</th>";


        $toptable.="</tr>";

        foreach($student_list as $students)
        {
			//$reg_date=$students['registration_date'];
            $reg_date=$students['assign_date'];
			
            $toptable.="<tr>";
            $toptable.="<td>";
            $toptable.=$students['std_regn'];
            $toptable.="</td>";

            $toptable.="<td>";
            $toptable.=$students['std_name'];
            $toptable.="</td>";
            
            $toptable.="<td>";
            $toptable.=$reg_date;
            $toptable.="</td>";
                        
            $total_num_of_classess=0;
            $attend_class=0;
            
            foreach($paper_list as $papers)
            {
                $paper_id=$papers['paper_id'];
                $std_regn=$students['std_regn'];
                
                if($batch_sem=='1')
                {
                $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date'  ");
                }
                else{
                $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to' ");
                }
                
                $number_of_classes=$number_of_classes_count['date'];
                $total_num_of_classess=$total_num_of_classess+$number_of_classes;

                $attendance_array=$db->FetchList("*",'tbl_attendance',"WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND std_regn='$std_regn' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date'  ");

                $absent=0;
                $persent=0;
                $j=0;
                foreach($attendance_array as $attendance)
                {
                    if($attendance['absent']==0)
                        $persent++;
                    elseif($attendance['absent']==1)
                        $absent++;
                    $j++;


                }
                $attend_class=$attend_class+$persent;
                $percentage=round((($persent/$number_of_classes)*100),2);
                if($percentage<50)
                {
					$toptable.="<td style='color:red; font-weight:900; '>";
                }
                else{
					$toptable.="<td>";
                }
                if($batch_sem=='1'){
                    $toptable.=$persent." (".$percentage." % )"." #".$number_of_classes;

                }else{
                    $toptable.=$persent." (".$percentage." % )";

                }
                $toptable.="</td>";


            }
            $total_percentage=round((($attend_class/$total_num_of_classess)*100),2);
            if($total_percentage<50)
            {
			$toptable.="<td style='color:red; font-weight:900;'>";
			}
			else
			{
			$toptable.="<td>";
            }
            if($batch_sem=='1')
            {
			$toptable.=$attend_class." (".$total_percentage." % )"." #".$total_num_of_classess;
			}
			else
			{
			$toptable.=$attend_class." (".$total_percentage." % )";
			}
            $toptable.="</td>";

            $toptable.="</tr>";

        }


        $toptable.="</tr>";

        echo $toptable;

    }


}

function attendancereport_csv()
{
    $db=new Database();
    if(isset($_POST['from']))
    {
        $from=$_POST['from'];
        $to=$_POST['to'];
        $batch_id=$_POST['batch_id'];


        $batch_details=$db->Fetch("*",'tbl_batches',"WHERE id='$batch_id' ");
        $batch_sem=$batch_details['sem'];

        $paper_list=$db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' ");

        $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");

         $path='/home/eduglocal/public_html/glocalstaffims/public/tmp';
        
        chdir($path);

        $batchname=$batch_details['title'];
        $filename=$batchname.'.csv';

        $output = fopen($filename, 'w');


        $headings=array("Reg. No","Name","Registration Date");

        foreach($paper_list as $papers)
        {
            $paper_id=$papers['paper_id'];
            $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to'   ");
            $number_of_classes=$number_of_classes_count['date'];


            $papername=$papers['paper_title']." (".$number_of_classes.")";
            array_push($headings,$papername);

        }
        array_push($headings,'Total');
        fputcsv($output, $headings);



        foreach($student_list as $students)
        {
            $data=array();
            array_push($data,$students['std_regn']);
            array_push($data,$students['std_name']);
             //$reg_date=$students['registration_date'];
			$reg_date=$students['assign_date'];            
		array_push($data,$reg_date);

            $total_num_of_classess=0;
            $attend_class=0;
            foreach($paper_list as $papers)
            {
                $paper_id=$papers['paper_id'];
                $std_regn=$students['std_regn'];
                
                 if($batch_sem=='1')
                {
                    $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime >= '$reg_date'  ");
                }
                else{
                    $number_of_classes_count=$db->runQuery("SELECT count(distinct concat(`att_datetime`,`lecture_num`)) as date from tbl_attendance WHERE paper_id='$paper_id' AND batch_id='$batch_id'  AND att_datetime >= '$from' AND att_datetime <= '$to' ");
                }
                
                
                $number_of_classes=$number_of_classes_count['date'];
                $total_num_of_classess=$total_num_of_classess+$number_of_classes;
                $attendance_array=$db->FetchList("*",'tbl_attendance',"WHERE paper_id='$paper_id' AND batch_id='$batch_id' AND std_regn='$std_regn' AND att_datetime >= '$from' AND att_datetime <= '$to' AND att_datetime <= '$to' AND att_datetime >= '$reg_date' ");

                $absent=0;
                $persent=0;
                $j=0;
                foreach($attendance_array as $attendance)
                {
                    if($attendance['absent']==0)
                        $persent++;
                    elseif($attendance['absent']==1)
                        $absent++;
                    $j++;


                }
                $attend_class=$attend_class+$persent;
                if($batch_sem=='1'){
                		array_push($data,$persent." (".round((($persent/$number_of_classes)*100),2)." % )"." #".$number_of_classes);

                }else{
                array_push($data,$persent." (".round((($persent/$number_of_classes)*100),2)." % )");

                }
                
                

            }
            if($batch_sem=='1'){
			array_push($data,$attend_class." (".round((($attend_class/$total_num_of_classess)*100),2)." % )"." #".$total_num_of_classess);

			}else{
			array_push($data,$attend_class." (".round((($attend_class/$total_num_of_classess)*100),2)." % )");

			}
            

            fputcsv($output,$data);
        }

        $filepath="/public/tmp/";
        fclose($output);
        $file=$filepath.$filename;
        echo $file;

    }
}

function jsonMarksTotal($marks,$extractValue)
{
    $pattern = json_decode($marks, true);
    if(!$pattern)
    {
        return 0;
    }
    else{
        return $pattern[$extractValue];
    }

}
function finalMarks($stdRegn,$paperId,$batchId,$groupId,$dash=true)
{
    // function to calculate the final marks of student.
    $db=new Database();
    $extractValue="Total";
    $marks=$db->Fetch("*","tbl_marks","WHERE batch_id='$batchId' AND std_regn='$stdRegn' AND paper_id='$paperId' AND group_id='$groupId' ");
    if($marks==false && $dash==false)
    {
        $paperData=$db->Fetch("*","tbl_papers","WHERE id='$paperId' LIMIT 0,1");
        $patternId=$paperData['marks_distribution_id'];
        $marksDistribution=$db->Fetch("*","tbl_marksdistibutionpattern","WHERE id='$patternId'");
        $marks['marks']=$marksDistribution['pattern'];
    }
    $semMarksTotal=jsonMarksTotal($marks['marks'],$extractValue);
    if($marks['reCheckMarks']!=NULL)
    $reCheckMarksTotal=jsonMarksTotal($marks['reCheckMarks'],$extractValue);
    if($marks['repeatMarks1']!=NULL)
        $repeatMarks1Total=jsonMarksTotal($marks['repeatMarks1'],$extractValue);
    if($marks['reCheckMarks2']!=NULL)
        $repeatMarks2Total=jsonMarksTotal($marks['repeatMarks2'],$extractValue);
    if($marks['reCheckMarks3']!=NULL)
        $repeatMarks3Total=jsonMarksTotal($marks['repeatMarks3'],$extractValue);
    $x = array(
        'marks' => $semMarksTotal,
        'reCheckMarks' => $reCheckMarksTotal,
        'repeatMarks1' => $repeatMarks1Total,
        'repeatMarks2' => $repeatMarks2Total,
        'repeatMarks3' => $repeatMarks3Total);

    reset($x);   // optional.
    arsort($x);

    $key= key($x);

    if($key=='marks' || $key=='reCheckMarks' || $marks==false)
    {
        $extraValue=null;
    }
    else{
        $extraValue="R";
    }
    return $marks[$key]."-".$extraValue;

   //    return $marks;

}




function marksreport()
{
    $db=new Database();
    if(isset($_POST['batch_id'])) {
        $batch_id=$_POST['batch_id'];

        $button="<button class='btn btn-theme02 marksreport' style='position: relative; id='marksreport' type='submit'> <i class='fa fa-rocket'> Generate Marks Report</i></button>";
        $button.="<tr><td>&nbsp;</td></tr>";
        $button.="<tr><td>&nbsp;</td></tr>";
        $batch_details=$db->Fetch("*",'view_batches',"WHERE id='$batch_id' ");

        $batch_info="</br></br>";
        $batch_info.="<table class='display table table-bordered dataTable'>";
        $batch_info.="<tr>";
        
        $path='/home/eduglocal/public_html/glocalstaffims/public/tmp/marks';


        chdir($path);
        $batchname=$batch_details['title'];
        $filename=$batchname.'.csv';

        $output = fopen($filename, 'w');

        $batch_info.="<th>";
        $batch_info.="Batch Code : ".$batch_details['title'];
        $batch_info.="</th>";

        $batch_info.="<th>";
        $batch_info.="Course Name : ".$batch_details['course_name'];
        $batch_info.="</th>";

        if($batch_details['sem-year']=='S')
        {
            $sem="Semester";
        }
        elseif($batch_details['sem-year']=='Y')
        {
            $sem="Year";
        }
        $batch_info.="<th>";
        if($batch_details['Sem-year']=='S')
        {
            $batch_info.="Semester : ";
        }
        elseif($batch_details['Sem-year']=='Y')
        {
            $batch_info.="Year : ";
        }

        $batch_info.=$batch_details['sem']." ".$sem;

        $batch_info.="</th>";

        $batch_info.="</tr>";
        $batch_info.="</table>";

        $paper_list=$db->FetchList("*","view_assign_paper_batch","WHERE batch_id='$batch_id' order by category DESC, id DESC");
        $data_table="<table class='table1 table-bordered table-striped table-condensed dataTable' style='border: 3px solid #ddd;'>";

        $subjectRow="<tr><td>&nbsp;</td><td>&nbsp;</td><th>Subjects -> </th>";
        $patternRow="<tr><th>S.No.</th><th>Reg. NO.</th><th>Student Name</th>";

        $subjectRowCSV=array("","","Subjects");
        $patternRowCSV=array("S.No.","Reg.No.","Name");
        $paperIds=array();
        $subjectFields=array();
        $patternTotal=array();
        $credits=array();
        $totalCredits=0;
        $totalMaxMarks=0;

        foreach($paper_list as $papers)
        {
            $paper_id=$papers['paper_id'];
            $marksDistributionId=$papers['marks_distribution_id'];
            $marksPattern=$db->Fetch("*","tbl_marksdistibutionpattern","WHERE id='$marksDistributionId'");
            $pattern = json_decode($marksPattern['pattern'],true);
           $assigndetails=$db->Fetch("*","tbl_assign_paper_staff","WHERE paper_id=$paper_id");
            $numberofKeys=1;
            foreach($pattern as $key => $value)
            {
                $patternRow.="<th>".$key."</th>";
                array_push($patternRowCSV,$key);
                $numberofKeys++;
                if($key=='Total')
                {
                    $totalMaxMarks=$totalMaxMarks+$value;
                }
            }
            $nk=$numberofKeys;
            if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
            {
                $subjectHeadings=$paper_id."(".$papers['paper_code'].") ".$papers['paper_title']." :: ".$papers['credits']." Credits";
                
            }
            if($batch_details['gradingSystem']==3)
            {
                $subjectHeadings=$paper_id."(".$papers['paper_code'].") ".$papers['paper_title'];
                $nk--;
            }
            $subjectHeadings.="<br>".$assigndetails['staff_id'];
            if($assigndetails['marksFinalSub']==1)
            {
               $subjectHeadings.="&nbsp;<i class='fa fa-check-circle text-success' aria-hidden='true'></i>";
            }
            $subjectRow.="<td colspan=".$nk.">".$subjectHeadings."</td>";
            array_push($subjectRowCSV,$subjectHeadings);



            if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
            {

                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"");
                }

                $patternRow.="<th>"."Grade"."</th>";
                array_push($patternRowCSV,"Grade");
            }
            elseif($batch_details['gradingSystem']==3)
            {
                    // blank row for 3rd coding system
                $numberofKeys--;
                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"");
                }
            }
            else{
                for($i=1;$i<$numberofKeys;$i++)
                {
                    array_push($subjectRowCSV,"...");
                }
                $patternRow.="<th>"."Grading System Not Defined"."</th>";
                array_push($patternRowCSV,"Grading System Not Defined");
            }

            array_push($paperIds,$paper_id);
            array_push($subjectFields,$numberofKeys);
            array_push($patternTotal,$pattern['Total']);

            
            array_push($credits,$papers['credits']);

        }

        if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
        {
            $subjectRow.="<td>SGPA</td>";
            array_push($subjectRowCSV,"SGPA");

        }
        elseif($batch_details['gradingSystem']==3)
        {
            $subjectRow.="<td>Percentage</td>";
            array_push($subjectRowCSV,"Percentage");
        }

        $subjectRow.="</tr>";
        $patternRow.="</tr>";

        fputcsv($output, $subjectRowCSV);
        fputcsv($output, $patternRowCSV);

        $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");
        $i=1;
        $studentMarksRow="";
        foreach ($student_list as $students)
        {
            $totalCredits=0;
            $totalOptainMarks=0;
            $studentMarksRowCSV=array();
            $stdRegn=$students['std_regn'];
            $stdName=$students['std_name'];
            $studentMarksRow.="<tr>";

            $studentMarksRow.="<td>".$i."</td>";
            array_push($studentMarksRowCSV,$i);

            $studentMarksRow.="<td>".$stdRegn."</td>";
            array_push($studentMarksRowCSV,$stdRegn);

            $studentMarksRow.="<td>".$stdName."</td>";
            array_push($studentMarksRowCSV,$stdName);

            $index=0;
            $gradeCredit=0;
            foreach ($paperIds as $paperId)
            {
                $flagCheck=0;
                $marksTotal=0;
                $paperdetails=$db->Fetch("*","tbl_papers","WHERE id='$paperId'");
                $paperType=$paperdetails['type'];
                
                $groupDetails=$db->Fetch("*","tbl_assign_paper_staff","WHERE paper_id='$paperId'");
              $groupId=$groupDetails['group_id'];
              $group_id = $groupId;

                if($paperType=='E')
                {
                    $flagCheck=1;
                    $checkElective=$db->Fetch("*","tbl_electivePaperList","WHERE batch_id='$batch_id' AND std_regn='$stdRegn' AND paper_id='$paperId' AND group_id='$group_id'");

                }

                $selectMarksData=$db->Fetch("*","tbl_marks","WHERE batch_id='$batch_id' AND std_regn='$stdRegn' AND paper_id='$paperId' ");
                if($checkElective==true || $flagCheck==0) {
                    if ($selectMarksData == false) {
                        for ($j = 1; $j <= $subjectFields[$index]; $j++) {
                            $studentMarksRow .= "<td>" . "M.N.U." . "</td>";
                            array_push($studentMarksRowCSV, "");
                        }
                    } else {
                                  $marks=finalMarks($stdRegn,$paperId,$batch_id,$group_id,false);
                       //$marks = $selectMarksData['marks'];
                        $marks=explode('-',$marks);

                        $pattern = json_decode($marks[0], true);

                        foreach ($pattern as $key => $value) {
                            if ($value == 'None') {
                                $studentMarksRow .= "<td>" . "&nbsp;" . "</td>";
                                array_push($studentMarksRowCSV, "");
                            } else {
                                if($key=='Total') {
                                    $studentMarksRow .= "<td>" . $value.$marks[1]. "</td>";
                                    array_push($studentMarksRowCSV, $value.$marks[1]);
                                }else{
                                    $studentMarksRow .= "<td>" . $value. "</td>";
                                    array_push($studentMarksRowCSV, $value);


                                }
                                }
                        }
             
                        $totalCredits=$totalCredits+$paperdetails['credits'];
                        $marksTotal = $pattern['Total'];
                        $totalOptainMarks = $totalOptainMarks + $marksTotal;
                        $percentage = round(($marksTotal * 100) / $patternTotal[$index], 0);

                        if ($batch_details['gradingSystem'] == 1) {
                            if ($percentage >= 91) {
                                $grade = "O";
                                $grade_point = 10;
                            } elseif ($percentage >= 81) {
                                $grade = "A+";
                                $grade_point = 9;
                            } elseif ($percentage >= 71) {
                                $grade = "A";
                                $grade_point = 8;
                            } elseif ($percentage >= 61) {
                                $grade = "B+";
                                $grade_point = 7;
                            } elseif ($percentage >= 56) {
                                $grade = "B";
                                $grade_point = 6;
                            } elseif ($percentage >= 51) {
                                $grade = "C";
                                $grade_point = 5;
                            } elseif ($percentage >= 40) {
                                $grade = "P";
                                $grade_point = 4;
                            } elseif ($percentage < 40) {
                                $grade = "F";
                                $grade_point = 0;
                            }
                            $gradeCredit = $gradeCredit + ($credits[$index] * $grade_point);
                            $studentMarksRow .= "<td>" . $grade . "</td>";
                            array_push($studentMarksRowCSV, $grade);
                        } elseif ($batch_details['gradingSystem'] == 2) {
                            if ($percentage <= 100 && $percentage >= 90) {
                                $grade = "O";
                                $grade_point = 10;
                            } elseif ($percentage < 90 && $percentage >= 80) {
                                $grade = "A";
                                $grade_point = 9;
                            } elseif ($percentage < 80 && $percentage >= 70) {
                                $grade = "B";
                                $grade_point = 8;
                            } elseif ($percentage < 70 && $percentage >= 60) {
                                $grade = "C";
                                $grade_point = 7;
                            } elseif ($percentage < 60 && $percentage >= 50) {
                                $grade = "D";
                                $grade_point = 6;
                            } elseif ($percentage < 50) {
                                $grade = "F";
                                $grade_point = 0;
                            }
                            $gradeCredit = $gradeCredit + ($credits[$index] * $grade_point);
                            $studentMarksRow .= "<td>" . $grade . "</td>";
                            array_push($studentMarksRowCSV, $grade);
                        } elseif ($batch_details['gradingSystem'] == 3) {
                            // for 3rd grading system
                        }


                    }
                }
                else{
                    for ($j = 1; $j <= $subjectFields[$index]; $j++) {
                        $studentMarksRow .= "<td>" . "<i class=\"fa fa-tasks\" aria-hidden=\"true\"></i></td>";
                        array_push($studentMarksRowCSV, "---");
                    }
                }
                $index++;




            }
            if($batch_details['gradingSystem']==1 || $batch_details['gradingSystem']==2)
            {
                $sgpa=round($gradeCredit/$totalCredits,2);
                $studentMarksRow.="<th style='text-align: center;'>".$sgpa."</th>";
                array_push($studentMarksRowCSV,$sgpa);
            }
            elseif($batch_details['gradingSystem']==3)
            {
                $per=round(($totalOptainMarks*100)/$totalMaxMarks,2);
                $studentMarksRow.="<th style='text-align: center;'>".$per."%</th>";
                array_push($studentMarksRowCSV,$per."%");
            }

            $i++;
            $studentMarksRow.="</tr>";
            fputcsv($output, $studentMarksRowCSV);

        }
        $filepath="/public/tmp/marks/";
        fclose($output);
        $file=$filepath.$filename;
        $csv_button="<div class='alert alert-success ajaxdata_table' style='display: inline; float: right; border: 1px solid black;' ><a class=ajaxdata_csv href=$file download style='border-bottom: 1px solid blue;'>CSV File is ready to download. To download click here.</a></div>";

        $data_table.=$subjectRow.$patternRow.$studentMarksRow;
        $result=$button.$csv_button.$batch_info.$data_table;

        echo $result;

    }
    else{
        echo "not";
    }

}
function addenquiry(){
    $db=new Database();
    if(isset($_POST['name'])) {
        $name=$_POST['name'];
        $source=$_POST['source'];
        $email=$_POST['email'];
        
        $stream=$_POST['stream'];
        $category=$_POST['category'];
        
        $ph_mobile=$_POST['ph_mobile'];
        $std_father=$_POST['std_father'];
        $school=$_POST['school'];
        $city=$_POST['city'];
        $remarks=$_POST['remarks'];
        $address=$_POST['address'];
        date_default_timezone_set('Asia/Kolkata');
        $current_date=date('Y-m-d H:i:s');
        $user=$_POST['user'];
        $favorite=$_POST['favorite'];
        $status="NEW";

        $f=array("name","email","12th_stream","category","std_mob_num","fat_mob_num","school_name","city","address","status","interested_courses","enquiry_date","attend_by","source","remarks");

        $v=array($name,$email,$stream,$category,$ph_mobile,$std_father,$school,$city,$address,$status,$favorite,$current_date,$user,$source,$remarks);

        $tbl='tbl_enquiry';
        $insert=$db->Insert($tbl,$f,$v);
        if($insert==true)
        {
            
            echo $insert;

        }
        else{
            echo "insert not working";
        }

    }
    else{
        echo "error";
    }
}


function fine_deposit()
{
    $db=New Database();
    if(isset($_POST['id'])) {
        $id=$_POST['id'];
        $libName=trim($_POST['libName']);
        $ids=explode('#-#',$id);
        $transaction_num=$ids[0];
        $acc_num=$ids[1];
        Session::init();
        $receiver_id=Session::get('user');
        $receiver_name=Session::get('name');
        date_default_timezone_set('Asia/Kolkata');
        $fine_receive_date = date("Y-m-d");
        if($libName=='central')
        {
            $transaction_details=$db->Fetch("*",'tbl_book_issue_stu',"WHERE id='$transaction_num'");
        }elseif($libName=='medical')
        {
            $transaction_details=$db->Fetch("*",'tbl_book_issue_stuMed',"WHERE id='$transaction_num'");
        }


        $std_regn=$transaction_details['stu_id'];



        if($transaction_details==true)
        {
            if($transaction_details['paid']=='yes')
            {
                echo "n_allready given";
            }
            else{
                $fields=array('paid','fine_received_by','fine_received_date');
                $values=array('Y',$receiver_id,$fine_receive_date);
                if($libName=='central')
                {
                    $update=$db->Update('tbl_book_issue_stu',$fields,$values,'id',$transaction_num);
                }elseif($libName=='medical')
                {
                    $update=$db->Update('tbl_book_issue_stuMed',$fields,$values,'id',$transaction_num);
                }

                if($update==true)
                {
                    if($libName=='central')
                    {
                        $book_issue_details = $db->FetchList("*", "view_issue_stu", "WHERE stu_id='$std_regn' AND date_of_return='0000-00-00' ORDER BY id ");
                        $fine_details = $db->Fetchlist("*", 'view_issue_stu', "WHERE stu_id='$std_regn' AND fine_amount > '0' AND (paid='N' or paid='no') ORDER BY id");
                        $issue_history = $db->FetchList("*", "view_issue_stu", "WHERE stu_id='$std_regn' ORDER BY id");
                    }elseif($libName=='medical')
                    {
                        $book_issue_details = $db->FetchList("*", "view_issue_stuMed", "WHERE stu_id='$std_regn' AND date_of_return='0000-00-00' ORDER BY id ");
                        $fine_details = $db->Fetchlist("*", 'view_issue_stuMed', "WHERE stu_id='$std_regn' AND fine_amount > '0' AND (paid='N' or paid='no') ORDER BY id");
                        $issue_history = $db->FetchList("*", "view_issue_stuMed", "WHERE stu_id='$std_regn' ORDER BY id");
                    }

                    $issue_details1="<tr>
                        <th>Accession Number</th>
                        <th style='text-align: center;'>Action</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Date of Issue</th>
                        <th>Issued By</th>
                        <th>Remarks</th>
                        <th>Transaction I.D.</th>
                    </tr>";
                    foreach($book_issue_details as $issued_list)
                    {

                        $issue_details1.= '<tr>';
                        $issue_details1.= "<td class='alert-danger' style='text-align: center; font-weight: bold;'>".$issued_list['acc_num'].'</td>';
                        $issue_details1.="<td><button type=submit name=bookreturn  value=".$issued_list['acc_num'].'-'.$issued_list['id']." class='bookreturn btn btn-round btn-primary btn-sm' style='margin-left:20px;'>Return</button></td>";
                        $issue_details1.= '<td>'.$issued_list['book_title'].'</td>';
                        $issue_details1.= '<td>'.$issued_list['author'].'</td>';
                        $issue_details1.= '<td>'.$issued_list['date_of_issue'].'</td>';
                        $issue_details1.= '<td>'.$issued_list['issuer_id'].'</td>';
                        $issue_details1.= '<td>'.$issued_list['remarks'].'</td>';
                        $issue_details1.= '<td>'.$issued_list['id'].'</td>';
                        $issue_details1.= '</tr>';

                    }

                    $fine_details1="<tr>
                        <th>Transaction I.D.</th>
                        <th>Accession Number</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Fine</th>
                        <th>Action</th>
                        <th>Date of Issue</th>
                        <th>Date of Return</th>
                        <th>Issued By</th>
                        <th>Return By</th>

                        <th>Remarks</th>
                    </tr>";

                    foreach($fine_details as $fine_list)
                    {
                        $fine_details1.= '<tr>';
                        $fine_details1.= '<td>'.$fine_list['id'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['acc_num'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['book_title'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['author'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['fine_amount'].'</td>';
                        $fine_details1.= "<td><button class='btn btn-theme02 btn-xs fine-deposite' value=".$fine_list['id']."-".$fine_list['acc_num'].">Fine Deposit</button></td>";
                        $fine_details1.= '<td>'.$fine_list['date_of_issue'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['date_of_return'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['issuer_id'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['receiver_id'].'</td>';
                        $fine_details1.= '<td>'.$fine_list['remarks'].'</td>';
                        $fine_details1.= '</tr>';
                    }

                    $issue_history1="<tr>
                            <th>Transaction I.D.</th>
                            <th>Accession Number</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Fine</th>
                            <th>Paid</th>
                            <th>Fine Received By</th>
                            <th>Fine Received Date</th>
                            <th>Date of Issue</th>
                            <th>Date of Return</th>
                            <th>Issued By</th>
                            <th>Return By</th>
                            <th>Remarks</th>
                        </tr>";


                    foreach($issue_history as $fine_list)
                    {
                        $issue_history1.= '<tr>';
                        $issue_history1.= '<td>'.$fine_list['id'].'</td>';
                        $issue_history1.='<td>'.$fine_list['acc_num'].'</td>';
                        $issue_history1.='<td>'.$fine_list['book_title'].'</td>';
                        $issue_history1.='<td>'.$fine_list['author'].'</td>';
                        $issue_history1.='<td>'.$fine_list['fine_amount'].'</td>';

                        $issue_history1.='<td>';
                        if($fine_list['fine_amount']>0)
                        {

                            if ($fine_list['paid'] == 'Y') {
                                $issue_history1.="<span class='label label-success label-mini'>Paid</span>";
                            } else {
                                $issue_history1.="<span class='label label-warning label-mini'>Due</span>";

                            }
                        }
                        else{
                            $issue_history1.="";
                        }

                        $issue_history1.='</td>';

                        $issue_history1.='<td>'.$fine_list['fine_received_by'].'</td>';
                        $issue_history1.='<td>'.$fine_list['fine_received_date'].'</td>';


                        $issue_history1.='<td>'.$fine_list['date_of_issue'].'</td>';
                        $issue_history1.='<td>'.$fine_list['date_of_return'].'</td>';
                        $issue_history1.='<td>'.$fine_list['issuer_id'].'</td>';
                        $issue_history1.='<td>'.$fine_list['receiver_id'].'</td>';
                        $issue_history1.='<td>'.$fine_list['remarks'].'</td>';
                        $issue_history1.='</tr>';
                    }
                        sleep(2);
                    echo "y_".$transaction_details['fine_amount']." Rs. Fine Received ...".'_'.$issue_details1."_".$fine_details1."_".$issue_history1;
                
                }

                else{
                    echo "n_Problem Occurred";
                }
            }

        }
        else{
            echo "n_Request Not Found";
        }
          }
}

function transportRN(){
    $db = new Database();
    $cat = $_POST['cat'];
    $value = $db->FetchList("id,name,amount", "tbl_fees", "WHERE fee_cat='$cat' ORDER BY name");
    $output = '<select name="fee_id_'.$cat.'" class="form-control validate[required]">
                <option value="">--SELECT--</option>';
    foreach ($value as $val) {
            $output.='<option value="' . $val[0] . '_'.$val[2].'">' . $val[1] . ' ('.$val[2].')</option>';
    }
    $output.='</select>';
    echo $output;
}


function FeeChanger()
{
    $db = new Database();
    $category=$_POST['category'];
    $courseCode=$_POST['courseCode'];
    $output="";
    if($category=='currentCourse')
    {
        $value = $db->FetchList("id,name,amount", "tbl_fees", "WHERE course_id='$courseCode'");
    }
    elseif($category=='hostel'){
        $value = $db->FetchList("id,name,amount", "tbl_fees", "WHERE fee_cat='Hostel' or fee_cat='Food' or fee_cat='HostelSecurity' ");
    }
    elseif($category=='all')
    {
        $value = $db->FetchList("id,name,amount", "tbl_fees", "WHERE 1");
    }elseif($category=='exam') {
        $value = $db->FetchList("id,name,amount", "tbl_fees", "WHERE fee_cat='examination'");
    }else{
        $value=false;
    }
    foreach ($value as $val) {
        $output.='<option value="' . $val[0].'">' . $val[1] .' Rs : '.$val[2].'</option>';
    }
    echo $output;

}

function checkStudentDetailsforpromotion() {
    $db=new Database();
    if(isset($_POST['reg_no'])) {
        Session::init();
        $receiver_id=Session::get('user');
        $reg_no=trim($_POST['reg_no']);
        $stu_details=$db->Fetch('*','tbl_students',"WHERE std_regn='$reg_no'");
        $stu_course_details=$db->Fetch('*','view_student_course_data',"WHERE std_regn='$reg_no' ");
        $user_info=$db->Fetch('*','tbl_users',"WHERE username='$receiver_id'");
        $staff_dept=$db->Fetch('*','tbl_staff',"WHERE staff_regn='$receiver_id'");
        $course_name=$stu_course_details['course_name'];
        $stu_dept_id=$db->Fetch('*','tbl_courses',"WHERE course_name='$course_name'");
        $faculty_id=$staff_dept['faculty_id'];
        $stu_status=$db->Fetch('*','tbl_assign_class',"WHERE std_regn='$reg_no' ORDER BY id  DESC LIMIT 0,1");
        $department=$db->FetchList('*','tbl_department',"WHERE faculty_id='$faculty_id'");
        $dept_name="cools";
        $flag=0;
       if(($receiver_id=='admin') OR ($receiver_id=='admin1') OR ($receiver_id=='admin2')){
           $flag=1;
       }
        foreach ($department as $dept){

            if( $stu_dept_id['dept_id']==$dept['dept_id']){
                $flag=1;
            }

        }

        if($flag==1){
           echo $stu_details['std_name']."|_|".$course_name."|_|".$stu_course_details['current_batch'];
        }

        else{
            echo "";
        }


     /*  // $course_id='isbb';
         //  $course_name=$db->Fetch('*','tbl_courses',"WHERE course_id='$course_id'");
        if($stu_details['std_regn']==true)
        {
        //    echo $stu_details['std_name']."|_|".$dept_name."|_|".$staff_dept['dept_id'];
          //  echo $stu_details['std_name']."|_|".$course_name."|_|".$stu_course_details['current_batch'];

        }
        else
        {
            echo "";
        }*/
    }
}

function getstate(){
    $db = new Database();
   $id=$_POST['id'];
   $states=$db->FetchList("*",'states',"WHERE country_id='$id' ");
   $option="";
   foreach ($states as $state){
       $option.="<option value='$state[id]'>".$state['name']."</option>";
   }
   echo $option;


}

function getcity(){
    $db = new Database();
    $id=$_POST['id'];
    $states=$db->FetchList("*",'cities',"WHERE state_id='$id' ");
    $option="";
    foreach ($states as $state){
        $option.="<option value='$state[id]'>".$state['name']."</option>";
    }
    echo $option;


}


function attRegister()
{
    $db = new Database();
    sleep(1);
    if(isset($_POST['paper_id']))
    {
        $paper_id=trim($_POST['paper_id']);
        $batch_id=trim($_POST['batch_id']);
        $group_id=trim($_POST['group_id']);
        $username=trim($_POST['username']);
        $role_id=trim($_POST['role_id']);
        $month=trim($_POST['month']);
        $month=explode(',',$month);


        $paper_details=$db->Fetch("*",'tbl_papers',"WHERE id='$paper_id' ");
        $batch_details=$db->Fetch("*",'tbl_batches',"WHERE id='$batch_id' ");

        $batch_sem=$batch_details['sem'];

        if($group_id==0)
        {
            $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' ORDER BY std_regn");
        }
        else{
            $student_list=$db->FetchList('*','tbl_assign_group',"where group_id='$group_id' AND active=1");
            $stu_list_gv="";
            foreach ($student_list as $stu)
            {
                $stu_list_gv.="'";
                $stu_list_gv.=$stu['std_regn'];
                $stu_list_gv.="'";
                $stu_list_gv.=",";
            }
            $stu_list_gv=rtrim($stu_list_gv,',');

            $student_list=$db->FetchList("*",'view_active_students',"WHERE batch_id='$batch_id' AND std_regn IN ($stu_list_gv) ORDER BY std_regn");
        }

        $middletable= "<br><table class='table table-bordered table-striped table-condensed'>";
        $middletable.="<tr><th>S.No.</th><th>Reg. No.</th><th>Name</th>";
        $middletableLecture="<tr><td></td><td></td><td></td>";
        $firstday = date('01-' . $month[0] . '-2021');
        $firstday = date("Y-m-d", strtotime($firstday));
        $startday = $firstday;
        $lastday = date(date('t', strtotime($firstday)) .'-' . $month[0] . '-Y');

        while (strtotime($startday) <= strtotime($lastday)) {
            $middletable.="<th colspan='4'>";
            $middletable.=date_format(date_create($startday),'d-m-Y');
            $middletable.="</th>";
            $middletableLecture.="<td align='center'>1</td><td align='center'>2</td><td align='center'>3</td><td align='center'>4</td>";
            $startday = date ("Y-m-d", strtotime("+1 day", strtotime($startday)));

        }

        $middletableLecture.="</tr>";
        $middletable.="<td>Total Present<td>";
        $middletable.=$middletableLecture;
        $middletable.="<tr>";


        $i=1;
        foreach($student_list as $students)
        {
            $totalPresent=0;
            $assignDate=$students['assign_date'];
            $middletable.="<tr>";
            $middletable.="<td>";
            $middletable.=$i;
            $middletable.="</td>";

            $middletable.="<td>";
            $middletable.=$students['std_regn'];
            $middletable.="</td>";

            $std_regn=$students['std_regn'];

            $middletable.="<td>";
            $middletable.=$students['std_name'];
            $middletable.="</td>";

            $numberOfDays=cal_days_in_month(CAL_GREGORIAN,$month[0],$month[1]);

            $firstday = date('01-' . $month[0] . '-Y');
            $firstday = date("Y-m-d", strtotime($firstday));

            $startday = $firstday;
            $lastday = date(date('t', strtotime($firstday)) .'-' . $month[0] . '-Y');


            while (strtotime($startday) <= strtotime($lastday)) {
                    $day = date('l', strtotime($startday));
                    if($day=='Sunday')
                    {
                        $middletable.="<td style='background: grey;'>&nbsp;</td>";
                        $middletable.="<td style='background: grey;'>&nbsp;</td>";
                        $middletable.="<td style='background: grey;'>&nbsp;</td>";
                        $middletable.="<td style='background: grey;'>&nbsp;</td>";
                    }
                    else{
                        if($assignDate>$startday)
                        {

                        }else{
                            $attStatus=$db->Fetch("*","tbl_attendance","WHERE batch_id='$batch_id' AND paper_id='$paper_id' AND lecture_num=1 AND std_regn='$std_regn' AND att_datetime='$startday'");
                        }
                        $middletable.="<td>";
                        $middletable.=attendanceStatus($attStatus['absent']);
                        $middletable.="</td>";
                        if($attStatus['absent']=='0')
                        {
                            $totalPresent++;
                        }

                        if($assignDate>$startday) {
                        }
                        else{
                            $attStatus=$db->Fetch("*","tbl_attendance","WHERE batch_id='$batch_id' AND paper_id='$paper_id' AND lecture_num=2 AND std_regn='$std_regn' AND att_datetime='$startday'");
                        }
                        $middletable.="<td>";
                        $middletable.=attendanceStatus($attStatus['absent']);
                        $middletable.="</td>";

                        if($attStatus['absent']=='0')
                        {
                            $totalPresent++;
                        }
                        
                        // for 3rd lecture start
                        if($assignDate>$startday) {
                        }
                        else{
                            $attStatus=$db->Fetch("*","tbl_attendance","WHERE batch_id='$batch_id' AND paper_id='$paper_id' AND lecture_num=3 AND std_regn='$std_regn' AND att_datetime='$startday'");
                        }
                        $middletable.="<td>";
                        $middletable.=attendanceStatus($attStatus['absent']);
                        $middletable.="</td>";

                        if($attStatus['absent']=='0')
                        {
                            $totalPresent++;
                        }
                        // for 3rd lecture end
                        
                        // for 4th lecture start
                        if($assignDate>$startday) {
                        }
                        else{
                            $attStatus=$db->Fetch("*","tbl_attendance","WHERE batch_id='$batch_id' AND paper_id='$paper_id' AND lecture_num=4 AND std_regn='$std_regn' AND att_datetime='$startday'");
                        }
                        $middletable.="<td>";
                        $middletable.=attendanceStatus($attStatus['absent']);
                        $middletable.="</td>";

                        if($attStatus['absent']=='0')
                        {
                            $totalPresent++;
                        }
                        // for 4th lecture end
                        
                }


                $startday = date ("Y-m-d", strtotime("+1 day", strtotime($startday)));
            }

            $middletable.="<td align='center'><span style='color:green;'>".$totalPresent."</span></td>";
            $middletable.="</tr>";

            $i++;
        }
        $middletable.="</table>";
        //$middletable.="<p>query".$attStatus."</p>";

        echo $middletable;

        //echo "Success".$paperID.$user.$batchID.$groupID.$roleID;
    }
    else{
        echo "fail";
    }
}

function attendanceStatus($status)
{
    if($status=='0')
    {
        return "<span style='color:blue;'>P</span>";
    }
    elseif($status=='1')
    {
        return "<span style='color:red;'>A</span>";
    }else{
        return "";
    }
}

function settingupdate(){
    $db=new Database();
    $val=$_POST['value'];
    $updatefield=$_POST['id'];
    $update=$db->runSQL("UPDATE tbl_config SET ".$updatefield." = ".$val." WHERE 1=1");
   

}

if ($_REQUEST['a']) {
    $fun = $_REQUEST['a'];
    @$fun();
}
