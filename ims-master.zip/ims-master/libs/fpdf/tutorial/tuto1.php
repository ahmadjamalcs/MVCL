<?php
require('../fpdf.php');

$p=array(15,10);
$pdf=new FPDF(P,cm,$p);
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,0,'Hello World!');
$pdf->Output();
?>
