<?php

class Database {

    private $Connection;
    private $condition;
    private $recordSet;
    private $newQuery;

    //Constructor for connecting database.
    function __construct() {
        $this->Connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS) or
                trigger_error(mysqli_error(), E_USER_ERROR);
        mysqli_select_db($this->Connection, DB_NAME);
    }

    private function exportCSV($titles){
        $name='report.csv';
        $filename = ROOT."public/".$name;
        $file=fopen($filename,"w");
        fputcsv($file,$titles);

        $q=mysqli_query($this->Connection,$this->newQuery.$this->condition);
        while($r=mysqli_fetch_row($q)){
            fputcsv($file,$r);
        }

        fclose($file);
        header('Location:'.URL.'public/'.$name);
    }
    private function CountRows() {
        return mysqli_num_rows($this->recordSet);
    }

    private function Sort() {

        foreach ($_POST as $key => $value) {
            $pos = strpos($key, 'ASC');
            $pos2 = strpos($key, 'ESC');
            if ($pos != FALSE) {
                $sort = $key;
                break;
            }
            if ($pos2 != FALSE) {
                $sort = $key;
                break;
            }
        }
        if (!isset($sort)) {
            return FALSE;
        }

        $sort = explode("-", $sort);
        $_SESSION['order'] = "ORDER BY $sort[0] $sort[1]";
        return;
    }

    private function GetPage() {
        if (isset($_POST['sub_page'])) {
            $_SESSION['page'] = $_POST['sel_page'];
            return $_SESSION['page'];
        } else if (isset($_POST['previous'])) {
            $_SESSION['page'] = $_POST['pg_prev'];
            return $_SESSION['page'];
        } else if (isset($_POST['next'])) {
            $_SESSION['page'] = $_POST['pg_next'];
            return $_SESSION['page'];
        } else if ($_SESSION['page'] != 0) {
            return $_SESSION['page'];
        } else {
            return 1;
        }
    }

    private function SearchRecords() {
        if (isset($_POST['search_reset'])) {
            $_SESSION['condition'] = FALSE;
            return FALSE;
        } else if (isset($_POST['search_submit'])) {
            if ($_POST['search_value'] == "" || !isset($_POST['search_value'])) {
                $_SESSION['condition'] = FALSE;
                return FALSE;
            }

            $key = $_POST['search_key'];
            $value = $_POST['search_value'];
            $_SESSION['condition'] = "WHERE $key LIKE '%$value%'";
            return $_SESSION['condition'];
        } else if (isset($_SESSION['condition'])) {
            return $_SESSION['condition'];
        } else {
            return FALSE;
        }
    }

    //for display datatable
    public function GetRecords($titles, $fields, $table, $criteria=FALSE, $add=FALSE, $delete=FALSE, $edit=FALSE, $details=FALSE, $search=FALSE, $publish=FALSE, $image=FAlSE) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }
        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

        $this->Sort();

        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table ";

        $this->newQuery=$query;

        $query.=$this->condition;
        $this->recordSet=mysqli_query($this->Connection,$query);
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        $qr = mysqli_query($this->Connection, $query);

        if(isset($_POST['ex_csv'])){
            $this->exportCSV($titles);
        }

        $total = $this->CountRows();

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';


        $output.='<div align="right">
        <input type="submit" name="ex_doc" value="Export to Word" />
        <input type="submit" name="ex_xls" value="Export to Excel" />
        <input type="submit" name="ex_csv" value="Export to CSV" />
        </div><br/>';



        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }
        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del=explode(",", $delete); $lbl="Delete";
            if(isset ($del[1])) { $lbl=$del[1]; }
            
            $output.='<input type="submit" id="del_sub" name="del_sub" value="'.$lbl.'" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table>';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . ' 
                <input type="submit" 
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />  
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . $edit[0] . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del=explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">'.$details['0'].'</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del=explode(",", $delete); $lbl="Delete";
            if(isset ($del[1])) { $lbl=$del[1]; }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="'.$lbl.'" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" /></div></center></form></div>';

        return $output;
    }
    
    //Functions for inserting records. 
    public function Insert($table, $fields, $values) {

        $flag = count($fields);

        if ($flag != count($values)) {
            return FALSE;
        }

        $query = "INSERT INTO $table ( ";

        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        $query.=") values (";

        for ($i = 0; $i < $flag; $i++) {
            $query.="'$values[$i]'";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        $query.=")";
        //return $query;
        return mysqli_query($this->Connection, $query);
    }

    //Function for deleting one record from the database
    public function Delete($table, $key, $value) {

        $query = "DELETE from $table where $key='$value'";
        return mysqli_query($this->Connection, $query);
    }

    public function Fetch($fields, $table, $qry=FALSE) {
        $query = "SELECT $fields from $table $qry";
        $result = mysqli_query($this->Connection, $query);
        if (mysqli_num_rows($result) < 2) {
            return mysqli_fetch_array($result);
        }
    }

    public function FetchList($fields, $table, $qry=FALSE) {
        $query = "SELECT $fields from $table $qry";
        $result = mysqli_query($this->Connection, $query);
        if (mysqli_num_rows($result) == 0) {
            return FALSE;
        } else {
            $list = array();
            while ($row = mysqli_fetch_array($result)) {
                $list[] = $row;
            }
            return $list;
        }
    }
    public function runQuery($qry) {
        $result = mysqli_query($this->Connection, $qry);
        return mysqli_fetch_array($result);
    }

    //Function for publishing one record from the database
//    public function Publish($table, $key, $value) {
//
//        $query = "UPDATE $table SET publish=1 where $key='$value'";
//        return mysqli_query($this->Connection,$query);
//    }
//
//    //Function for unpublishing one record from the database
//    public function UnPublish($table, $key, $value) {
//
//        $query = "UPDATE $table SET publish=0 where $key='$value'";
//        return mysqli_query($this->Connection,$query);
//    }
    //Function for updating one record from the database
    public function Update($table, $fields, $values, $key, $value) {
        $flag = count($fields);
        if ($flag != count($values)) {
            return FALSE;
        }
        $query = "UPDATE $table SET ";
        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]='$values[$i]'";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        $query.=" WHERE $key='$value'";
        return mysqli_query($this->Connection, $query);
    }
    public function UpdateI($table, $fields, $values, $condition=FALSE) {
        $flag = count($fields);
        if ($flag != count($values)) {
            return FALSE;
        }
        $query = "UPDATE $table SET ";
        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]=$values[$i]";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        if($condition==FALSE){ $condition=""; } else { $condition=" WHERE $condition"; }
        $query.=$condition;
        return mysqli_query($this->Connection, $query);
    }

}
