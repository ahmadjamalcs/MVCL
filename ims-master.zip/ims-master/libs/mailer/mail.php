<?php

/*function sendmail($to,$subject,$body){
	require_once 'swift_required.php';
$transport = Swift_SmtpTransport::newInstance('ssl://smtp.gmail.com', 465)
    ->setUsername('webadmin@glocaluniversity.edu.in') // Your Gmail Username
    ->setPassword('f7cd96ef'); // Your Gmail Password
$mailer = Swift_Mailer::newInstance($transport);
$message = Swift_Message::newInstance($subject)
    ->setFrom(array('ims@theglocaluniversity.in'=>'Glocal IMS')) // can be $_POST['email'] etc...
    ->setTo($to) // your email / multiple supported.
    ->setBody($body, 'text/html');
	return $mailer->send($message);
}
*/