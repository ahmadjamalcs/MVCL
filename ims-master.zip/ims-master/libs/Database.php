<?php

class Database {

    private $Connection;
    private $pdoConnection;
    private $condition;
    private $newQuery;
    private $activityName;
    private $table_name;
    private $table_key;
    private $activityDescription;


    //Constructor for connecting database.
    function __construct() {
        $this->Connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS) or
                trigger_error(mysqli_error(), E_USER_ERROR);
        mysqli_select_db($this->Connection, DB_NAME);

        mysqli_select_db($this->Connection, DB_NAME);

        //list($dbhost,$dbname,$dbuser,$dbpass) = array(DB_HOST,DB_NAME,DB_USER,DB_PASS);
        // PDO connection
        $this->pdoConnection = new PDO("mysql:host=".DB_HOST."; dbname=".DB_NAME, DB_USER,DB_PASS);
 

    }

    private function addActivity() {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('d-m-Y');
        $time = date('H:i:s');
        $userid = Session::get('user_id');
        $username = Session::get('user');
        $ip = $_SERVER['REMOTE_ADDR'];
        $q = "INSERT INTO tbl_useractivity 
            (userid, table_key, table_name, username, activity, des, date, time, ip) VALUES 
            ('$userid', '$this->table_key', '$this->table_name', '$username', '$this->activityName', '$this->activityDescription', '$date', '$time', '$ip')";
        return mysqli_query($this->Connection, $q);
    }

    private function CountRows($table) {
        $result = mysqli_query($this->Connection, "SELECT COUNT(*) AS id FROM $table $this->condition");
        $num = mysqli_fetch_array($result);
        $count = $num['id'];
        return $count;
    }

    private function Sort() {

        foreach ($_POST as $key => $value) {
            $pos = strpos($key, 'ASC');
            $pos2 = strpos($key, 'ESC');
            if ($pos != FALSE) {
                $sort = $key;
                break;
            }
            if ($pos2 != FALSE) {
                $sort = $key;
                break;
            }
        }
        if (!isset($sort)) {
            return FALSE;
        }

        $sort = explode("-", $sort);
        $_SESSION['order'] = "ORDER BY $sort[0] $sort[1]";
        return;
    }

    private function GetPage() {
        if (isset($_POST['sub_page'])) {
            $_SESSION['page'] = $_POST['sel_page'];
            return $_SESSION['page'];
        } else if (isset($_POST['previous'])) {
            $_SESSION['page'] = $_POST['pg_prev'];
            return $_SESSION['page'];
        } else if (isset($_POST['next'])) {
            $_SESSION['page'] = $_POST['pg_next'];
            return $_SESSION['page'];
        } else if ($_SESSION['page'] != 0) {
            return $_SESSION['page'];
        } else {
            return 1;
        }
    }

    private function SearchRecords() {
        if (isset($_POST['search_reset'])) {
            $_SESSION['condition'] = FALSE;
            return FALSE;
        } else if (isset($_POST['search_submit'])) {
            if ($_POST['search_value'] == "" || !isset($_POST['search_value'])) {
                $_SESSION['condition'] = FALSE;
                return FALSE;
            }

            $key = $_POST['search_key'];
            $value = $_POST['search_value'];
            $_SESSION['condition'] = "WHERE $key LIKE '%$value%'";
            return $_SESSION['condition'];
        } else if (isset($_SESSION['condition'])) {
            return $_SESSION['condition'];
        } else {
            return FALSE;
        }
    }

    private function exportCSV($titles, $file) {
        $name = 'rep_' . $file . '.csv';
        $filename = ROOT . "public/" . $name;
        $file = fopen($filename, "w");
        fputcsv($file, $titles);

        $q = mysqli_query($this->Connection, $this->newQuery);
        while ($r = mysqli_fetch_row($q)) {
            fputcsv($file, $r);
        }

        fclose($file);
        header('Location:' . URL . 'public/' . $name);
    }

    //for display datatable
    public function GetRecords($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }

        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

        $this->Sort();

        $sort = $_SESSION['order'];
         
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
//return $query;
        $this->newQuery = $query;
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }



        $qr = mysqli_query($this->Connection, $query);


        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . ' 
                <input type="submit" 
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />  
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . $edit[0] . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" /> 
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }


    //Function for print values without grid
    public function GetRecords_new($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false,$fine=False) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }


        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

       // $this->Sort();
//$query.="ORDER BY date_of_issue";
        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();

        //$query.="order by date_of_issue" ;
        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
        $this->newQuery = $query;
        $query.=" ORDER BY date_of_issue desc";
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }


        //return $query;
        $qr = mysqli_query($this->Connection, $query);


        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid" class="table table-bordered table-striped table-condensed">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . '
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . $edit[0] . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" />
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }
    
    public function GetRecords_assisgnments($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }

        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

        $this->Sort();

        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
//return $query;
        $this->newQuery = $query;
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }


        $qr = mysqli_query($this->Connection, $query);


        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . ' 
                <input type="submit" 
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />  
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . "Uploaded Assignment" . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }

        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a target="_blank" href="' .URL."public/docs/" . $r[2] . "" . '">' . 'File' . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" /> 
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }


    public function GetRecords_join($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }

        if ($image != FALSE) {
            $query.=",";
            $query.=$image[2].".".$image[1];
        }

        $this->Sort();
        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
        $this->newQuery = $query;
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }



        $qr = mysqli_query($this->Connection, $query);
        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . '
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . $edit[0] . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did= $del[0];
                } elseif ($publish != FALSE) {
                    $did= $publish;
                }

                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" />
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }

    public function GetRecords_batches($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }

        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

        $this->Sort();

        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
//return $query;
        $this->newQuery = $query;
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }



        $qr = mysqli_query($this->Connection, $query);


        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . ' 
                <input type="submit" 
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />  
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . "Time Table" . '</th>';

            $output.='<th>' . $edit[0] . '</th>';
             }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . "batches/timetable" . '/' . $r[$edit[2]] . '">' . "View-Time Table" . '</a></td>';

                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" /> 
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }


    //function for get my paper list custom

    public function GetRecords_mypaperlist($titles, $fields, $table, $criteria = FALSE, $add = FALSE, $delete = FALSE, $edit = FALSE, $details = FALSE, $search = FALSE, $publish = FALSE, $image = FAlSE, $export = TRUE,$extra_field=false) {

        $titles_sum = count($titles);
        $fields_sum = count($fields);
        $page_limit = PAGELIMIT;
        $page = $this->GetPage();

        $start = ($page - 1) * $page_limit;

        $query = "SELECT ";
        for ($i = 0; $i < $fields_sum; $i++) {
            $query.=$fields[$i];
            if ((($fields_sum) - $i) != 1) {
                $query.=",";
            }
        }

        if($extra_field!=false){
            $query.=",$extra_field";
        }

        if ($image != FALSE) {
            $query.=",";
            $query.=$image[1];
        }

        $this->Sort();

        $sort = $_SESSION['order'];
        $this->condition = $this->SearchRecords();


        if ($criteria != FALSE) {
            if ($this->condition != FALSE) {
                $this->condition = "$this->condition AND $criteria";
            } else {
                $this->condition = "WHERE $criteria";
            }
        }

        $query.=" from $table $this->condition";
//return $query;
        $this->newQuery = $query;
        $query.=" $sort LIMIT $start, $page_limit";
        //return $query;
        if ($export == true) {
            if (isset($_POST['ex_csv'])) {
                $this->exportCSV($titles, $table);
            }
        }



        $qr = mysqli_query($this->Connection, $query);


        $total = $this->CountRows($table);

//        if($total==0){
//            return FALSE;
//        }

        $output = '<div id="datatable"><form id="frm_data" enctype="multipart/form-data" method="post">';

        if ($export == true) {
            $output.='<div align="right">
            <input type="submit" name="ex_csv" value="Export to CSV" />
            </div><br/>';
        }

        if ($search != FALSE) {
            $output.='<div id="search">';
            $output.='Search Records: <Select name="search_key" id="search_key">';
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<option value="' . $fields[$i] . '">' . $titles[$i] . '</option>';
            }
            $output.='</select> <input type="text" name="search_value" id="search_value" />';
            $output.=' <input type="submit" name="search_submit" value="Go!" />';
            $output.=' <input type="submit" name="search_reset" value="Clear Search" /></div>';
        }


        $output.='<br><div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }

            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" /> ';
            $output.='<input type="submit" name="unpublish" value="Unpublish" /> ';
        }
        $output.='</div>';
        $output.='<table id="grid">';
        $output.='<tr>';
        if ($delete != FALSE || $publish != FALSE) {
            $output.='<th> </th>';
        }
        for ($i = 0; $i < $titles_sum; $i++) {
            $output.='<th>' . $titles[$i] . ' 
                <input type="submit" 
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8595;" name="' . $fields[$i] . '-ASC" />  
                <input type="submit"
                style="width:10px;height:20px;padding: 0px 0px 0px 0px;border: 1px solid #CCCCCC;"
                value="&#8593;" name="' . $fields[$i] . '-DESC" />
            </th>';
        }

        if ($image != FALSE) {
            $output.='<th>' . $image[0] . '</th>';
        }
        if ($edit != FALSE) {
            $output.='<th>' . "Time Table" . '</th>';

            $output.='<th>' . $edit[0] . '</th>';
        }
        if ($details != FALSE) {
            $output.='<th>' . $details[0] . '</th>';
        }
        $output.='</tr>';
        while ($r = mysqli_fetch_array($qr)) {
            $output.='<tr>';
            if ($delete != FALSE || $publish != FALSE) {
                if ($delete != FALSE) {
                    $del = explode(",", $delete);
                    $did = $del[0];
                } elseif ($publish != FALSE) {
                    $did = $publish;
                }
                $output.='<td><input type="checkbox" name="checkbox[]" id="checkbox[]" value="' . $r[$did] . '" /></td>';
            }
            for ($i = 0; $i < $titles_sum; $i++) {
                $output.='<td>' . $r[$i] . '</td>';
            }
            if ($image != FALSE) {
                $output.='<td><img src="' . URL . 'skins/' . SKIN . '/images/' . $r[$image[1]] . '.png" /></td>';
            }
            if ($edit != FALSE) {
                $output.='<td><a href="' . "timetable" . '/' . $r[$edit[2]]."+".$r['batch_id'] . '">' . "View-Time Table" . '</a></td>';

                $output.='<td><a href="' . $edit[1] . '/' . $r[$edit[2]] . '">' . $edit[0] . '</a></td>';
            }
            if ($details != FALSE) {
                $output.='<td><a href="' . $details[1] . '/' . $r[$details[2]] . '">' . $details['0'] . '</a></td>';
            }
            $output.='</tr>';
        }
        $output.='</table>';
        $output.='<div id="actions">';
        if ($add != FALSE) {
            $output.='<a href="' . $add . '" id="addnew"><b>Add New </b></a>';
        }
        if ($delete != FALSE) {
            $del = explode(",", $delete);
            $lbl = "Delete";
            if (isset($del[1])) {
                $lbl = $del[1];
            }
            $output.='<input type="submit" id="del_sub" name="del_sub" value="' . $lbl . '" onclick="return del();" /> ';
        }
        if ($publish != FALSE) {
            $output.='<input type="submit" name="publish" value="Publish" />';
            $output.='<input type="submit" name="unpublish" value="Unpublish" />';
        }
        $output.='</div><br>';
        $tpage = ceil($total / $page_limit);

        $output.='<br><center><div id="pagination" style="margin:auto">';
        $pg_prev = 0;
        $pg_next = 0;
        if ($page > 1) {
            $pg_prev = $page - 1;
            $output.='<input type="submit" name="previous" value="Previous Page" />';
        }
        $output.= ' Page No. ' . $page . ' of ' . $tpage . ' Page(s) ';
        if ($tpage > $page) {
            $pg_next = $page + 1;
            $output.= '<input type="submit" name="next" value="Next Page" />';
        }

        $output.=' Jump to page: <select name="sel_page">';
        for ($i = 1; $i <= $tpage; $i++) {
            $output.='<option value="' . $i . '">' . $i . '</option>';
        }
        $output.='</select> <input type="submit" name="sub_page" value="Go!" />';
        $output.= '<input type="hidden" name="pg_prev" value="' . $pg_prev . '" />
            <input type="hidden" name="pg_next" value="' . $pg_next . '" /> 
                Total <b>' . $total . '</b> record(s) found.</div></center></form></div>';

        return $output;
    }

    //function to count records
    public function countRecords($fields, $table, $query = "") {
        $query = "SELECT $fields FROM $table $query";
        $result = mysqli_query($this->Connection, $query);
        return mysqli_num_rows($result);
    }

    //Functions for inserting records. 
    public function Insert($table, $fields, $values) {


        $this->table_name = $table;
        $this->table_key = "--";
        $this->activityName = "Add";
        $this->activityDescription = "<b>Values added- </b><br>";
        $flag = count($fields);

        if ($flag != count($values)) {
            return FALSE;
        }

        $query = "INSERT INTO $table ( ";

        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }

        $query.=") values (";

        for ($i = 0; $i < $flag; $i++) {
            $query.="'$values[$i]'";
            $this->activityDescription.=$values[$i];
            if (($flag - $i) != 1) {
                $query.=", ";
                $this->activityDescription.=",";
            }
        }

         $query.=")";

         if ($table != "tbl_session") {
            $this->addActivity();
         }

      // return $query;
         mysqli_query($this->Connection, $query);
         return mysqli_insert_id($this->Connection);
    }

    //Function for deleting one record from the database
    public function Delete($table, $key, $value) {

        $this->table_name = $table;
        $this->table_key = $key;
        $this->activityName = "Delete";
        $this->activityDescription = "<b>Deleted Record Values- </b><br>";

        $q = mysqli_query($this->Connection, "SELECT * FROM $table WHERE $key='$value'");
        $r = mysqli_fetch_row($q);
        for ($i = 0; $i < count($r); $i++) {
            $this->activityDescription.=$r[$i] . ', ';
        }

        if ($table != "tbl_useractivity") {
            $this->addActivity();
        }

        $query = "DELETE from $table where $key='$value'";
        return mysqli_query($this->Connection, $query);
    }

    public function Fetch($fields, $table, $qry = FALSE) {
        $query = "SELECT $fields from $table $qry";
        $result = mysqli_query($this->Connection, $query);

        if (mysqli_num_rows($result) < 2) {
            return mysqli_fetch_array($result);
        }
    }

    public function FetchList($fields, $table, $qry = FALSE) {
        $query = "SELECT $fields from $table $qry";
        //return $query;
        $result = mysqli_query($this->Connection, $query);
        if (mysqli_num_rows($result) == 0) {
            return FALSE;
        } else {
            $list = array();
            while ($row = mysqli_fetch_array($result)) {
                $list[] = $row;
            }
            return $list;
        }
    }

    public function runQuery($qry) {
        //return $qry;
        $result = mysqli_query($this->Connection, $qry);
        return mysqli_fetch_array($result);

    }

    public function runSQL($qry) {
        //return $qry;
        mysqli_query($this->Connection, $qry);
        //return $qry;
        return mysqli_insert_id($this->Connection);

    }

    //Function for publishing one record from the database
//    public function Publish($table, $key, $value) {
//
//        $query = "UPDATE $table SET publish=1 where $key='$value'";
//        return mysqli_query($this->Connection,$query);
//    }
//
//    //Function for unpublishing one record from the database
//    public function UnPublish($table, $key, $value) {
//
//        $query = "UPDATE $table SET publish=0 where $key='$value'";
//        return mysqli_query($this->Connection,$query);
//    }
    //Function for updating one record from the database
    public function Update($table, $fields, $values, $key, $value) {

        $this->table_name = $table;
        $this->table_key = $key;
        $this->activityName = "Update";
        $this->activityDescription = "<b>Previous Values- </b><br>";

        $q = mysqli_query($this->Connection, "SELECT * FROM $table WHERE $key='$value'");
        $r = mysqli_fetch_row($q);
        for ($i = 0; $i < count($r); $i++) {
            $this->activityDescription.=$r[$i] . ', ';
        }
        $this->activityDescription.="<br><b> - New Values - </b><br>";

        $flag = count($fields);
        if ($flag != count($values)) {
            return FALSE;
        }
        $query = "UPDATE $table SET ";
        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]='$values[$i]'";
            $this->activityDescription.=$values[$i] . ', ';
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        $query.=" WHERE $key='$value'";
        if ($table != "tbl_session") {
            $this->addActivity();
        }
        //return $query;
        return mysqli_query($this->Connection, $query);
    }

    public function UpdateI($table, $fields, $values, $condition = FALSE) {
        $flag = count($fields);
        if ($flag != count($values)) {
            return FALSE;
        }
        $query = "UPDATE $table SET ";
        for ($i = 0; $i < $flag; $i++) {
            $query.="$fields[$i]=$values[$i]";
            if (($flag - $i) != 1) {
                $query.=", ";
            }
        }
        if ($condition == FALSE) {
            $condition = "";
        } else {
            $condition = " WHERE $condition";
        }
        $query.=$condition;

    return mysqli_query($this->Connection, $query);

    }
    public function count_rows_sql($result)
    {
        //return $resource;
        return mysqli_num_rows($result);
        //return mysqli_num_rows($resource);
    }
    public function get_time_difference_php($created_time)
    {
        date_default_timezone_set('Asia/Kolkata'); //Change as per your default time
        $str = strtotime($created_time);
        $today = strtotime(date('Y-m-d H:i:s'));

        // It returns the time difference in Seconds...
        $time_differnce = $today-$str;

        // To Calculate the time difference in Years...
        $years = 60*60*24*365;

        // To Calculate the time difference in Months...
        $months = 60*60*24*30;

        // To Calculate the time difference in Days...
        $days = 60*60*24;

        // To Calculate the time difference in Hours...
        $hours = 60*60;

        // To Calculate the time difference in Minutes...
        $minutes = 60;

        if(intval($time_differnce/$years) > 1)
        {
            return intval($time_differnce/$years)." years ago";
        }else if(intval($time_differnce/$years) > 0)
        {
            return intval($time_differnce/$years)." year ago";
        }else if(intval($time_differnce/$months) > 1)
        {
            return intval($time_differnce/$months)." months ago";
        }else if(intval(($time_differnce/$months)) > 0)
        {
            return intval(($time_differnce/$months))." month ago";
        }else if(intval(($time_differnce/$days)) > 1)
        {
            return intval(($time_differnce/$days))." days ago";
        }else if (intval(($time_differnce/$days)) > 0)
        {
            return intval(($time_differnce/$days))." day ago";
        }else if (intval(($time_differnce/$hours)) > 1)
        {
            return intval(($time_differnce/$hours))." hours ago";
        }else if (intval(($time_differnce/$hours)) > 0)
        {
            return intval(($time_differnce/$hours))." hour ago";
        }else if (intval(($time_differnce/$minutes)) > 1)
        {
            return intval(($time_differnce/$minutes))." minutes ago";
        }else if (intval(($time_differnce/$minutes)) > 0)
        {
            return intval(($time_differnce/$minutes))." minute ago";
        }else if (intval(($time_differnce)) > 1)
        {
            return intval(($time_differnce))." seconds ago";
        }else
        {
            return "few seconds ago";
        }
    }
   private function semesterCalc($semYear,$sem)
    {
        $current_sem=0;
        if($semYear=='Y')
        {
            $year=intval(date('m'));
            if($year<6)
            {
                if($sem!=1) {
                    $current_sem = $sem * 2+1;
                }
                else{
                    $current_sem=$sem+1;
                }
            }
            else{
                if($sem!=1) {
                    $current_sem = $sem * 2;
                }
                else{
                    $current_sem=$sem;
                }
            }
        }
        else{
            $current_sem=$sem;
        }
        return $current_sem;
    }
    public function startingDueDateCals($stdRegn,$assign_batch_sem=false)
    {
        if(preg_match('/GU22/',$stdRegn) or preg_match('/22UT/',$stdRegn))
        {
            $startingDueDate="2022-07-01";
            $admissionyear="2022";
        }
        elseif(preg_match('/GU21/',$stdRegn) or preg_match('/21UT/',$stdRegn))
        {
            $startingDueDate="2021-07-01";
            $admissionyear="2021";
        }
        elseif(preg_match('/GU20/',$stdRegn) or preg_match('/20UT/',$stdRegn))
        {
            $startingDueDate="2020-07-01";
            $admissionyear="2020";
        }
        elseif(preg_match('/GU19/',$stdRegn) or preg_match('/19UT/',$stdRegn))
        {
            $startingDueDate="2019-07-01";
            $admissionyear="2019";
        }elseif(preg_match('/GU18/',$stdRegn) or preg_match('/18UT/',$stdRegn))
        {
            $startingDueDate="2018-07-01";
            $admissionyear="2018";
        }
        elseif(preg_match('/GU17/',$stdRegn))
        {
            $startingDueDate="2017-07-01";
            $admissionyear="2017";
        }elseif(preg_match('/GU16/',$stdRegn))
        {
            $startingDueDate="2016-07-01";
            $admissionyear="2016";
        }elseif(preg_match('/GU15/',$stdRegn))
        {
            $startingDueDate="2015-07-01";
            $admissionyear="2015";
        }elseif(preg_match('/GU14/',$stdRegn))
        {
            $startingDueDate="2014-07-01";
            $admissionyear="2014";
        }elseif(preg_match('/GU13/',$stdRegn))
        {
            $startingDueDate="2013-07-01";
            $admissionyear="2013";
        }else{
            $startingDueDate=false;
            $admissionyear=false;
        }

        // if(preg_match('/L/',$stdRegn))
        // {
        //     $currentSem=3;
        // }elseif(preg_match('/C/',$stdRegn))
        // {
        //     $currentSem=$assign_batch_sem;
        // }
        // else{
        //     $currentSem=1;
        // }
        
        $currentSem=$assign_batch_sem;
        
        return $startingDueDate."#-#".$admissionyear."#-#".$currentSem;
    }
    public function studentFeeInstaller($std_regn)
    {
            $std_regn=trim($std_regn);
            
            $assign_class_details=$this->Fetch("*","tbl_assign_class","WHERE std_regn='$std_regn' LIMIT 0,1");
            $assign_batch_id = $assign_class_details['batch_id'];
            $assign_batch_details = $this->Fetch("*","tbl_batches","WHERE id='$assign_batch_id' LIMIT 0,1");
            $assign_batch_sem = $assign_batch_details['sem'];
            
            $startingDue=$this->startingDueDateCals($std_regn,$assign_batch_sem);
            $startingDue=explode("#-#",$startingDue);
            $startingDueDate=$startingDue[0];
            $admissionYear=$startingDue[1];
            $current_sem=$startingDue[2];
            //return $startingDueDate.$std_regn;
            if(!$startingDueDate || !$admissionYear)
            {
                //return "ahmad";
                return false;
            }
            $studentBatchDetails=$this->Fetch("*","tbl_assign_class","WHERE std_regn='$std_regn' AND active=1");
           
            
            $batch_id=$studentBatchDetails['batch_id'];
            $batchDetails=$this->Fetch("*","tbl_batches","WHERE id='$batch_id'");
            //$current_sem=$this->semesterCalc($batchDetails['Sem-year'],$batchDetails['sem']);

            $courseCode=$batchDetails['course_id'];
            $courseDetails=$this->Fetch("*","tbl_courses","WHERE course_id='$courseCode'");
            $courseName=$courseDetails['course_name'];
            $maximum_semester=$courseDetails['semester'];

            $course_fee=$this->FetchList("*","tbl_fees","WHERE course_id='$courseCode' AND year='$admissionYear' AND active=1 AND pay_period='Sem' ");

            $examFee=2500;
            $uniform=5000;
            $fee_cleared=0;
            $ac_session='2018-2019';
            $active=1;

            $feeID="";
            $amount="";
            $fields=array('std_regn','batch_id','fee_id','due_date','amount_due','fee_cleared','ac_session','active');

            //$current_sem=1;
            //$current_sem=$batchDetails['sem'];
            $data="";
            while($current_sem<=$maximum_semester)
            {
                $batchD="NOT";
                if($batchDetails['Sem-year']=='S')
                {
                    $batchD=$this->Fetch("*","tbl_batches","WHERE course_id='$courseCode' AND sem='$current_sem'");
                }
                else{
                    if($current_sem==1 || $current_sem==2)
                    {
                        $year=1;
                    }
                    else{
                        $year=ceil($current_sem/2);
                    }
                    $batchD=$this->Fetch("*","tbl_batches","WHERE course_id='$courseCode' AND sem='$year'");

                }


                foreach ($course_fee as $TutionFee)
                {
                    $feeID=$TutionFee['id'];
                    $amount=$TutionFee['amount'];
                    $batch_id=$batchD['id'];
                    $values=array($std_regn,$batch_id,$feeID,$startingDueDate,$amount,$fee_cleared,$ac_session,$active);
                    $this->Insert("tbl_student_fees",$fields,$values);

                    //needs to enter in database start
                    $data.="</br>Date :".$startingDueDate.", ".$TutionFee['fee_cat']." : ".$TutionFee['amount']."-".$current_sem." semester"." Batch:".$batchD['title'];
                    //needs to enter in database end
                }
                //needs to enter in database start
                if($admissionYear=='2022')
                {
                    $feeID=611;
                    $amount=2500;
                }
                elseif($admissionYear=='2021')
                {
                    $feeID=505;
                    $amount=2500;
                }
                elseif($admissionYear=='2020')
                {
                    $feeID=425;
                    $amount=2500;
                }
                elseif($admissionYear=='2019')
                {
                    $feeID=355;
                    $amount=2500;
                }
                else{
                    $feeID=268;
                    $amount=2500;

                }
                $batch_id=$batchD['id'];
                $values=array($std_regn,$batch_id,$feeID,$startingDueDate,$amount,$fee_cleared,$ac_session,$active);
                $this->Insert("tbl_student_fees",$fields,$values);

                $data.="</br>Date :".$startingDueDate." -, Exam Fee ".$examFee."-".$current_sem." semester";
                $newdate=strtotime("+6 month", strtotime($startingDueDate));
                $startingDueDate=date('Y-m-d',$newdate);
                $current_sem++;
            }

           return $data;
            //return "jamal";
    }
     public function realScape($text)
    {
        return mysqli_real_escape_string($this->Connection,$text);
    }
 public function pdoFetch($fields, $table, $qry = FALSE, $values = FALSE) {

       $this->pdoConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


        $sql="select $fields from $table $qry";
        $stmt=$this->pdoConnection->prepare($sql);
        $stmt->execute($values);
        $u=$stmt->fetch();
     // Controller::$view['message'].=print_r($u);
        return $u;
    }


}
