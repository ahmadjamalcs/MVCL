<?php
require 'libs/Session.php';
require 'config/settings.php';
require 'config/database.php';
require 'libs/Bootstrap.php';
require 'libs/Controller.php';
require 'libs/Database.php';
require 'libs/mailer/mail.php';
@$app = new Bootstrap();
